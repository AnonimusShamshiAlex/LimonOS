/* Заглушки памяти для хост-стенда: куча = обычный malloc. */
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
void *kmalloc(size_t n) { return malloc(n); }
void *kcalloc(size_t a, size_t b) { return calloc(a, b); }
void kfree(void *p) { free(p); }
size_t heap_used(void) { return 0; }
uint64_t pmm_alloc(size_t pages) { void *p = calloc(pages, 4096); return (uint64_t)(uintptr_t)p; }
uint64_t pmm_free_bytes(void) { return 0; }
uint64_t pmm_used_bytes(void) { return 0; }
size_t heap_total(void) { return 64u * 1024 * 1024; }
unsigned heap_bad_frees(void) { return 0; }

/* Фаза 3: shell.c зовёт user_selftest(); на хосте ring3 нет */
struct term;
int user_selftest(struct term *t) { (void)t; return 0; }
int user_run_file(struct term *t, int cwd, int argc, const char *const *argv) { (void)t; (void)cwd; (void)argc; (void)argv; return 0; }
