/* Тест приёма TCP из kernel/net.c: порядок, дубликаты, дыры, перекрытие, переполнение, FIN, RST */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../../kernel/net.c"

volatile uint64_t timer_ticks;
static uint8_t last_frame[2000]; static size_t last_len; static int nsent;
int nic_init(void){return -1;}
int nic_send(const void*p,size_t n){ memcpy(last_frame,p,n); last_len=n; nsent++; return 0; }
int nic_recv(void*b,size_t n){(void)b;(void)n;return 0;} const uint8_t*nic_mac(void){static uint8_t m[6];return m;}
const char*nic_name(void){return "t";} int nic_link(void){return 0;}
void *kmalloc(size_t n){return calloc(1,n);} void kfree(void*p){free(p);}
int tls_connect(struct tls_conn*c,tls_send_fn s,tls_recv_fn r,void*x,const char*h){(void)c;(void)s;(void)r;(void)x;(void)h;return -1;}
int tls_write(struct tls_conn*c,const uint8_t*d,size_t n){(void)c;(void)d;(void)n;return 0;}
int tls_read(struct tls_conn*c,uint8_t*b,size_t n,int t){(void)c;(void)b;(void)n;(void)t;return 0;}
void tls_close(struct tls_conn*c){(void)c;}
const char *tls_err_str(int e){(void)e;return "x";}

static int fails;
#define CHECK(c) do{ if(!(c)){ printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } }while(0)

#define SRV 0x0A000001u
static void feed(uint32_t seq, uint8_t flags, const void *data, size_t n) {
    uint8_t seg[20 + 2000]; memset(seg, 0, 20);
    wr16(seg, 443); wr16(seg + 2, 0xC000); wr32(seg + 4, seq); seg[12] = 5 << 4; seg[13] = flags;
    if (n) memcpy(seg + 20, data, n);
    tcp_rx(SRV, seg, 20 + n);
}
static uint32_t sent_ack(void) { return rd32(last_frame + 14 + 20 + 8); }
static uint16_t sent_win(void) { return rd16(last_frame + 14 + 20 + 14); }

int main(void) {
    ni.ip = 0;
    struct tcp_conn *c = &tcpc[0];
    memset(c, 0, sizeof *c);
    c->state = TCP_ESTABLISHED; c->rip = SRV; c->rport = 443; c->lport = 0xC000;
    c->rx = kmalloc(TCP_RXCAP); c->ack = 1000; c->seq = 5000;
    uint8_t out[40000]; char data[40000]; for (int i = 0; i < 40000; i++) data[i] = (char)('a' + i % 26);

    feed(1000, 0x18, data, 100);                         /* по порядку */
    CHECK(c->rxlen == 100 && c->ack == 1100 && sent_ack() == 1100);
    feed(1000, 0x18, data, 100);                         /* полный дубликат */
    CHECK(c->rxlen == 100 && c->ack == 1100 && sent_ack() == 1100);
    feed(1200, 0x18, data + 200, 50);                    /* дыра: 1100..1199 потеряны */
    CHECK(c->rxlen == 100 && c->ack == 1100 && sent_ack() == 1100);   /* повторный ACK 1100 */
    feed(1050, 0x18, data + 50, 150);                    /* перекрытие: 1050..1199, новое с 1100 */
    CHECK(c->rxlen == 200 && c->ack == 1200);
    feed(1200, 0x18, data + 200, 50);                    /* теперь по порядку */
    CHECK(c->rxlen == 250 && c->ack == 1250);
    int n = tcp_recv(0, out, 1000, 10);
    CHECK(n == 250 && memcmp(out, data, 250) == 0 && c->rxlen == 0);   /* ничего не потеряно, порядок верный */

    /* данные ПРИХОДЯТ, пока никто не читает (ровно то, из-за чего ломался TLS) */
    uint32_t seq = 1250; size_t sent = 0;
    while (sent < 20000) { feed(seq, 0x18, data + sent, 1400); seq += 1400; sent += 1400; }
    CHECK(c->rxlen == sent);
    size_t got = 0;
    while (got < sent) { int r = tcp_recv(0, out + got, 3000, 10); if (r <= 0) break; got += (size_t)r; }
    CHECK(got == sent && memcmp(out, data, sent) == 0);

    /* переполнение буфера: лишнее не подтверждаем, окно честное */
    c->rxlen = 0; c->ack = 7000; seq = 7000;
    for (int i = 0; i < 30; i++) { feed(seq, 0x18, data, 1460); if (c->ack == seq + 1460) seq += 1460; }
    CHECK(c->rxlen <= TCP_RXCAP && c->ack == 7000 + c->rxlen);
    CHECK(sent_win() < TCP_RXCAP);
    printf("  (буфер заполнен: %zu байт, окно %u)\n", c->rxlen, sent_win());
    tcp_recv(0, out, 5000, 10);                          /* читаем -> окно открывается, уходит ACK */
    CHECK(sent_win() > 0);

    /* FIN вместе с данными */
    c->rxlen = 0; c->ack = 100; c->got_fin = 0;
    feed(100, 0x19, "xyz", 3);
    CHECK(c->got_fin && c->ack == 104 && sent_ack() == 104);
    CHECK(tcp_recv(0, out, 10, 10) == 3);
    CHECK(tcp_recv(0, out, 10, 10) == 0);                /* дальше — конец потока */
    /* RST не теряет буфер/слот */
    c->got_fin = 0; feed(104, 0x04, NULL, 0);
    CHECK(c->state == TCP_RESET && c->rx != NULL && tcp_alloc() == 1);
    tcp_close(0);
    CHECK(c->state == TCP_CLOSED && c->rx == NULL);
    printf(fails ? "ПРОВАЛ: %d\n" : "все проверки TCP пройдены\n", fails);
    return fails != 0;
}
