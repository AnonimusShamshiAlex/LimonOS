/* Тест чистой логики HTTP из kernel/net.c (без сетевой карты): chunked, URL, переходы, "ответ целиком?" */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../../kernel/net.c"

volatile uint64_t timer_ticks;
int nic_init(void){return -1;} int nic_send(const void*p,size_t n){(void)p;(void)n;return 0;}
int nic_recv(void*b,size_t n){(void)b;(void)n;return 0;} const uint8_t*nic_mac(void){static uint8_t m[6];return m;}
const char*nic_name(void){return "t";} int nic_link(void){return 0;}
void *kmalloc(size_t n){return malloc(n);} void kfree(void*p){free(p);}
int tls_connect(struct tls_conn*c,tls_send_fn s,tls_recv_fn r,void*x,const char*h){(void)c;(void)s;(void)r;(void)x;(void)h;return -1;}
int tls_write(struct tls_conn*c,const uint8_t*d,size_t n){(void)c;(void)d;(void)n;return 0;}
int tls_read(struct tls_conn*c,uint8_t*b,size_t n,int t){(void)c;(void)b;(void)n;(void)t;return 0;}
void tls_close(struct tls_conn*c){(void)c;}
const char *tls_err_str(int e){(void)e;return "x";}

static int fails;
#define CHECK(c) do{ if(!(c)){ printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } }while(0)

int main(void){
    /* chunked */
    char buf[512];
    const char *resp = "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n5\r\nHello\r\n7;ext=1\r\n, world\r\n1B\r\n! and a longer last chunk..\r\n0\r\n\r\n";
    strcpy(buf, resp);
    size_t bo = find_body(buf, strlen(buf));
    size_t n = dechunk(buf, bo, strlen(buf));
    CHECK(strcmp(buf + bo, "Hello, world! and a longer last chunk..") == 0);
    CHECK(n == bo + 39);
    /* оборванный chunked */
    strcpy(buf, "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n10\r\nabc");
    bo = find_body(buf, strlen(buf)); n = dechunk(buf, bo, strlen(buf));
    CHECK(strcmp(buf + bo, "abc") == 0);

    /* http_complete */
    const char *a = "HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhel";
    CHECK(!http_complete(a, strlen(a)));
    const char *b = "HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello";
    CHECK(http_complete(b, strlen(b)));
    CHECK(!http_complete("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n5\r\nHello\r\n", 56));
    CHECK(http_complete(resp, strlen(resp)));
    const char *nc = "HTTP/1.1 304 Not Modified\r\nX: y\r\n\r\n";
    CHECK(http_complete(nc, strlen(nc)));
    CHECK(!http_complete("HTTP/1.1 200 OK\r\nServer: x\r\n\r\nbody", 33));   /* без длины — ждём закрытия */

    /* URL */
    struct url u;
    CHECK(url_parse("https://google.com", &u) == 0 && u.tls && u.port == 443 && !strcmp(u.host, "google.com") && !strcmp(u.path, "/"));
    CHECK(url_parse("example.com/a/b?x=1", &u) == 0 && !u.tls && u.port == 80 && !strcmp(u.path, "/a/b?x=1"));
    CHECK(url_parse("http://h.io:8080/p", &u) == 0 && u.port == 8080 && !strcmp(u.host, "h.io"));
    CHECK(url_parse("https://", &u) != 0);
    /* переходы */
    url_parse("http://google.com/", &u);
    CHECK(url_redirect(&u, "https://www.google.com/") == 0 && u.tls && !strcmp(u.host, "www.google.com"));
    CHECK(url_redirect(&u, "/search?q=1") == 0 && !strcmp(u.path, "/search?q=1") && !strcmp(u.host, "www.google.com"));
    url_parse("https://a.org/dir/page.html", &u);
    CHECK(url_redirect(&u, "other.html") == 0 && !strcmp(u.path, "/dir/other.html"));
    CHECK(url_redirect(&u, "//cdn.x.net/f") == 0 && u.tls && !strcmp(u.host, "cdn.x.net"));
    char s[100]; url_parse("http://h.io:8080/p", &u); url_str(&u, s, sizeof s); CHECK(!strcmp(s, "http://h.io:8080/p"));
    url_parse("https://x.org/q", &u); url_str(&u, s, sizeof s); CHECK(!strcmp(s, "https://x.org/q"));
    char hv[40];
    CHECK(http_header("HTTP/1.1 301\r\nLocation: https://x/\r\n\r\n", 38, "location", hv, sizeof hv) == 0 && !strcmp(hv, "https://x/"));
    printf(fails ? "ПРОВАЛ: %d\n" : "все проверки HTTP пройдены\n", fails);
    return fails != 0;
}
