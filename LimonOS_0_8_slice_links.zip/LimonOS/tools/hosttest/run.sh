#!/bin/sh
# Поднимает openssl s_server (TLS 1.3, AES-128-GCM) с БОЛЬШОЙ цепочкой сертификатов (>16 КБ) и гоняет tls.c
set -e
cd "$(dirname "$0")"; ROOT=../..; T=$(mktemp -d)
openssl req -x509 -newkey rsa:4096 -nodes -keyout $T/k.pem -out $T/c.pem -subj /CN=localhost -days 2 2>/dev/null
cat $T/c.pem $T/c.pem $T/c.pem $T/c.pem $T/c.pem $T/c.pem $T/c.pem $T/c.pem $T/c.pem $T/c.pem $T/c.pem $T/c.pem > $T/chain.pem   # 12 сертификатов: Certificate ~17 КБ (> одной записи TLS)
head -c 120000 /dev/urandom | base64 > $T/big.txt
cp $T/big.txt /tmp/big_expected.txt
mkdir -p $T/www; cp $T/big.txt $T/www/big.txt
gcc -O1 -Wall -I$ROOT/kernel -I$ROOT/kernel/crypto -o $T/test tls_host_test.c \
    $ROOT/kernel/crypto/tls.c $ROOT/kernel/crypto/sha256.c $ROOT/kernel/crypto/hmac.c $ROOT/kernel/crypto/hkdf.c $ROOT/kernel/crypto/gcm.c $ROOT/kernel/crypto/aes.c $ROOT/kernel/crypto/x25519.c
( cd $T/www && openssl s_server -accept 4433 -tls1_3 -ciphersuites TLS_AES_128_GCM_SHA256 \
    -cert $T/c.pem -cert_chain $T/chain.pem -key $T/k.pem -WWW -quiet >/dev/null 2>&1 & echo $! > $T/pid )
sleep 1
$T/test 4433; RC=$?
kill $(cat $T/pid) 2>/dev/null || true
exit $RC
