/* Тест разбора ссылок <a href> в Citrus: номера в тексте и разрешённые адреса. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void *kmalloc(size_t n) { return malloc(n); }
void  kfree(void *p) { free(p); }
#include "../../kernel/browser.c"

static int fails;
#define CHECK(c) do{ if(!(c)){ printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } }while(0)

int main(void) {
    const char *html =
        "<html><body>"
        "<p>Привет <a href=\"/about\">о нас</a> и "
        "<a href='https://other.com/x?y=1'>внешняя</a> и "
        "<a href=\"sub/page.html\">соседняя</a> и "
        "<a href=\"javascript:alert(1)\">скрипт</a> конец</p>"
        "</body></html>";

    char *lines[64];
    struct citrus_link links[16];
    int nlinks = 0;
    int n = html_to_lines(html, strlen(html), 100, lines, 64,
                           "example.com", "/dir/page.html", 1, links, 16, &nlinks);
    CHECK(n >= 1);
    CHECK(nlinks == 3);   /* javascript: ссылка не должна попасть в таблицу */

    /* текст должен содержать номера [1] [2] [3], но не [4] (javascript пропущена) */
    int has1 = 0, has2 = 0, has3 = 0, has4 = 0;
    for (int i = 0; i < n; i++) {
        if (strstr(lines[i], "[1]")) has1 = 1;
        if (strstr(lines[i], "[2]")) has2 = 1;
        if (strstr(lines[i], "[3]")) has3 = 1;
        if (strstr(lines[i], "[4]")) has4 = 1;
    }
    CHECK(has1 && has2 && has3 && !has4);

    /* [1] = /about -> тот же host, путь /about */
    CHECK(strcmp(links[0].host, "example.com") == 0);
    CHECK(strcmp(links[0].path, "/about") == 0);
    CHECK(links[0].tls == 1);

    /* [2] = https://other.com/x?y=1 -> другой host, свой путь */
    CHECK(strcmp(links[1].host, "other.com") == 0);
    CHECK(strcmp(links[1].path, "/x?y=1") == 0);
    CHECK(links[1].tls == 1);

    /* [3] = sub/page.html, относительно каталога /dir/ -> /dir/sub/page.html */
    CHECK(strcmp(links[2].host, "example.com") == 0);
    CHECK(strcmp(links[2].path, "/dir/sub/page.html") == 0);

    if (fails == 0) printf("все проверки ссылок Citrus пройдены\n");
    for (int i = 0; i < n; i++) free(lines[i]);
    return fails ? 1 : 0;
}
