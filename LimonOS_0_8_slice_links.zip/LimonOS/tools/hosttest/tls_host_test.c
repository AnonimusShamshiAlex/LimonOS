/* Проверка TLS-кода LimonOS на компьютере: тот же tls.c, но поверх обычного сокета.
 * Запуск: tools/hosttest/run.sh  (нужен openssl) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "tls.h"

void *kmalloc(size_t n) { return malloc(n); }
void  kfree(void *p) { free(p); }
void  rng_bytes(uint8_t *o, size_t n) { int f = open("/dev/urandom", O_RDONLY); if (read(f, o, n) != (ssize_t)n) exit(9); close(f); }

static int send_fn(void *ctx, const uint8_t *d, size_t n) {
    int fd = *(int *)ctx;
    while (n) { ssize_t w = write(fd, d, n); if (w <= 0) return -1; d += w; n -= (size_t)w; }
    return 0;
}
/* как tcp_recv в ядре: отдаёт НЕ БОЛЬШЕ нескольких сотен байт за раз, чтобы проверить сборку записей */
static int recv_fn(void *ctx, uint8_t *b, size_t n, int to) {
    int fd = *(int *)ctx;
    struct pollfd p = { fd, POLLIN, 0 };
    if (poll(&p, 1, to) <= 0) return 0;
    if (n > 1460) n = 1460;
    ssize_t r = read(fd, b, n);
    return r > 0 ? (int)r : 0;
}

int main(int argc, char **argv) {
    int port = argc > 1 ? atoi(argv[1]) : 4433;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = { .sin_family = AF_INET, .sin_port = htons((uint16_t)port) };
    inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    if (connect(fd, (void *)&a, sizeof a) != 0) { perror("connect"); return 2; }
    struct tls_conn tc;
    int r = tls_connect(&tc, send_fn, recv_fn, &fd, "localhost");
    printf("tls_connect = %d (%s)\n", r, tls_err_str(r));
    if (r != TLS_OK) { tls_close(&tc); return 1; }
    const char *req = "GET /big.txt HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n";
    tls_write(&tc, (const uint8_t *)req, strlen(req));
    static uint8_t out[400000]; size_t total = 0;
    for (;;) {
        int n = tls_read(&tc, out + total, 700, 3000);   /* маленький буфер: проверяем остаток записи */
        if (n <= 0) break;
        total += (size_t)n;
    }
    out[total] = 0;
    printf("получено %zu байт, начало: %.15s\n", total, (char *)out);
    tls_close(&tc);
    FILE *f = fopen("/tmp/tls_out.bin", "wb"); fwrite(out, 1, total, f); fclose(f);
    return 0;
}
