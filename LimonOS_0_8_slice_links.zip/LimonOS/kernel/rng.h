#ifndef LIMON_RNG_H
#define LIMON_RNG_H
#include <stdint.h>
#include <stddef.h>

void rng_init(void);
void rng_bytes(uint8_t *out, size_t n);   /* криптографически случайные байты */

#endif
