#include "ramfs.h"
#include "mem.h"
#include "kstring.h"

struct ramfile {
    char   name[RAMFS_NAME_MAX + 1];
    char  *data;    /* kmalloc'нутая копия содержимого, может быть NULL */
    size_t len;
    uint8_t used;
};

static struct ramfile files[RAMFS_MAX_FILES];

int ramfs_find(const char *name) {
    for (int i = 0; i < RAMFS_MAX_FILES; i++)
        if (files[i].used && strcmp(files[i].name, name) == 0) return i;
    return -1;
}

int ramfs_open(const char *name) {
    int i = ramfs_find(name);
    if (i >= 0) return i;
    for (i = 0; i < RAMFS_MAX_FILES; i++) {
        if (!files[i].used) {
            files[i].used = 1;
            files[i].data = NULL;
            files[i].len = 0;
            size_t n = 0;
            while (name[n] && n < RAMFS_NAME_MAX) { files[i].name[n] = name[n]; n++; }
            files[i].name[n] = 0;
            return i;
        }
    }
    return -1;
}

const char *ramfs_data(int slot) {
    if (slot < 0 || slot >= RAMFS_MAX_FILES || !files[slot].used) return NULL;
    return files[slot].data;
}

size_t ramfs_len(int slot) {
    if (slot < 0 || slot >= RAMFS_MAX_FILES || !files[slot].used) return 0;
    return files[slot].len;
}

const char *ramfs_name(int slot) {
    if (slot < 0 || slot >= RAMFS_MAX_FILES || !files[slot].used) return "";
    return files[slot].name;
}

int ramfs_save(int slot, const char *data, size_t len) {
    if (slot < 0 || slot >= RAMFS_MAX_FILES || !files[slot].used) return -1;
    char *copy = kmalloc(len + 1);
    if (!copy) return -1;
    memcpy(copy, data, len);
    copy[len] = 0;
    if (files[slot].data) kfree(files[slot].data);
    files[slot].data = copy;
    files[slot].len = len;
    return 0;
}

int ramfs_remove(const char *name) {
    int i = ramfs_find(name);
    if (i < 0) return -1;
    if (files[i].data) kfree(files[i].data);
    files[i].data = NULL;
    files[i].len = 0;
    files[i].used = 0;
    files[i].name[0] = 0;
    return 0;
}

int ramfs_list(char out_names[][RAMFS_NAME_MAX + 1], size_t out_lens[], int max) {
    int n = 0;
    for (int i = 0; i < RAMFS_MAX_FILES && n < max; i++) {
        if (!files[i].used) continue;
        size_t k = 0;
        while (files[i].name[k] && k < RAMFS_NAME_MAX) { out_names[n][k] = files[i].name[k]; k++; }
        out_names[n][k] = 0;
        out_lens[n] = files[i].len;
        n++;
    }
    return n;
}
