/* Источник случайности: RDRAND (аппаратный ГПСЧ процессора), если он есть, иначе —
 * резервный вариант (xorshift64, затравленный таймером и адресами стека). RDRAND есть
 * на всех процессорах, которые ставит VirtualBox/QEMU по умолчанию в режиме host-passthrough
 * или на любом железе 2012+ года (Intel Ivy Bridge+, AMD Zen+); на старом железе сработает
 * резервный вариант — он ХУЖЕ RDRAND, но лучше полностью предсказуемого значения. */
#include "rng.h"
#include "cpuinfo.h"

static int have_rdrand;
static uint64_t xorshift_state;

static int rdrand64(uint64_t *out) {
#ifdef HOST_TEST
    (void)out; return 0;
#else
    for (int tries = 0; tries < 10; tries++) {
        uint8_t ok;
        __asm__ volatile ("rdrand %0; setc %1" : "=r"(*out), "=qm"(ok));
        if (ok) return 1;
    }
    return 0;
#endif
}

void rng_init(void) {
    uint32_t a, b, c, d;
    __asm__ volatile ("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(1), "c"(0));
    have_rdrand = (c >> 30) & 1;

    uint64_t seed = 0x2545F4914F6CDD1DULL;
    seed ^= (uint64_t)(uintptr_t)&seed;
    uint64_t r;
    if (have_rdrand && rdrand64(&r)) seed ^= r;
    xorshift_state = seed ? seed : 0x9E3779B97F4A7C15ULL;
}

static uint64_t xorshift_next(void) {
    uint64_t x = xorshift_state;
    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
    xorshift_state = x;
    return x;
}

void rng_bytes(uint8_t *out, size_t n) {
    size_t i = 0;
    while (i < n) {
        uint64_t r;
        if (have_rdrand && rdrand64(&r)) { /* используем RDRAND напрямую */ }
        else r = xorshift_next();          /* резерв — хуже, но не стоит на месте */
        size_t take = n - i; if (take > 8) take = 8;
        for (size_t k = 0; k < take; k++) out[i + k] = (uint8_t)(r >> (8 * k));
        i += take;
    }
}
