#ifndef LIMON_BROWSER_H
#define LIMON_BROWSER_H
#include <stddef.h>
#include <stdint.h>

/* Один адрес, на который можно перейти (ссылка <a href>), уже разрешённый
 * относительно страницы, на которой он найден — абсолютный host+path. */
struct citrus_link {
    char     host[64];
    char     path[220];
    uint16_t port;
    uint8_t  tls;
};

/* Citrus — простой текстовый браузер: убирает теги HTML, раскрывает несколько
 * сущностей (&amp; &lt; ...), сворачивает пробелы и переносит строки по ширине.
 * Ссылки <a href="..."> становятся в тексте пометками [1] [2] ... по порядку
 * появления и попадают в out_links (до max_links штук), чтобы их можно было
 * открыть по номеру — см. cmd_citrus / desktop.c (клавиши: цифры + Enter).
 * base_host/base_path/base_tls — адрес текущей страницы, нужен, чтобы относительные
 * ссылки (href="/ещё" или href="страница.html") превратились в полный адрес.
 * cols — ширина строки в символах. Возвращает количество готовых строк.
 * out_lines — массив указателей на kmalloc'нутые строки (заполняет функция),
 * max_lines — размер этого массива. *out_nlinks — сколько ссылок нашли и уместили. */
int html_to_lines(const char *html, size_t html_len, int cols, char **out_lines, int max_lines,
                   const char *base_host, const char *base_path, int base_tls,
                   struct citrus_link *out_links, int max_links, int *out_nlinks);

#endif
