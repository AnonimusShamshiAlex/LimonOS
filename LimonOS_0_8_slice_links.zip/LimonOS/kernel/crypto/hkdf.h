#ifndef LIMON_HKDF_H
#define LIMON_HKDF_H
#include <stdint.h>
#include <stddef.h>

/* RFC 5869, с SHA-256 */
void hkdf_extract(const uint8_t *salt, size_t salt_len, const uint8_t *ikm, size_t ikm_len, uint8_t prk[32]);
void hkdf_expand(const uint8_t *prk, size_t prk_len, const uint8_t *info, size_t info_len, uint8_t *out, size_t out_len);

/* TLS 1.3 HKDF-Expand-Label (RFC 8446 §7.1) */
void tls_hkdf_expand_label(const uint8_t *secret, const char *label, const uint8_t *ctx, size_t ctx_len,
                            uint8_t *out, size_t out_len);

#endif
