/* X25519 (RFC 7748) — простая, не оптимизированная по скорости и не константная по
 * времени реализация (разовое рукопожатие TLS, не высоконагруженный сервер).
 * Поле GF(2^255-19) представлено как 32 байта little-endian, арифметика —
 * через 64-битные "лимбы" с явным переносом (учебная, но корректная реализация). */
#include "x25519.h"
#include "kstring.h"

typedef uint64_t fe[4];     /* 4 x 64 бита = 256 бит, с избыточным пространством под перенос */

static void fe_from_bytes(fe out, const uint8_t in[32]) {
    for (int i = 0; i < 4; i++) {
        uint64_t v = 0;
        for (int j = 0; j < 8; j++) v |= (uint64_t)in[i*8+j] << (8*j);
        out[i] = v;
    }
    out[3] &= 0x7fffffffffffffffULL;    /* маскируем старший бит, как требует RFC */
}

static void fe_to_bytes(uint8_t out[32], const fe in) {
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 8; j++)
            out[i*8+j] = (uint8_t)(in[i] >> (8*j));
}

/* приводит 256-битное (с запасом) значение к каноническому виду по модулю p=2^255-19 */
static void fe_reduce(fe x) {
    /* сначала частичная редукция переносом: может быть до нескольких "лишних" бит */
    for (int pass = 0; pass < 2; pass++) {
        uint64_t carry = x[3] >> 63;
        x[3] &= 0x7fffffffffffffffULL;
        __uint128_t t = (__uint128_t)x[0] + carry * 19;
        x[0] = (uint64_t)t; carry = (uint64_t)(t >> 64);
        t = (__uint128_t)x[1] + carry; x[1] = (uint64_t)t; carry = (uint64_t)(t >> 64);
        t = (__uint128_t)x[2] + carry; x[2] = (uint64_t)t; carry = (uint64_t)(t >> 64);
        t = (__uint128_t)x[3] + carry; x[3] = (uint64_t)t;
    }
    /* условное вычитание p, если x >= p */
    uint64_t p[4] = { 0xffffffffffffffedULL, 0xffffffffffffffffULL, 0xffffffffffffffffULL, 0x7fffffffffffffffULL };
    uint64_t borrow = 0; uint64_t r[4];
    for (int i = 0; i < 4; i++) {
        __uint128_t t = (__uint128_t)x[i] - p[i] - borrow;
        r[i] = (uint64_t)t;
        borrow = (t >> 64) ? 1 : 0;
    }
    uint64_t use = 1 - (uint32_t)borrow;   /* borrow==0 значит x>=p, используем r */
    for (int i = 0; i < 4; i++) x[i] = use ? r[i] : x[i];
}

static void fe_add(fe out, const fe a, const fe b) {
    uint64_t carry = 0;
    for (int i = 0; i < 4; i++) {
        __uint128_t t = (__uint128_t)a[i] + b[i] + carry;
        out[i] = (uint64_t)t; carry = (uint64_t)(t >> 64);
    }
    /* carry может выйти за пределы 255 бит — компенсируем как при редукции (*19) */
    uint64_t top = out[3] >> 63; out[3] &= 0x7fffffffffffffffULL;
    __uint128_t t = (__uint128_t)out[0] + (carry * 2 + top) * 19;
    out[0] = (uint64_t)t; uint64_t c2 = (uint64_t)(t >> 64);
    t = (__uint128_t)out[1] + c2; out[1] = (uint64_t)t; c2 = (uint64_t)(t >> 64);
    t = (__uint128_t)out[2] + c2; out[2] = (uint64_t)t; c2 = (uint64_t)(t >> 64);
    t = (__uint128_t)out[3] + c2; out[3] = (uint64_t)t;
}

static void fe_sub(fe out, const fe a, const fe b) {
    /* a - b mod p: вычисляем a + 2p - b в ПОЛНОЙ точности на 5 лимбах (без промежуточного
     * свёртывания по модулю), и только в самом конце сворачиваем лишний (5-й) лимб через
     * *38 (т.к. 2^256 ≡ 38 mod p). Так t=a+2p остаётся настоящим большим числом (>=2p>b)
     * на всех шагах, и вычитание b никогда не уходит в минус — в отличие от более ранней
     * версии, где ранняя свёртка делала t снова маленьким и t-b мог уйти в отрицательные
     * (с переносом через 2^256, который без этой правки давал ошибку ровно в 38). */
    uint64_t p2[4] = { 0xffffffffffffffdaULL, 0xffffffffffffffffULL, 0xffffffffffffffffULL, 0xffffffffffffffffULL };
    uint64_t t[5];
    uint64_t carry = 0;
    for (int i = 0; i < 4; i++) {
        __uint128_t s = (__uint128_t)a[i] + p2[i] + carry;
        t[i] = (uint64_t)s; carry = (uint64_t)(s >> 64);
    }
    t[4] = carry;                                   /* 0 или 1 — a+2p может занимать до 257 бит */

    uint64_t borrow = 0;
    for (int i = 0; i < 4; i++) {
        __uint128_t s = (__uint128_t)t[i] - b[i] - borrow;
        t[i] = (uint64_t)s; borrow = (s >> 64) ? 1 : 0;
    }
    t[4] -= borrow;                                  /* t[4] остаётся 0 или 1: a+2p>=2p>b всегда */

    fe r = { t[0], t[1], t[2], t[3] };
    if (t[4]) {
        __uint128_t s = (__uint128_t)r[0] + 38;
        r[0] = (uint64_t)s; uint64_t c2 = (uint64_t)(s >> 64);
        s = (__uint128_t)r[1] + c2; r[1] = (uint64_t)s; c2 = (uint64_t)(s >> 64);
        s = (__uint128_t)r[2] + c2; r[2] = (uint64_t)s; c2 = (uint64_t)(s >> 64);
        s = (__uint128_t)r[3] + c2; r[3] = (uint64_t)s;
    }
    fe_reduce(r);
    memcpy(out, r, sizeof r);
}

/* умножение 256x256 -> 512 бит (8 лимбов), затем редукция по модулю 2^255-19 */
static void fe_mul(fe out, const fe a, const fe b) {
    uint64_t r[8] = {0};
    for (int i = 0; i < 4; i++) {
        __uint128_t carry = 0;
        for (int j = 0; j < 4; j++) {
            __uint128_t t = (__uint128_t)a[i] * b[j] + r[i+j] + carry;
            r[i+j] = (uint64_t)t;
            carry = t >> 64;
        }
        r[i+4] = (uint64_t)carry;
    }
    /* r = r_lo (4 лимба) + r_hi (4 лимба) * 2^256; 2^256 = 2*2^255 ≡ 2*19 = 38 (mod p) */
    fe lo = { r[0], r[1], r[2], r[3] & 0x7fffffffffffffffULL };
    uint64_t top = r[3] >> 63;
    fe hi = { r[4], r[5], r[6], r[7] };
    /* добавляем top*2^255 ≡ top*19, и hi*2^256 ≡ hi*38 */
    __uint128_t t = (__uint128_t)lo[0] + top * 19;
    uint64_t tmp0 = (uint64_t)t; uint64_t c = (uint64_t)(t >> 64);
    t = (__uint128_t)lo[1] + c; uint64_t tmp1=(uint64_t)t; c=(uint64_t)(t>>64);
    t = (__uint128_t)lo[2] + c; uint64_t tmp2=(uint64_t)t; c=(uint64_t)(t>>64);
    t = (__uint128_t)lo[3] + c; uint64_t tmp3=(uint64_t)t;
    fe acc = { tmp0, tmp1, tmp2, tmp3 };

    /* hi*38, прибавляем лимб за лимбом со сдвигом на 0 (т.к. hi уже умножен на 2^256=38 по модулю).
     * Перенос за пределы лимба 3 (carry) сам представляет множитель 2^256 ≡ 38 (mod p) —
     * сворачиваем его тем же способом, пока не останется переноса (хватает 2 проходов:
     * carry тут всегда мал, порядка 38*2^64/2^64 ~ 38, так что второй проход его гасит). */
    uint64_t carry = 0;
    for (int i = 0; i < 4; i++) {
        __uint128_t s = (__uint128_t)hi[i] * 38 + acc[i] + carry;
        acc[i] = (uint64_t)s; carry = (uint64_t)(s >> 64);
    }
    while (carry) {
        __uint128_t s = (__uint128_t)acc[0] + carry * 38;
        acc[0] = (uint64_t)s; uint64_t c2 = (uint64_t)(s >> 64);
        s = (__uint128_t)acc[1] + c2; acc[1] = (uint64_t)s; c2 = (uint64_t)(s >> 64);
        s = (__uint128_t)acc[2] + c2; acc[2] = (uint64_t)s; c2 = (uint64_t)(s >> 64);
        s = (__uint128_t)acc[3] + c2; acc[3] = (uint64_t)s; c2 = (uint64_t)(s >> 64);
        carry = c2;   /* в норме здесь уже 0; цикл защищает от крайне редкого повторного переноса */
    }
    memcpy(out, acc, sizeof acc);
    fe_reduce(out);
}

static void fe_sq(fe out, const fe a) { fe_mul(out, a, a); }

static void fe_mul_small(fe out, const fe a, uint32_t k) {
    uint64_t carry = 0;
    fe r;
    for (int i = 0; i < 4; i++) {
        __uint128_t t = (__uint128_t)a[i] * k + carry;
        r[i] = (uint64_t)t; carry = (uint64_t)(t >> 64);
    }
    uint64_t top = r[3] >> 63; r[3] &= 0x7fffffffffffffffULL;
    __uint128_t t = (__uint128_t)r[0] + carry * 38 + top * 19;
    r[0] = (uint64_t)t; uint64_t c2 = (uint64_t)(t >> 64);
    t = (__uint128_t)r[1] + c2; r[1] = (uint64_t)t; c2 = (uint64_t)(t >> 64);
    t = (__uint128_t)r[2] + c2; r[2] = (uint64_t)t; c2 = (uint64_t)(t >> 64);
    t = (__uint128_t)r[3] + c2; r[3] = (uint64_t)t;
    memcpy(out, r, sizeof r);
    fe_reduce(out);
}

/* a^(p-2) mod p (обратный элемент по Ферма). Простое, заведомо-корректное
 * возведение в степень "слева направо" по известным битам константы p-2 —
 * вместо хрупкой вручную выведенной цепочки сложений. Медленнее (~255 шагов
 * вместо ~265 в оптимизированной цепочке, то есть практически так же), но
 * риск ошибки в переписывании почти нулевой: биты берутся из самого p-2. */
static void fe_invert(fe out, const fe a) {
    /* p-2 = 2^255 - 21, лимбы посчитаны отдельно (python) и проверены */
    static const uint64_t e[4] = {
        0xffffffffffffffebULL, 0xffffffffffffffffULL, 0xffffffffffffffffULL, 0x7fffffffffffffffULL
    };
    fe r = {1,0,0,0};
    for (int bit = 254; bit >= 0; bit--) {
        fe_sq(r, r);
        if ((e[bit/64] >> (bit%64)) & 1) fe_mul(r, r, a);
    }
    memcpy(out, r, sizeof r);
}

static void cswap(uint64_t swap, fe a, fe b) {
    uint64_t mask = (uint64_t)0 - (swap & 1);
    for (int i = 0; i < 4; i++) {
        uint64_t d = mask & (a[i] ^ b[i]);
        a[i] ^= d; b[i] ^= d;
    }
}

void x25519(uint8_t out[32], const uint8_t scalar[32], const uint8_t u_in[32]) {
    uint8_t k[32]; memcpy(k, scalar, 32);
    k[0] &= 248; k[31] &= 127; k[31] |= 64;

    fe x1, x2, z2, x3, z3, u;
    fe_from_bytes(u, u_in);
    memcpy(x1, u, sizeof u);
    x2[0]=1;x2[1]=0;x2[2]=0;x2[3]=0;
    z2[0]=0;z2[1]=0;z2[2]=0;z2[3]=0;
    memcpy(x3, u, sizeof u);
    z3[0]=1;z3[1]=0;z3[2]=0;z3[3]=0;
    uint64_t swap = 0;

    for (int t = 254; t >= 0; t--) {
        uint64_t kt = (k[t/8] >> (t%8)) & 1;
        swap ^= kt;
        cswap(swap, x2, x3);
        cswap(swap, z2, z3);
        swap = kt;

        fe A,AA,B,BB,E,C,D,DA,CB, tmp;
        fe_add(A, x2, z2); fe_sq(AA, A);
        fe_sub(B, x2, z2); fe_sq(BB, B);
        fe_sub(E, AA, BB);
        fe_add(C, x3, z3);
        fe_sub(D, x3, z3);
        fe_mul(DA, D, A);
        fe_mul(CB, C, B);
        fe_add(tmp, DA, CB); fe_sq(x3, tmp);
        fe_sub(tmp, DA, CB); fe_sq(tmp, tmp); fe_mul(z3, x1, tmp);
        fe_mul(x2, AA, BB);
        fe_mul_small(tmp, E, 121665);
        fe_add(tmp, AA, tmp);
        fe_mul(z2, E, tmp);
    }
    cswap(swap, x2, x3);
    cswap(swap, z2, z3);

    fe zinv, res;
    fe_invert(zinv, z2);
    fe_mul(res, x2, zinv);
    fe_reduce(res);
    fe_to_bytes(out, res);
}

void x25519_base(uint8_t out[32], const uint8_t scalar[32]) {
    uint8_t base[32] = {9};
    x25519(out, scalar, base);
}
