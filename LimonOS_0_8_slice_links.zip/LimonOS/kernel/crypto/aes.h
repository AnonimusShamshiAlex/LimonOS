#ifndef LIMON_AES_H
#define LIMON_AES_H
#include <stdint.h>
#include <stddef.h>

struct aes128 { uint32_t rk[44]; };     /* развёрнутый ключ (11 раундов) */

void aes128_init(struct aes128 *a, const uint8_t key[16]);
void aes128_encrypt_block(const struct aes128 *a, const uint8_t in[16], uint8_t out[16]);

#endif
