#include "gcm.h"
#include "kstring.h"

/* умножение в GF(2^128) по модулю x^128+x^7+x^2+x+1, как того требует GCM (GHASH) */
static void gf_mul(const uint8_t x[16], const uint8_t y[16], uint8_t out[16]) {
    uint8_t z[16] = {0}, v[16];
    memcpy(v, y, 16);
    for (int i = 0; i < 128; i++) {
        int byte = i / 8, bit = 7 - (i % 8);
        if (x[byte] & (1 << bit)) for (int k = 0; k < 16; k++) z[k] ^= v[k];
        int lsb = v[15] & 1;
        for (int k = 15; k > 0; k--) v[k] = (uint8_t)((v[k] >> 1) | (v[k-1] << 7));
        v[0] = (uint8_t)(v[0] >> 1);
        if (lsb) v[0] ^= 0xe1;
    }
    memcpy(out, z, 16);
}

struct ghash_st { uint8_t h[16]; uint8_t y[16]; };

static void ghash_init(struct ghash_st *g, const uint8_t h[16]) { memcpy(g->h, h, 16); memset(g->y, 0, 16); }

static void ghash_block(struct ghash_st *g, const uint8_t block[16]) {
    uint8_t x[16];
    for (int i = 0; i < 16; i++) x[i] = (uint8_t)(g->y[i] ^ block[i]);
    gf_mul(x, g->h, g->y);
}

static void ghash_data(struct ghash_st *g, const uint8_t *data, size_t len) {
    uint8_t block[16];
    while (len >= 16) { ghash_block(g, data); data += 16; len -= 16; }
    if (len) { memset(block, 0, 16); memcpy(block, data, len); ghash_block(g, block); }
}

static void put_counter(uint8_t block[16], const uint8_t nonce[12], uint32_t ctr) {
    memcpy(block, nonce, 12);
    block[12] = (uint8_t)(ctr >> 24); block[13] = (uint8_t)(ctr >> 16);
    block[14] = (uint8_t)(ctr >> 8);  block[15] = (uint8_t)ctr;
}

static void ctr_crypt(const struct aes128 *a, const uint8_t nonce[12], uint32_t start_ctr,
                       const uint8_t *in, size_t len, uint8_t *out) {
    uint8_t block[16], ks[16];
    uint32_t ctr = start_ctr;
    while (len > 0) {
        put_counter(block, nonce, ctr++);
        aes128_encrypt_block(a, block, ks);
        size_t take = len < 16 ? len : 16;
        for (size_t i = 0; i < take; i++) out[i] = (uint8_t)(in[i] ^ ks[i]);
        in += take; out += take; len -= take;
    }
}

static void lenblock(uint8_t out[16], size_t aad_len, size_t ct_len) {
    uint64_t ab = (uint64_t)aad_len * 8, cb = (uint64_t)ct_len * 8;
    for (int i = 0; i < 8; i++) out[i]     = (uint8_t)(ab >> (56 - 8*i));
    for (int i = 0; i < 8; i++) out[8 + i] = (uint8_t)(cb >> (56 - 8*i));
}

void gcm_encrypt(const struct aes128 *a, const uint8_t nonce[12],
                  const uint8_t *aad, size_t aad_len,
                  const uint8_t *pt, size_t pt_len,
                  uint8_t *ct, uint8_t tag[16]) {
    uint8_t h[16] = {0}, j0ks[16];
    aes128_encrypt_block(a, h, h);                 /* H = AES(key, 0^128) */
    ctr_crypt(a, nonce, 2, pt, pt_len, ct);         /* J0=счётчик1, шифрование данных с inc32(J0)=счётчик2 */

    struct ghash_st g; ghash_init(&g, h);
    ghash_data(&g, aad, aad_len);
    ghash_data(&g, ct, pt_len);
    uint8_t lb[16]; lenblock(lb, aad_len, pt_len);
    ghash_block(&g, lb);

    put_counter(j0ks, nonce, 1);                    /* J0 = IV || 1 — только для маскирования тега */
    aes128_encrypt_block(a, j0ks, j0ks);
    for (int i = 0; i < 16; i++) tag[i] = (uint8_t)(g.y[i] ^ j0ks[i]);
}

int gcm_decrypt(const struct aes128 *a, const uint8_t nonce[12],
                 const uint8_t *aad, size_t aad_len,
                 const uint8_t *ct, size_t ct_len, const uint8_t tag[16],
                 uint8_t *pt) {
    uint8_t h[16] = {0}, j0ks[16];
    aes128_encrypt_block(a, h, h);

    struct ghash_st g; ghash_init(&g, h);
    ghash_data(&g, aad, aad_len);
    ghash_data(&g, ct, ct_len);
    uint8_t lb[16]; lenblock(lb, aad_len, ct_len);
    ghash_block(&g, lb);

    put_counter(j0ks, nonce, 1);
    aes128_encrypt_block(a, j0ks, j0ks);
    uint8_t want[16];
    for (int i = 0; i < 16; i++) want[i] = (uint8_t)(g.y[i] ^ j0ks[i]);

    uint8_t diff = 0;
    for (int i = 0; i < 16; i++) diff |= (uint8_t)(want[i] ^ tag[i]);   /* сравнение за постоянное время */
    if (diff != 0) return 0;

    ctr_crypt(a, nonce, 2, ct, ct_len, pt);
    return 1;
}
