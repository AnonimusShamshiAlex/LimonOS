#include "hkdf.h"
#include "hmac.h"
#include "kstring.h"

void hkdf_extract(const uint8_t *salt, size_t salt_len, const uint8_t *ikm, size_t ikm_len, uint8_t prk[32]) {
    static const uint8_t zero[32] = { 0 };
    if (!salt || salt_len == 0) { salt = zero; salt_len = 32; }
    hmac_sha256(salt, salt_len, ikm, ikm_len, prk);
}

void hkdf_expand(const uint8_t *prk, size_t prk_len, const uint8_t *info, size_t info_len, uint8_t *out, size_t out_len) {
    uint8_t t[32]; size_t tlen = 0;
    uint8_t buf[256 + 32 + 1];
    size_t done = 0;
    uint8_t counter = 1;
    while (done < out_len) {
        size_t n = 0;
        memcpy(buf + n, t, tlen); n += tlen;
        memcpy(buf + n, info, info_len); n += info_len;
        buf[n++] = counter++;
        hmac_sha256(prk, prk_len, buf, n, t);
        tlen = 32;
        size_t take = out_len - done; if (take > 32) take = 32;
        memcpy(out + done, t, take);
        done += take;
    }
}

void tls_hkdf_expand_label(const uint8_t *secret, const char *label, const uint8_t *ctx, size_t ctx_len,
                            uint8_t *out, size_t out_len) {
    /* HkdfLabel: uint16 length; opaque label<7..255> = "tls13 " + label; opaque context<0..255> */
    uint8_t info[2 + 1 + 6 + 32 + 1 + 64];
    size_t n = 0;
    info[n++] = (uint8_t)(out_len >> 8); info[n++] = (uint8_t)out_len;
    size_t llen = 6 + strlen(label);
    info[n++] = (uint8_t)llen;
    memcpy(info + n, "tls13 ", 6); n += 6;
    memcpy(info + n, label, strlen(label)); n += strlen(label);
    info[n++] = (uint8_t)ctx_len;
    memcpy(info + n, ctx, ctx_len); n += ctx_len;
    hkdf_expand(secret, 32, info, n, out, out_len);
}
