#ifndef LIMON_GCM_H
#define LIMON_GCM_H
#include <stdint.h>
#include <stddef.h>
#include "aes.h"

/* AES-128-GCM (NIST SP 800-38D), 12-байтовый nonce, 16-байтовый тег.
 * ct и pt могут указывать на один и тот же буфер (шифрование на месте). */
void gcm_encrypt(const struct aes128 *a, const uint8_t nonce[12],
                  const uint8_t *aad, size_t aad_len,
                  const uint8_t *pt, size_t pt_len,
                  uint8_t *ct, uint8_t tag[16]);

/* возвращает 1, если тег совпал (и ct расшифрован в pt), 0 — подделка/ошибка (pt не трогается) */
int gcm_decrypt(const struct aes128 *a, const uint8_t nonce[12],
                 const uint8_t *aad, size_t aad_len,
                 const uint8_t *ct, size_t ct_len, const uint8_t tag[16],
                 uint8_t *pt);

#endif
