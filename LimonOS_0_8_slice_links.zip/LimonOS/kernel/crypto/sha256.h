#ifndef LIMON_SHA256_H
#define LIMON_SHA256_H
#include <stdint.h>
#include <stddef.h>

struct sha256_ctx { uint32_t h[8]; uint8_t buf[64]; uint64_t len; size_t buflen; };

void sha256_init(struct sha256_ctx *c);
void sha256_update(struct sha256_ctx *c, const void *data, size_t n);
void sha256_final(struct sha256_ctx *c, uint8_t out[32]);
void sha256(const void *data, size_t n, uint8_t out[32]);          /* удобный вариант в одно действие */

#endif
