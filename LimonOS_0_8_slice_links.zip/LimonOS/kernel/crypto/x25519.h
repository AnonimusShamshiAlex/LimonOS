#ifndef LIMON_X25519_H
#define LIMON_X25519_H
#include <stdint.h>

/* RFC 7748. out = X25519(scalar, u). Для генерации своего ключа: u = базовая точка {9,0,0,...}. */
void x25519(uint8_t out[32], const uint8_t scalar[32], const uint8_t u[32]);
void x25519_base(uint8_t out[32], const uint8_t scalar[32]);   /* out = X25519(scalar, 9) */

#endif
