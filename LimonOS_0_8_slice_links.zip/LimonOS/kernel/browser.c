#include "browser.h"
#include "mem.h"
#include "kstring.h"

struct ent { const char *name; uint32_t cp; };
static const struct ent entities[] = {
    { "amp;", '&' }, { "lt;", '<' }, { "gt;", '>' }, { "quot;", '"' },
    { "apos;", '\'' }, { "#39;", '\'' }, { "nbsp;", ' ' }, { "mdash;", 0x2014 },
    { "ndash;", 0x2013 }, { "hellip;", 0x2026 }, { "laquo;", 0xAB }, { "raquo;", 0xBB },
};

static const char *const block_tags[] = {
    "p", "br", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "table", "ul", "ol",
};

static int tag_is_block(const char *name, int len) {
    for (unsigned i = 0; i < sizeof block_tags / sizeof block_tags[0]; i++)
        if ((int)strlen(block_tags[i]) == len && strncmp(block_tags[i], name, (size_t)len) == 0) return 1;
    return 0;
}

/* индекс needle в h (без учёта регистра), ищет начиная с from; n, если не найдено */
static size_t ci_find(const char *h, size_t n, size_t from, const char *needle) {
    size_t nl = strlen(needle);
    if (nl == 0 || from + nl > n) return n;
    for (size_t i = from; i + nl <= n; i++) {
        size_t j = 0;
        for (; j < nl; j++) {
            char a = h[i + j]; if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
            char b = needle[j];
            if (a != b) break;
        }
        if (j == nl) return i;
    }
    return n;
}

static int starts_tag_ci(const char *h, size_t n, size_t i, const char *name) {
    size_t l = strlen(name);
    if (i + 1 + l > n) return 0;
    for (size_t j = 0; j < l; j++) {
        char a = h[i + 1 + j]; if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
        if (a != name[j]) return 0;
    }
    char after = (i + 1 + l < n) ? h[i + 1 + l] : '>';
    return after == '>' || after == ' ' || after == '\t' || after == '\n' || after == '/';
}

static int ci_eq(char a, char b) {
    if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
    if (b >= 'A' && b <= 'Z') b = (char)(b + 32);
    return a == b;
}

/* Ищет атрибут href="..." (или ') внутри сырых символов одного тега <a ...>.
 * raw/rawlen — всё, что было между '<' и '>' (без них). Возвращает 1, если нашли. */
static int find_href(const char *raw, int rawlen, char *out, int outsz) {
    for (int i = 0; i + 4 <= rawlen; i++) {
        if (!(ci_eq(raw[i], 'h') && ci_eq(raw[i + 1], 'r') && ci_eq(raw[i + 2], 'e') && ci_eq(raw[i + 3], 'f'))) continue;
        if (i > 0 && raw[i - 1] != ' ' && raw[i - 1] != '\t' && raw[i - 1] != '\n') continue;
        int j = i + 4;
        while (j < rawlen && (raw[j] == ' ' || raw[j] == '\t')) j++;
        if (j >= rawlen || raw[j] != '=') continue;
        j++;
        while (j < rawlen && (raw[j] == ' ' || raw[j] == '\t')) j++;
        if (j >= rawlen) continue;
        char q = raw[j];
        int o = 0;
        if (q == '"' || q == '\'') {
            j++;
            while (j < rawlen && raw[j] != q && o < outsz - 1) out[o++] = raw[j++];
        } else {
            while (j < rawlen && raw[j] != ' ' && o < outsz - 1) out[o++] = raw[j++];
        }
        out[o] = 0;
        return o > 0;
    }
    return 0;
}

/* Превращает href (возможно относительный) в абсолютный адрес, считая,
 * что страница, где эта ссылка найдена, была по адресу base_host/base_path. */
static void resolve_link(const char *base_host, const char *base_path, int base_tls,
                          const char *href, struct citrus_link *out) {
    out->host[0] = 0; out->path[0] = 0;
    out->tls = (uint8_t)base_tls; out->port = (uint16_t)(base_tls ? 443 : 80);
    const char *h = href;
    if (strncmp(h, "https://", 8) == 0) { out->tls = 1; out->port = 443; h += 8; }
    else if (strncmp(h, "http://", 7) == 0) { out->tls = 0; out->port = 80; h += 7; }
    else if (h[0] == '/' && h[1] == '/') { h += 2; }
    else if (h[0] == '/') {
        size_t hn = 0; while (base_host[hn] && hn < 63) { out->host[hn] = base_host[hn]; hn++; } out->host[hn] = 0;
        size_t pn = 0; while (h[pn] && pn < 219) { out->path[pn] = h[pn]; pn++; } out->path[pn] = 0;
        return;
    } else if (h[0] == 0 || h[0] == '#') {
        size_t hn = 0; while (base_host[hn] && hn < 63) { out->host[hn] = base_host[hn]; hn++; } out->host[hn] = 0;
        size_t pn = 0; while (base_path[pn] && pn < 219) { out->path[pn] = base_path[pn]; pn++; } out->path[pn] = 0;
        return;
    } else {
        /* относительно "каталога" текущей страницы: всё после последнего '/' обрезаем */
        size_t hn = 0; while (base_host[hn] && hn < 63) { out->host[hn] = base_host[hn]; hn++; } out->host[hn] = 0;
        size_t dirlen = 0, bl = strlen(base_path);
        for (size_t i = 0; i < bl; i++) if (base_path[i] == '/') dirlen = i + 1;
        size_t pn = 0;
        if (dirlen > 0) { for (size_t i = 0; i < dirlen && pn < 219; i++) out->path[pn++] = base_path[i]; }
        else out->path[pn++] = '/';
        size_t k = 0; while (h[k] && pn < 219) out->path[pn++] = h[k++];
        out->path[pn] = 0;
        return;
    }
    /* сюда попадаем только для http://, https:// и protocol-relative:// — разбираем host[:port]/path */
    size_t hn = 0;
    while (*h && *h != '/' && *h != '?' && *h != '#' && hn < 63) out->host[hn++] = *h++;
    out->host[hn] = 0;
    if (*h == '/') {
        size_t pn = 0; while (*h && pn < 219) out->path[pn++] = *h++;
        out->path[pn] = 0;
    } else { out->path[0] = '/'; out->path[1] = 0; }
}

/* html -> обычный текст (без тегов), с переводами строк на блочных тегах.
 * Содержимое <script> и <style> целиком вырезается поиском закрывающего тега,
 * чтобы символ '<' внутри самого JS/CSS (например "x<2") не ломал разбор.
 * Заодно собирает ссылки <a href>: в текст подставляется пометка [N], а
 * абсолютный адрес ссылки N кладётся в links (их не больше max_links). */
static char *strip_html(const char *h, size_t n, size_t *out_len,
                         const char *base_host, const char *base_path, int base_tls,
                         struct citrus_link *links, int max_links, int *out_nlinks) {
    size_t cap = n + 64;
    char *out = kmalloc(cap);
    if (!out) { *out_len = 0; return NULL; }
    size_t o = 0;
    int in_tag = 0;
    int last_space = 1;
    char tagname[16]; int tnlen = 0; int tag_closing = 0; int tagname_done = 0;
    char tagraw[256]; int trawlen = 0;
    int nlinks = 0;
    size_t i = 0;
    while (i < n) {
        unsigned char c = (unsigned char)h[i];
        if (!in_tag && c == '<') {
            if (starts_tag_ci(h, n, i, "script") || starts_tag_ci(h, n, i, "style")) {
                int is_script = starts_tag_ci(h, n, i, "script");
                size_t gt = i;
                while (gt < n && h[gt] != '>') gt++;
                size_t close = ci_find(h, n, gt, is_script ? "</script>" : "</style>");
                i = (close < n) ? close + (is_script ? 9 : 8) : n;
                if (!last_space && o < cap - 1) { out[o++] = ' '; last_space = 1; }
                continue;
            }
            in_tag = 1; tnlen = 0; tag_closing = 0; trawlen = 0; tagname_done = 0;
            i++;
            if (i < n && h[i] == '/') { tag_closing = 1; i++; }
            continue;
        }
        if (in_tag) {
            if (c == '>') {
                in_tag = 0;
                tagname[tnlen < 15 ? tnlen : 15] = 0;
                if (!tag_closing && tnlen == 1 && tagname[0] == 'a' && links && nlinks < max_links) {
                    char href[220];
                    if (find_href(tagraw, trawlen, href, sizeof href) &&
                        strncmp(href, "javascript:", 11) != 0 && strncmp(href, "mailto:", 7) != 0 &&
                        strncmp(href, "tel:", 4) != 0) {
                        resolve_link(base_host, base_path, base_tls, href, &links[nlinks]);
                        char mark[8]; int mn = 0; mark[mn++] = '[';
                        int num = nlinks + 1;
                        char digits[4]; int dn = 0;
                        if (num == 0) digits[dn++] = '0';
                        while (num > 0 && dn < 3) { digits[dn++] = (char)('0' + num % 10); num /= 10; }
                        while (dn > 0) mark[mn++] = digits[--dn];
                        mark[mn++] = ']'; mark[mn] = 0;
                        for (int k = 0; k < mn && o < cap - 1; k++) out[o++] = mark[k];
                        last_space = 0;
                        nlinks++;
                    }
                }
                if (tag_is_block(tagname, tnlen)) {
                    if (o > 0 && out[o - 1] != '\n') out[o++] = '\n';
                    last_space = 1;
                } else if (!last_space && o < cap - 1) {
                    out[o++] = ' '; last_space = 1;
                }
                i++;
                continue;
            }
            if (!tagname_done) {
                if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) {
                    if (tnlen < 15) tagname[tnlen++] = (char)(c >= 'A' && c <= 'Z' ? c + 32 : c);
                } else {
                    tagname_done = 1;   /* имя тега кончилось на первом пробеле/слэше — дальше атрибуты */
                }
            }
            if (trawlen < (int)sizeof tagraw - 1) tagraw[trawlen++] = (char)c;
            i++;
            continue;
        }
        if (c == '&') {
            unsigned j;
            int matched = 0;
            for (j = 0; j < sizeof entities / sizeof entities[0]; j++) {
                size_t l = strlen(entities[j].name);
                if (i + 1 + l <= n && strncmp(h + i + 1, entities[j].name, l) == 0) {
                    if (o + 4 < cap) o += (size_t)utf8_encode(entities[j].cp, out + o);
                    i += 1 + l;
                    matched = 1;
                    last_space = (entities[j].cp == ' ');
                    break;
                }
            }
            if (matched) continue;
            if (i + 1 < n && h[i + 1] == '#') {
                size_t k = i + 2;
                int hex = (k < n && (h[k] == 'x' || h[k] == 'X'));
                if (hex) k++;
                uint32_t cp = 0; size_t start = k;
                while (k < n && h[k] != ';' &&
                       ((h[k] >= '0' && h[k] <= '9') || (hex && ((h[k] | 32) >= 'a' && (h[k] | 32) <= 'f')))) {
                    int d = (h[k] <= '9') ? h[k] - '0' : (h[k] | 32) - 'a' + 10;
                    cp = cp * (uint32_t)(hex ? 16 : 10) + (uint32_t)d;
                    k++;
                }
                if (k > start && k < n && h[k] == ';' && o + 4 < cap) {
                    o += (size_t)utf8_encode(cp, out + o);
                    i = k + 1;
                    last_space = 0;
                    continue;
                }
            }
            if (o < cap - 1) { out[o++] = '&'; last_space = 0; }
            i++;
            continue;
        }
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
            if (!last_space && o < cap - 1) { out[o++] = ' '; last_space = 1; }
            i++;
            continue;
        }
        if (o < cap - 1) { out[o++] = (char)c; last_space = 0; }
        i++;
    }
    while (o > 0 && (out[o - 1] == ' ' || out[o - 1] == '\n')) o--;
    out[o] = 0;
    *out_len = o;
    if (out_nlinks) *out_nlinks = nlinks;
    return out;
}

struct wrapper {
    char **out; int n, max;
    char buf[600]; int cols; size_t bytes;
};

static void wrap_flush(struct wrapper *w) {
    if (w->n >= w->max) return;
    w->buf[w->bytes] = 0;
    char *s = kmalloc(w->bytes + 1);
    if (s) { memcpy(s, w->buf, w->bytes + 1); w->out[w->n++] = s; }
    w->cols = 0; w->bytes = 0;
}

int html_to_lines(const char *html, size_t html_len, int cols, char **out_lines, int max_lines,
                   const char *base_host, const char *base_path, int base_tls,
                   struct citrus_link *out_links, int max_links, int *out_nlinks) {
    size_t tlen;
    if (out_nlinks) *out_nlinks = 0;
    char *text = strip_html(html, html_len, &tlen, base_host, base_path, base_tls, out_links, max_links, out_nlinks);
    if (!text) return 0;

    struct wrapper w = { out_lines, 0, max_lines, { 0 }, 0, 0 };
    const char *p = text;
    int blank_run = 0;

    while (*p && w.n < max_lines) {
        if (*p == '\n') {
            wrap_flush(&w);
            p++;
            blank_run++;
            if (blank_run > 1) continue;          /* не больше одной пустой строки подряд */
            if (w.n < max_lines) { char *e = kmalloc(1); if (e) { e[0] = 0; out_lines[w.n++] = e; } }
            continue;
        }
        blank_run = 0;
        if (*p == ' ') { p++; continue; }           /* ведущие пробелы новой строки пропускаем */
        const char *word = p;
        int wcols = 0;
        while (*word && *word != ' ' && *word != '\n') { utf8_next(&word); wcols++; }
        size_t wbytes = (size_t)(word - p);

        if (w.cols > 0 && w.cols + 1 + wcols > cols) wrap_flush(&w);
        else if (w.cols > 0) { w.buf[w.bytes++] = ' '; w.cols++; }

        while (wcols > cols) {                      /* слово длиннее строки — режем жёстко */
            int take = cols - w.cols;
            if (take <= 0) { wrap_flush(&w); take = cols; }
            while (take-- > 0 && wbytes > 0) {
                const char *q = p; utf8_next(&q);
                size_t cb = (size_t)(q - p);
                if (w.bytes + cb >= sizeof w.buf - 1) break;
                memcpy(w.buf + w.bytes, p, cb); w.bytes += cb; w.cols++;
                p += cb; wbytes -= cb; wcols--;
            }
            wrap_flush(&w);
        }
        if (w.bytes + wbytes < sizeof w.buf - 1) { memcpy(w.buf + w.bytes, p, wbytes); w.bytes += wbytes; w.cols += wcols; }
        p += wbytes;
    }
    if (w.cols > 0) wrap_flush(&w);
    kfree(text);
    return w.n;
}
