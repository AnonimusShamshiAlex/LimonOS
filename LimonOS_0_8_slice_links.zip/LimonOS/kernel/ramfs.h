#ifndef LIMON_RAMFS_H
#define LIMON_RAMFS_H
#include <stddef.h>

/* Ramfs — временное хранилище "файлов" прямо в памяти (ОЗУ), пока нет
 * настоящего диска и файловой системы (этап 7 в docs/TZ.md). Данные
 * живут только до выключения/перезагрузки. Этим пользуется редактор
 * Slice (slice <имя>) и команда files (файлы). */

#define RAMFS_MAX_FILES 16
#define RAMFS_NAME_MAX  31

/* Находит файл по имени, -1 — не найден */
int ramfs_find(const char *name);

/* Находит файл или создаёт новый пустой слот с этим именем.
 * Возвращает индекс слота, -1 — нет места (максимум RAMFS_MAX_FILES). */
int ramfs_open(const char *name);

/* Содержимое файла (может быть NULL/0, если ещё ничего не сохраняли) */
const char *ramfs_data(int slot);
size_t      ramfs_len(int slot);
const char *ramfs_name(int slot);

/* Сохраняет содержимое буфера в файл (копирует, предыдущие данные освобождаются) */
int ramfs_save(int slot, const char *data, size_t len);

/* Удаляет файл насовсем */
int ramfs_remove(const char *name);

/* Список для команды "files": имена существующих файлов.
 * Возвращает число найденных (<= max), пишет в out_names[i] (буфер RAMFS_NAME_MAX+1). */
int ramfs_list(char out_names[][RAMFS_NAME_MAX + 1], size_t out_lens[], int max);

#endif
