#ifndef LIMON_NET_H
#define LIMON_NET_H
#include <stdint.h>
#include <stddef.h>

/* Vine — сетевой стек LimonOS: Ethernet, ARP, IPv4, ICMP, UDP, DHCP, DNS. IP-адреса — числа вида a<<24|b<<16|c<<8|d */
struct netinfo {
    int present, link, configured;
    uint8_t mac[6];
    uint32_t ip, mask, gw, dns;
    const char *nic;
};

int  net_init(void);                              /* 0 — сетевая карта запущена */
const struct netinfo *net_info(void);
void net_poll(void);                              /* принять и обработать пришедшие пакеты */
int  net_dhcp(void);                              /* получить адрес автоматически, 0 — успех */
int  net_ping(uint32_t ip, int timeout_ms, int *rtt_ms);   /* 0 — ответ получен */
int  net_resolve(const char *host, uint32_t *ip); /* имя -> адрес; 0 — успех */
int  net_parse_ip(const char *s, uint32_t *ip);   /* "10.0.2.15" -> число; 0 — успех */
void net_ip_str(uint32_t ip, char out[16]);

/* ---- TCP (простой клиент: только исходящие соединения, без повторной отправки и переупорядочивания) ---- */
int  tcp_connect(uint32_t ip, uint16_t port, int timeout_ms);   /* id соединения или <0 */
int  tcp_send(int id, const void *data, size_t len);
int  tcp_read_all(int id, void *buf, size_t maxlen, int timeout_ms);  /* читает до FIN или таймаута */
int  tcp_recv(int id, void *buf, size_t maxlen, int timeout_ms);      /* читает что пришло (не ждёт FIN), 0 — таймаут/конец, <0 — ошибка */
void tcp_close(int id);

/* ---- HTTP (поверх TCP; перенаправления — через web_get) ---- */
int  http_get(const char *host, uint16_t port, const char *path,
              char *out, size_t outmax, int *status, size_t *body_off);
/* достаёт значение заголовка (например "Location") из ответа http_get; 0 — нашёл */
int  http_header(const char *response, size_t headers_len, const char *name, char *out, size_t outmax);

/* ---- HTTPS (TLS 1.3 поверх TCP). ВНИМАНИЕ: сертификат сервера не проверяется — см.
 * предупреждение в kernel/crypto/tls.c. Работает как http_get, но по шифрованному каналу. */
int  https_get(const char *host, const char *path,
               char *out, size_t outmax, int *status, size_t *body_off);

/* Коды ошибок https_get: -1 нет DNS, -2 нет соединения, -3 нет памяти, <= -100 — ошибка TLS (код = n + 100, см. tls_err_str).
 * Подробности последней ошибки TLS: */
int  net_last_tls_error(void);    /* TLS_ERR_* (отрицательное) или 0 */
int  net_last_tls_alert(void);    /* код TLS-alert сервера, если он прислал */

void net_describe_error(int n, char *out, size_t max);   /* понятный текст для кода ошибки web_get/https_get */

/* ---- web_get: как curl -L. Принимает полный URL (http:// или https://) или host/путь.
 * Идёт по переходам (до 6), собирает chunked. Ответ: заголовки+тело в out, *body_off — начало тела,
 * final_url — куда в итоге пришли. Возвращает длину, или <=0 / код ошибки как у https_get. */
int  web_get(const char *url, char *out, size_t outmax, int *status, size_t *body_off,
             char *final_url, size_t final_max);

#endif
