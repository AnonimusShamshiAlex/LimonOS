#include "image.h"
#include "mem.h"
#include "kstring.h"

/* GIF — свой LZW-декодер (не DEFLATE: другой, более простой алгоритм, переменная
 * разрядность кода 3..12 бит). Берём только ПЕРВЫЙ кадр (анимация игнорируется —
 * честное упрощение, как и во многих простых просмотрщиках). */

struct gifbits {
    const uint8_t *data; size_t len, pos;    /* уже склеенные под-блоки (без длин) */
    uint32_t buf; int nbits;
};

static int gb_read(struct gifbits *g, int nbits, int *out) {
    while (g->nbits < nbits) {
        if (g->pos >= g->len) return -1;
        g->buf |= (uint32_t)g->data[g->pos++] << g->nbits;
        g->nbits += 8;
    }
    *out = (int)(g->buf & ((1u << nbits) - 1));
    g->buf >>= nbits; g->nbits -= nbits;
    return 0;
}

#define GIF_MAXCODES 4096

int gif_decode(const uint8_t *data, size_t len, struct img_rgb *out, int max_w, int max_h) {
    if (max_w <= 0) max_w = 2048;
    if (max_h <= 0) max_h = 2048;
    if (len < 13 || (memcmp(data, "GIF87a", 6) != 0 && memcmp(data, "GIF89a", 6) != 0)) return IMG_ERR_FORMAT;

    int width = data[6] | (data[7] << 8);
    int height = data[8] | (data[9] << 8);
    uint8_t flags = data[10];
    int gct_present = (flags & 0x80) != 0;
    int gct_size = 2 << (flags & 0x07);                 /* число цветов глобальной таблицы */
    if (width <= 0 || height <= 0) return IMG_ERR_DATA;
    if (width > max_w || height > max_h) return IMG_ERR_TOO_BIG;

    size_t pos = 13;
    uint8_t gct[256 * 3]; int ngct = 0;
    if (gct_present) {
        size_t need = (size_t)gct_size * 3;
        if (pos + need > len) return IMG_ERR_DATA;
        memcpy(gct, data + pos, need);
        ngct = gct_size;
        pos += need;
    }

    int transparent_idx = -1;

    while (pos < len) {
        uint8_t marker = data[pos];
        if (marker == 0x21) {                            /* Extension */
            if (pos + 1 >= len) return IMG_ERR_DATA;
            uint8_t label = data[pos + 1];
            pos += 2;
            if (label == 0xF9 && pos < len) {             /* Graphic Control Extension — тут флаг прозрачности */
                uint8_t blk = data[pos];
                if (pos + 1 + blk <= len && blk >= 4) {
                    uint8_t gflags = data[pos + 1];
                    if (gflags & 0x01) transparent_idx = data[pos + 1 + 3];
                }
            }
            while (pos < len && data[pos] != 0) pos += (size_t)data[pos] + 1;   /* под-блоки до 0 */
            if (pos < len) pos++;                          /* сам терминатор 0 */
        } else if (marker == 0x2C) {                       /* Image Descriptor — вот он, первый (и единственный) кадр */
            if (pos + 10 > len) return IMG_ERR_DATA;
            int left = data[pos + 1] | (data[pos + 2] << 8);
            int top = data[pos + 3] | (data[pos + 4] << 8);
            int iw = data[pos + 5] | (data[pos + 6] << 8);
            int ih = data[pos + 7] | (data[pos + 8] << 8);
            uint8_t iflags = data[pos + 9];
            pos += 10;
            int lct_present = (iflags & 0x80) != 0;
            int interlaced = (iflags & 0x40) != 0;
            int lct_size = 2 << (iflags & 0x07);
            uint8_t lct[256 * 3]; int nlct = 0;
            if (lct_present) {
                size_t need = (size_t)lct_size * 3;
                if (pos + need > len) return IMG_ERR_DATA;
                memcpy(lct, data + pos, need);
                nlct = lct_size; pos += need;
            }
            const uint8_t *pal = lct_present ? lct : gct;
            int npal = lct_present ? nlct : ngct;
            if (npal == 0 || iw <= 0 || ih <= 0) return IMG_ERR_DATA;
            if (iw > max_w || ih > max_h) return IMG_ERR_TOO_BIG;

            if (pos >= len) return IMG_ERR_DATA;
            int min_code_size = data[pos++];
            if (min_code_size < 2 || min_code_size > 11) return IMG_ERR_DATA;

            /* склеиваем под-блоки LZW-данных в один буфер (длина у каждого в первом байте) */
            size_t cap = 4096, n = 0;
            uint8_t *lzw = kmalloc(cap);
            if (!lzw) return IMG_ERR_MEMORY;
            while (pos < len && data[pos] != 0) {
                uint8_t blk = data[pos];
                if (pos + 1 + blk > len) { kfree(lzw); return IMG_ERR_DATA; }
                if (n + blk > cap) { size_t nc = cap * 2; while (nc < n + blk) nc *= 2;
                    uint8_t *nb = kmalloc(nc); if (!nb) { kfree(lzw); return IMG_ERR_MEMORY; }
                    memcpy(nb, lzw, n); kfree(lzw); lzw = nb; cap = nc; }
                memcpy(lzw + n, data + pos + 1, blk); n += blk;
                pos += (size_t)blk + 1;
            }

            /* --- LZW-декодирование в индексы палитры --- */
            uint8_t *indices = kmalloc((size_t)iw * (size_t)ih);
            if (!indices) { kfree(lzw); return IMG_ERR_MEMORY; }
            size_t idx_n = 0, idx_cap = (size_t)iw * (size_t)ih;

            int clear_code = 1 << min_code_size;
            int end_code = clear_code + 1;
            int code_size = min_code_size + 1;
            int next_code = end_code + 1;
            /* Классический LZW с таблицей (prefix,suffix): код >= clear_code — это (предыдущий код, добавленный байт).
             * Разворачиваем строку кода, идя по цепочке prefix до корня (однобайтового кода < clear_code);
             * получается задом наперёд — поэтому пишем в stackbuf и затем выводим в обратном порядке. */
            static int16_t prefix[GIF_MAXCODES]; static uint8_t suffix[GIF_MAXCODES];
            for (int i = 0; i < clear_code; i++) { prefix[i] = -1; suffix[i] = (uint8_t)i; }

            struct gifbits gb = { lzw, n, 0, 0, 0 };
            int prev = -1;
            uint8_t stackbuf[GIF_MAXCODES]; int ok = 1;
            for (;;) {
                int code;
                if (gb_read(&gb, code_size, &code) != 0) break;     /* данные кончились — считаем, что кадр готов */
                if (code == clear_code) {
                    next_code = end_code + 1; code_size = min_code_size + 1; prev = -1; continue;
                }
                if (code == end_code) break;
                /* код может быть: уже в таблице (code < next_code), либо ровно следующий ещё не добавленный
                 * (особый случай "KwKwK" — означает string(prev)+первый_байт(prev)); иное — повреждённые данные */
                int special = (code == next_code);
                if (code > next_code || (special && prev < 0) || (!special && code >= next_code)) { ok = 0; break; }

                int cc = special ? prev : code, sp = 0;
                while (cc >= 0) {
                    if (sp >= GIF_MAXCODES) { ok = 0; break; }
                    stackbuf[sp++] = suffix[cc];
                    cc = prefix[cc];
                }
                if (!ok) break;
                int first_char = stackbuf[sp - 1];          /* первый байт развёрнутой строки (code, либо prev для KwKwK) */
                for (int k = sp - 1; k >= 0; k--) if (idx_n < idx_cap) indices[idx_n++] = stackbuf[k];
                if (special && idx_n < idx_cap) indices[idx_n++] = (uint8_t)first_char;   /* KwKwK: + первый байт prev */

                if (prev >= 0 && next_code < GIF_MAXCODES) {     /* новая строка = string(prev) + first_char */
                    prefix[next_code] = (int16_t)prev;
                    suffix[next_code] = (uint8_t)first_char;
                    next_code++;
                    if (next_code == (1 << code_size) && code_size < 12) code_size++;
                }
                prev = code;
            }
            kfree(lzw);
            if (idx_n < idx_cap) memset(indices + idx_n, 0, idx_cap - idx_n);   /* обрезанные данные — остаток чёрным/0 */

            uint8_t *rgb = kmalloc((size_t)width * (size_t)height * 3);
            if (!rgb) { kfree(indices); return IMG_ERR_MEMORY; }
            memset(rgb, 0xFF, (size_t)width * (size_t)height * 3);     /* то, что вне кадра — белое */

            /* indices[] лежит в порядке декодирования: для обычного GIF это подряд строка за
             * строкой (srcrow==y), а для чересстрочного — сначала проход 0,8,16,.., потом 4,12,20,..,
             * потом 2,6,10,.., потом 1,3,5,.. (Adam7-подобная развёртка, но попроще, только по Y). */
            static const int pass_start[4] = { 0, 4, 2, 1 };
            static const int pass_step[4] = { 8, 8, 4, 2 };
            int sy = 0;
            int npasses = interlaced ? 4 : 1;
            for (int pass = 0; pass < npasses; pass++) {
                int y0 = interlaced ? pass_start[pass] : 0;
                int step = interlaced ? pass_step[pass] : 1;
                for (int y = y0; y < ih; y += step) {
                    if (sy >= ih) break;
                    int srcrow = sy;                      /* indices[] всегда в порядке декодирования — это и есть srcrow */
                    for (int x = 0; x < iw; x++) {
                        int idxv = indices[(size_t)srcrow * (size_t)iw + (size_t)x];
                        int py = top + y, pxx = left + x;
                        if (py < 0 || py >= height || pxx < 0 || pxx >= width) continue;
                        if (idxv == transparent_idx) continue;           /* прозрачный — оставляем белым фоном */
                        if (idxv >= npal) idxv = 0;
                        uint8_t *d = rgb + ((size_t)py * (size_t)width + (size_t)pxx) * 3;
                        d[0] = pal[idxv * 3]; d[1] = pal[idxv * 3 + 1]; d[2] = pal[idxv * 3 + 2];
                    }
                    sy++;
                }
            }
            kfree(indices);
            out->pix = rgb; out->w = width; out->h = height;
            return IMG_OK;
        } else {
            return IMG_ERR_DATA;                           /* неожиданный маркер */
        }
    }
    return IMG_ERR_DATA;                                    /* не нашли ни одного кадра */
}
