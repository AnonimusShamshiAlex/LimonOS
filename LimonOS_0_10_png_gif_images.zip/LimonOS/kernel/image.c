#include "image.h"
#include "mem.h"
#include "kstring.h"

int png_decode(const uint8_t *data, size_t len, struct img_rgb *out, int max_w, int max_h);
int gif_decode(const uint8_t *data, size_t len, struct img_rgb *out, int max_w, int max_h);

int image_decode(const uint8_t *data, size_t len, struct img_rgb *out, int max_w, int max_h) {
    if (len >= 8 && data[0] == 0x89 && data[1] == 'P' && data[2] == 'N' && data[3] == 'G')
        return png_decode(data, len, out, max_w, max_h);
    if (len >= 6 && (memcmp(data, "GIF87a", 6) == 0 || memcmp(data, "GIF89a", 6) == 0))
        return gif_decode(data, len, out, max_w, max_h);
    return IMG_ERR_FORMAT;          /* JPEG/WEBP/SVG/... — пока не поддержано, см. image.h */
}

void image_free(struct img_rgb *im) {
    if (im->pix) kfree(im->pix);
    im->pix = NULL; im->w = im->h = 0;
}
