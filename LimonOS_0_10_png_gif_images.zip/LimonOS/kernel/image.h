#ifndef LIMON_IMAGE_H
#define LIMON_IMAGE_H
#include <stddef.h>
#include <stdint.h>

/* Декодер картинок для <img> в Citrus. Без внешних библиотек — всё с нуля, как и весь
 * остальной код ядра (DEFLATE — kernel/inflate.c, LZW для GIF — kernel/image_gif.c).
 *
 * Поддержано: PNG (8 бит на канал, без чересстрочной Adam7-развёртки — это почти все
 * PNG в вебе) и GIF (первый кадр, без анимации). НЕ поддержано: JPEG, WEBP, SVG,
 * PNG с глубиной 1/2/4/16 бит или с Adam7 — для них image_decode просто вернёт
 * IMG_ERR_FORMAT, и вызывающий код (browser.c) покажет подпись [alt], как раньше. */
struct img_rgb {
    uint8_t *pix;     /* w*h*3 байт, по строкам, RGB; kmalloc — освобождать image_free */
    int w, h;
};

enum {
    IMG_OK = 0,
    IMG_ERR_FORMAT   = 1,   /* не PNG/GIF, либо неподдержанный вариант (глубина, Adam7, ...) */
    IMG_ERR_DATA     = 2,   /* похоже на PNG/GIF, но данные битые/обрезаны */
    IMG_ERR_MEMORY   = 3,
    IMG_ERR_TOO_BIG  = 4,   /* больше max_w/max_h или внутреннего защитного предела */
};

int  image_decode(const uint8_t *data, size_t len, struct img_rgb *out, int max_w, int max_h);
void image_free(struct img_rgb *im);

#endif
