#include "image.h"
#include "inflate.h"
#include "mem.h"
#include "kstring.h"

static const uint8_t PNG_SIG[8] = { 0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A };

static uint32_t be32(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
}

static int paeth(int a, int b, int c) {
    int p = a + b - c;
    int pa = p > a ? p - a : a - p, pb = p > b ? p - b : b - p, pc = p > c ? p - c : c - p;
    if (pa <= pb && pa <= pc) return a;
    if (pb <= pc) return b;
    return c;
}

int png_decode(const uint8_t *data, size_t len, struct img_rgb *out, int max_w, int max_h) {
    if (max_w <= 0) max_w = 2048;
    if (max_h <= 0) max_h = 2048;
    if (len < 8 || memcmp(data, PNG_SIG, 8) != 0) return IMG_ERR_FORMAT;

    size_t pos = 8;
    int width = 0, height = 0, bitdepth = 0, colortype = -1, interlace = 0;
    uint8_t palette[256 * 3]; int npalette = 0;
    uint8_t trns[256]; int ntrns = 0; for (int i = 0; i < 256; i++) trns[i] = 255;
    uint8_t *idat = NULL; size_t idat_len = 0, idat_cap = 0;
    int have_ihdr = 0, done = 0;

    while (pos + 8 <= len && !done) {
        uint32_t clen = be32(data + pos);
        const char *ctype = (const char *)(data + pos + 4);
        size_t cstart = pos + 8;
        if (cstart + clen + 4 > len) { if (idat) kfree(idat); return IMG_ERR_DATA; }  /* чанк вылезает за файл */

        if (memcmp(ctype, "IHDR", 4) == 0) {
            if (clen < 13) { if (idat) kfree(idat); return IMG_ERR_DATA; }
            width = (int)be32(data + cstart);
            height = (int)be32(data + cstart + 4);
            bitdepth = data[cstart + 8];
            colortype = data[cstart + 9];
            /* data[cstart+10] = compression (всегда 0), data[cstart+11] = filter (всегда 0) */
            interlace = data[cstart + 12];
            have_ihdr = 1;
            if (width <= 0 || height <= 0) { if (idat) kfree(idat); return IMG_ERR_DATA; }
            if (width > max_w || height > max_h) { if (idat) kfree(idat); return IMG_ERR_TOO_BIG; }
        } else if (memcmp(ctype, "PLTE", 4) == 0) {
            npalette = (int)(clen / 3); if (npalette > 256) npalette = 256;
            memcpy(palette, data + cstart, (size_t)npalette * 3);
        } else if (memcmp(ctype, "tRNS", 4) == 0) {
            ntrns = (int)clen; if (ntrns > 256) ntrns = 256;
            memcpy(trns, data + cstart, (size_t)ntrns);
        } else if (memcmp(ctype, "IDAT", 4) == 0) {
            if (idat_len + clen > idat_cap) {
                size_t newcap = idat_cap ? idat_cap * 2 : 65536;
                while (newcap < idat_len + clen) newcap *= 2;
                uint8_t *nb = kmalloc(newcap);
                if (!nb) { if (idat) kfree(idat); return IMG_ERR_MEMORY; }
                if (idat) { memcpy(nb, idat, idat_len); kfree(idat); }
                idat = nb; idat_cap = newcap;
            }
            memcpy(idat + idat_len, data + cstart, clen);
            idat_len += clen;
        } else if (memcmp(ctype, "IEND", 4) == 0) {
            done = 1;
        }
        pos = cstart + clen + 4;   /* данные + 4 байта CRC (не проверяем) */
    }

    if (!have_ihdr || !idat || idat_len < 3) { if (idat) kfree(idat); return IMG_ERR_DATA; }
    if (bitdepth != 8) { kfree(idat); return IMG_ERR_FORMAT; }           /* 1/2/4/16 бит — не поддержано */
    if (interlace != 0) { kfree(idat); return IMG_ERR_FORMAT; }         /* Adam7 — не поддержано */
    int channels;
    switch (colortype) {
        case 0: channels = 1; break;   /* серый */
        case 2: channels = 3; break;   /* RGB */
        case 3: channels = 1; break;   /* палитра */
        case 4: channels = 2; break;   /* серый+альфа */
        case 6: channels = 4; break;   /* RGBA */
        default: kfree(idat); return IMG_ERR_FORMAT;
    }
    if (colortype == 3 && npalette == 0) { kfree(idat); return IMG_ERR_DATA; }

    size_t stride = (size_t)width * (size_t)channels;                    /* байт пикселей в строке */
    size_t raw_size = (stride + 1) * (size_t)height;                     /* +1 байт фильтра на строку */
    uint8_t *raw = kmalloc(raw_size);
    if (!raw) { kfree(idat); return IMG_ERR_MEMORY; }

    /* IDAT — это zlib-поток: 2 байта заголовка, затем сырой DEFLATE (plюс Adler32 в конце,
     * который inflate_raw просто не дочитает — поток сам себя завершает битом BFINAL). */
    size_t outlen = 0;
    int rc = (idat_len > 2) ? inflate_raw(idat + 2, idat_len - 2, raw, raw_size, &outlen) : INFL_ERR_INPUT;
    kfree(idat);
    if (rc != INFL_OK || outlen != raw_size) { kfree(raw); return IMG_ERR_DATA; }

    uint8_t *rgb = kmalloc((size_t)width * (size_t)height * 3);
    if (!rgb) { kfree(raw); return IMG_ERR_MEMORY; }

    size_t bpp = channels;                                              /* 8 бит/канал => bpp = channels байт */
    uint8_t *prevrow = NULL;
    for (int y = 0; y < height; y++) {
        uint8_t *rowp = raw + (size_t)y * (stride + 1);
        uint8_t filt = rowp[0];
        uint8_t *px = rowp + 1;
        for (size_t x = 0; x < stride; x++) {
            int left = (x >= bpp) ? px[x - bpp] : 0;
            int up = prevrow ? prevrow[x] : 0;
            int upleft = (prevrow && x >= bpp) ? prevrow[x - bpp] : 0;
            int v = px[x];
            switch (filt) {
                case 0: break;
                case 1: v = (v + left) & 0xFF; break;
                case 2: v = (v + up) & 0xFF; break;
                case 3: v = (v + (left + up) / 2) & 0xFF; break;
                case 4: v = (v + paeth(left, up, upleft)) & 0xFF; break;
                default: kfree(raw); kfree(rgb); return IMG_ERR_DATA;    /* неизвестный тип фильтра */
            }
            px[x] = (uint8_t)v;
        }
        /* конвертация строки в RGB24, прозрачность — смешиваем с белым (упрощение) */
        uint8_t *out_row = rgb + (size_t)y * (size_t)width * 3;
        for (int x = 0; x < width; x++) {
            uint8_t r, g, b;
            if (colortype == 0) { r = g = b = px[x]; }
            else if (colortype == 2) { r = px[x * 3]; g = px[x * 3 + 1]; b = px[x * 3 + 2]; }
            else if (colortype == 3) {
                int idx = px[x]; if (idx >= npalette) idx = 0;
                r = palette[idx * 3]; g = palette[idx * 3 + 1]; b = palette[idx * 3 + 2];
                int a = (idx < ntrns) ? trns[idx] : 255;
                if (a < 255) { r = (uint8_t)((r * a + 255 * (255 - a)) / 255); g = (uint8_t)((g * a + 255 * (255 - a)) / 255); b = (uint8_t)((b * a + 255 * (255 - a)) / 255); }
            } else if (colortype == 4) {
                int gr = px[x * 2], a = px[x * 2 + 1];
                r = g = b = (uint8_t)((gr * a + 255 * (255 - a)) / 255);
            } else { /* 6: RGBA */
                int rr = px[x * 4], gg = px[x * 4 + 1], bb = px[x * 4 + 2], a = px[x * 4 + 3];
                r = (uint8_t)((rr * a + 255 * (255 - a)) / 255);
                g = (uint8_t)((gg * a + 255 * (255 - a)) / 255);
                b = (uint8_t)((bb * a + 255 * (255 - a)) / 255);
            }
            out_row[x * 3] = r; out_row[x * 3 + 1] = g; out_row[x * 3 + 2] = b;
        }
        prevrow = px;
    }
    kfree(raw);
    out->pix = rgb; out->w = width; out->h = height;
    return IMG_OK;
}
