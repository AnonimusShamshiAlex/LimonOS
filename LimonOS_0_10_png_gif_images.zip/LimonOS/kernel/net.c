#include "net.h"
#include "nic.h"
#include "timer.h"
#include "kstring.h"
#include "format.h"
#include "mem.h"
#include "tls.h"

static uint8_t txb[1600], rxb[2048];
static struct netinfo ni;
static const uint8_t BCAST[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

static uint16_t rd16(const uint8_t *p) { return (uint16_t)((p[0] << 8) | p[1]); }
static uint32_t rd32(const uint8_t *p) { return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }
static void wr16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)(v >> 8); p[1] = (uint8_t)v; }
static void wr32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v; }

static uint16_t csum(const uint8_t *d, size_t n) {
    uint32_t s = 0;
    size_t i = 0;
    for (; i + 1 < n; i += 2) s += (uint32_t)((d[i] << 8) | d[i + 1]);
    if (n & 1) s += (uint32_t)d[n - 1] << 8;
    while (s >> 16) s = (s & 0xFFFF) + (s >> 16);
    return (uint16_t)~s;
}

static uint64_t deadline_ms(int ms) { return timer_ticks + (uint64_t)((ms * TIMER_HZ + 999) / 1000); }

/* ---------- Ethernet ---------- */

static int eth_send(const uint8_t *dst, uint16_t type, const uint8_t *pl, size_t len) {
    if (len > 1500) return -1;
    memcpy(txb, dst, 6);
    memcpy(txb + 6, ni.mac, 6);
    wr16(txb + 12, type);
    memcpy(txb + 14, pl, len);
    size_t total = 14 + len;
    if (total < 60) { memset(txb + total, 0, 60 - total); total = 60; }
    return nic_send(txb, total);
}

/* ---------- ARP ---------- */

static struct { uint32_t ip; uint8_t mac[6]; int ok; } arpc[8];
static int arp_next;

static void arp_learn(uint32_t ip, const uint8_t *mac) {
    if (!ip) return;
    for (int i = 0; i < 8; i++)
        if (arpc[i].ok && arpc[i].ip == ip) { memcpy(arpc[i].mac, mac, 6); return; }
    arpc[arp_next].ip = ip; arpc[arp_next].ok = 1; memcpy(arpc[arp_next].mac, mac, 6);
    arp_next = (arp_next + 1) % 8;
}

static int arp_lookup(uint32_t ip, uint8_t *mac) {
    for (int i = 0; i < 8; i++)
        if (arpc[i].ok && arpc[i].ip == ip) { memcpy(mac, arpc[i].mac, 6); return 1; }
    return 0;
}

static void arp_send(uint16_t op, const uint8_t *dmac, uint32_t tip, const uint8_t *tha) {
    uint8_t p[28];
    wr16(p, 1); wr16(p + 2, 0x0800); p[4] = 6; p[5] = 4; wr16(p + 6, op);
    memcpy(p + 8, ni.mac, 6); wr32(p + 14, ni.ip);
    memcpy(p + 18, tha, 6); wr32(p + 24, tip);
    eth_send(dmac, 0x0806, p, 28);
}

static void arp_rx(const uint8_t *p, size_t n) {
    if (n < 28 || rd16(p) != 1 || rd16(p + 2) != 0x0800) return;
    uint16_t op = rd16(p + 6);
    uint32_t sip = rd32(p + 14), tip = rd32(p + 24);
    arp_learn(sip, p + 8);
    if (op == 1 && ni.ip && tip == ni.ip) arp_send(2, p + 8, sip, p + 8);
}

static int arp_resolve(uint32_t ip, uint8_t *mac) {
    static const uint8_t zero[6] = { 0 };
    for (int tries = 0; tries < 3; tries++) {
        if (arp_lookup(ip, mac)) return 1;
        arp_send(1, BCAST, ip, zero);
        uint64_t dl = deadline_ms(300);
        while (timer_ticks < dl) {
            net_poll();
            if (arp_lookup(ip, mac)) return 1;
        }
    }
    return 0;
}

/* ---------- IPv4 ---------- */

static uint16_t ip_id;

static int ip_send(uint32_t dst, uint8_t proto, const uint8_t *pl, size_t len) {
    uint8_t pkt[1500];
    if (len > 1480) return -1;
    pkt[0] = 0x45; pkt[1] = 0;
    wr16(pkt + 2, (uint16_t)(20 + len)); wr16(pkt + 4, ip_id++); wr16(pkt + 6, 0x4000);
    pkt[8] = 64; pkt[9] = proto; wr16(pkt + 10, 0);
    wr32(pkt + 12, ni.ip); wr32(pkt + 16, dst);
    wr16(pkt + 10, csum(pkt, 20));
    memcpy(pkt + 20, pl, len);
    uint8_t mac[6];
    if (dst == 0xFFFFFFFF || !ni.ip) memcpy(mac, BCAST, 6);
    else {
        uint32_t hop = ((dst ^ ni.ip) & ni.mask) == 0 ? dst : ni.gw;
        if (!hop || !arp_resolve(hop, mac)) return -1;
    }
    return eth_send(mac, 0x0800, pkt, 20 + len);
}

/* ---------- ICMP ---------- */

static volatile int ping_got;
static uint16_t ping_seq;
#define PING_ID 0x4C4D

static void icmp_rx(uint32_t src, const uint8_t *p, size_t n) {
    if (n < 8) return;
    if (p[0] == 8) {                                   /* нас пингуют — отвечаем */
        uint8_t r[1480];
        if (n > sizeof r) return;
        memcpy(r, p, n);
        r[0] = 0; wr16(r + 2, 0); wr16(r + 2, csum(r, n));
        ip_send(src, 1, r, n);
    } else if (p[0] == 0 && rd16(p + 4) == PING_ID && rd16(p + 6) == ping_seq) {
        ping_got = 1;
    }
}

int net_ping(uint32_t ip, int timeout_ms, int *rtt_ms) {
    uint8_t p[40];
    if (!ni.configured) return -1;
    p[0] = 8; p[1] = 0; wr16(p + 2, 0); wr16(p + 4, PING_ID); wr16(p + 6, ++ping_seq);
    for (int i = 0; i < 32; i++) p[8 + i] = (uint8_t)(0x61 + i % 23);
    wr16(p + 2, csum(p, 40));
    ping_got = 0;
    uint64_t t0 = timer_ticks;
    if (ip_send(ip, 1, p, 40) < 0) return -1;
    uint64_t dl = deadline_ms(timeout_ms);
    while (timer_ticks < dl) {
        net_poll();
        if (ping_got) { *rtt_ms = (int)((timer_ticks - t0) * 1000 / TIMER_HZ); return 0; }
    }
    return -2;
}

/* ---------- DHCP и DNS (поверх UDP) ---------- */

static int udp_send(uint32_t dst, uint16_t sp, uint16_t dp, const uint8_t *d, size_t n) {
    uint8_t b[1480];
    if (n + 8 > sizeof b) return -1;
    wr16(b, sp); wr16(b + 2, dp); wr16(b + 4, (uint16_t)(8 + n)); wr16(b + 6, 0);
    memcpy(b + 8, d, n);
    return ip_send(dst, 17, b, 8 + n);
}

static uint32_t dhcp_xid, d_ip, d_mask, d_gw, d_dns, d_srv;
static volatile int dhcp_stage;     /* 1 — DISCOVER отправлен, 2 — получен OFFER, 3 — REQUEST отправлен, 4 — получен ACK */

static size_t dhcp_build(uint8_t *b, uint8_t type) {
    memset(b, 0, 300);
    b[0] = 1; b[1] = 1; b[2] = 6;
    wr32(b + 4, dhcp_xid); wr16(b + 10, 0x8000);
    memcpy(b + 28, ni.mac, 6);
    b[236] = 99; b[237] = 130; b[238] = 83; b[239] = 99;
    uint8_t *o = b + 240;
    *o++ = 53; *o++ = 1; *o++ = type;
    if (type == 3) {
        *o++ = 50; *o++ = 4; wr32(o, d_ip); o += 4;
        *o++ = 54; *o++ = 4; wr32(o, d_srv); o += 4;
    }
    *o++ = 55; *o++ = 4; *o++ = 1; *o++ = 3; *o++ = 6; *o++ = 15;
    *o++ = 255;
    return 300;
}

static void dhcp_rx(const uint8_t *d, size_t n) {
    if (n < 241 || d[0] != 2 || rd32(d + 4) != dhcp_xid || d[236] != 99 || d[237] != 130) return;
    if (memcmp(d + 28, ni.mac, 6) != 0) return;
    int type = 0;
    uint32_t mask = 0, gw = 0, dns = 0, srv = 0;
    for (size_t o = 240; o + 1 < n;) {
        uint8_t code = d[o];
        if (code == 255) break;
        if (code == 0) { o++; continue; }
        uint8_t len = d[o + 1];
        if (o + 2 + len > n) break;
        const uint8_t *v = d + o + 2;
        switch (code) {
        case 53: type = v[0]; break;
        case 1:  if (len >= 4) mask = rd32(v); break;
        case 3:  if (len >= 4) gw = rd32(v); break;
        case 6:  if (len >= 4) dns = rd32(v); break;
        case 54: if (len >= 4) srv = rd32(v); break;
        default: break;
        }
        o += 2 + (size_t)len;
    }
    if (type == 2 && dhcp_stage == 1) {
        d_ip = rd32(d + 16); d_mask = mask; d_gw = gw; d_dns = dns; d_srv = srv; dhcp_stage = 2;
    } else if (type == 5 && dhcp_stage == 3) {
        d_ip = rd32(d + 16);
        if (mask) d_mask = mask;
        if (gw) d_gw = gw;
        if (dns) d_dns = dns;
        dhcp_stage = 4;
    }
}

int net_dhcp(void) {
    uint8_t b[300];
    if (!ni.present) return -1;
    ni.ip = 0; ni.mask = 0; ni.gw = 0; ni.dns = 0; ni.configured = 0;
    for (int attempt = 0; attempt < 3; attempt++) {
        dhcp_xid = 0x4C494D4Fu ^ (uint32_t)timer_ticks ^ (uint32_t)attempt;
        dhcp_stage = 1;
        udp_send(0xFFFFFFFF, 68, 67, b, dhcp_build(b, 1));
        uint64_t dl = deadline_ms(2000);
        while (timer_ticks < dl && dhcp_stage != 2) net_poll();
        if (dhcp_stage != 2) continue;
        dhcp_stage = 3;
        udp_send(0xFFFFFFFF, 68, 67, b, dhcp_build(b, 3));
        dl = deadline_ms(2000);
        while (timer_ticks < dl && dhcp_stage != 4) net_poll();
        if (dhcp_stage != 4) continue;
        ni.ip = d_ip; ni.mask = d_mask ? d_mask : 0xFFFFFF00; ni.gw = d_gw; ni.dns = d_dns ? d_dns : d_gw;
        ni.configured = 1;
        return 0;
    }
    return -2;
}

static uint16_t dns_id, dns_sport;
static volatile int dns_state;      /* 1 — ответ получен, -1 — ошибка */
static uint32_t dns_ip;

static const uint8_t *skip_name(const uint8_t *p, const uint8_t *end) {
    while (p < end) {
        uint8_t l = *p;
        if (l == 0) return p + 1;
        if ((l & 0xC0) == 0xC0) return p + 2 <= end ? p + 2 : 0;
        p += (size_t)l + 1;
    }
    return 0;
}

static void dns_rx(const uint8_t *d, size_t n) {
    if (n < 12 || rd16(d) != dns_id) return;
    uint16_t fl = rd16(d + 2);
    if (!(fl & 0x8000)) return;
    if ((fl & 0xF) != 0) { dns_state = -1; return; }
    uint16_t qd = rd16(d + 4), an = rd16(d + 6);
    const uint8_t *p = d + 12, *end = d + n;
    for (int i = 0; i < qd; i++) {
        p = skip_name(p, end);
        if (!p || p + 4 > end) { dns_state = -1; return; }
        p += 4;
    }
    for (int i = 0; i < an; i++) {
        p = skip_name(p, end);
        if (!p || p + 10 > end) break;
        uint16_t t = rd16(p), rl = rd16(p + 8);
        p += 10;
        if (p + rl > end) break;
        if (t == 1 && rl == 4) { dns_ip = rd32(p); dns_state = 1; return; }
        p += rl;
    }
    dns_state = -1;
}

static void udp_rx(const uint8_t *p, size_t n) {
    if (n < 8) return;
    uint16_t dp = rd16(p + 2), len = rd16(p + 4);
    if (len < 8 || len > n) return;
    if (dp == 68) dhcp_rx(p + 8, len - 8);
    else if (dp == dns_sport) dns_rx(p + 8, len - 8);
}

int net_parse_ip(const char *s, uint32_t *ip) {
    uint32_t v = 0;
    for (int part = 0; part < 4; part++) {
        if (*s < '0' || *s > '9') return -1;
        uint32_t o = 0;
        while (*s >= '0' && *s <= '9') { o = o * 10 + (uint32_t)(*s++ - '0'); if (o > 255) return -1; }
        v = (v << 8) | o;
        if (part < 3) { if (*s != '.') return -1; s++; }
    }
    if (*s) return -1;
    *ip = v;
    return 0;
}

void net_ip_str(uint32_t ip, char out[16]) {
    int n = 0;
    for (int i = 3; i >= 0; i--) {
        unsigned v = (ip >> (i * 8)) & 255;
        char t[3]; int k = 0;
        do { t[k++] = (char)('0' + v % 10); v /= 10; } while (v);
        while (k) out[n++] = t[--k];
        if (i) out[n++] = '.';
    }
    out[n] = 0;
}

int net_resolve(const char *host, uint32_t *ip_out) {
    if (net_parse_ip(host, ip_out) == 0) return 0;
    if (!ni.configured || !ni.dns) return -1;
    size_t hl = strlen(host);
    if (hl == 0 || hl > 200) return -1;
    static uint16_t counter;
    for (int attempt = 0; attempt < 3; attempt++) {
        uint8_t q[300];
        counter++;
        dns_id = (uint16_t)(0x4C00 + counter);
        dns_sport = (uint16_t)(49152 + (counter & 0xFF));
        memset(q, 0, 12);
        wr16(q, dns_id); wr16(q + 2, 0x0100); wr16(q + 4, 1);
        size_t o = 12;
        const char *p = host;
        while (*p) {
            const char *dot = p;
            while (*dot && *dot != '.') dot++;
            size_t l = (size_t)(dot - p);
            if (l == 0 || l > 63) return -1;
            q[o++] = (uint8_t)l;
            memcpy(q + o, p, l); o += l;
            p = *dot ? dot + 1 : dot;
        }
        q[o++] = 0;
        wr16(q + o, 1); wr16(q + o + 2, 1); o += 4;
        dns_state = 0;
        if (udp_send(ni.dns, dns_sport, 53, q, o) < 0) continue;
        uint64_t dl = deadline_ms(2000);
        while (timer_ticks < dl && dns_state == 0) net_poll();
        if (dns_state == 1) { *ip_out = dns_ip; return 0; }
        if (dns_state == -1) return -3;
    }
    return -2;
}

/* ---------- TCP ---------- */
/* Клиент: у каждого соединения свой приёмный буфер (32 КБ), данные не теряются, пока их не читают;
   окно приёма честное (не больше, чем влезает в кольцо сетевой карты); потерянные/повторные/
   переставленные сегменты не ломают поток (отвечаем повторным ACK — сервер пришлёт заново).
   Пока НЕТ: повторной отправки НАШИХ сегментов (в NAT VirtualBox/QEMU потерь почти не бывает). */

#define TCP_MAX     4
#define TCP_RXCAP   32768
#define TCP_WIN_MAX 14600          /* 10 сегментов: кольцо e1000 на 32 пакета не переполнится */
enum { TCP_CLOSED = 0, TCP_SYN_SENT, TCP_ESTABLISHED, TCP_RESET };

struct tcp_conn {
    int state;
    uint32_t rip;
    uint16_t rport, lport;
    uint32_t seq;         /* следующий байт, который отправим */
    uint32_t ack;         /* следующий байт, который ждём от собеседника */
    uint8_t *rx;          /* приёмный буфер */
    size_t   rxlen;
    int got_fin;
};
static struct tcp_conn tcpc[TCP_MAX];
static uint16_t tcp_lport = 0xC000;

static uint16_t tcp_checksum(uint32_t src, uint32_t dst, const uint8_t *seg, size_t seglen) {
    uint8_t buf[12 + 1480];
    if (seglen > 1480) seglen = 1480;
    wr32(buf, src); wr32(buf + 4, dst);
    buf[8] = 0; buf[9] = 6; wr16(buf + 10, (uint16_t)seglen);
    memcpy(buf + 12, seg, seglen);
    return csum(buf, 12 + seglen);
}

static int tcp_send_seg(struct tcp_conn *c, uint8_t flags, const uint8_t *data, size_t dlen) {
    uint8_t seg[20 + 1460];
    if (dlen > 1460) return -1;
    size_t room = c->rx ? TCP_RXCAP - c->rxlen : 0;
    if (room > TCP_WIN_MAX) room = TCP_WIN_MAX;
    wr16(seg, c->lport); wr16(seg + 2, c->rport);
    wr32(seg + 4, c->seq); wr32(seg + 8, (flags & 0x10) ? c->ack : 0);
    seg[12] = 5 << 4; seg[13] = flags; wr16(seg + 14, (uint16_t)room); wr16(seg + 16, 0); wr16(seg + 18, 0);
    if (dlen) memcpy(seg + 20, data, dlen);
    wr16(seg + 16, tcp_checksum(ni.ip, c->rip, seg, 20 + dlen));
    return ip_send(c->rip, 6, seg, 20 + dlen);
}

static int tcp_alloc(void) {
    for (int i = 0; i < TCP_MAX; i++) if (tcpc[i].state == TCP_CLOSED) return i;
    return -1;
}

static void tcp_rx(uint32_t src, const uint8_t *p, size_t n) {
    if (n < 20) return;
    uint16_t sport = rd16(p), dport = rd16(p + 2);
    uint32_t seq = rd32(p + 4), ackn = rd32(p + 8);
    size_t doff = (size_t)(p[12] >> 4) * 4;
    uint8_t flags = p[13];
    if (doff < 20 || doff > n) return;
    const uint8_t *data = p + doff;
    size_t dlen = n - doff;

    struct tcp_conn *c = NULL;
    for (int i = 0; i < TCP_MAX; i++)
        if (tcpc[i].state != TCP_CLOSED && tcpc[i].rip == src && tcpc[i].rport == sport && tcpc[i].lport == dport)
            { c = &tcpc[i]; break; }
    if (!c) return;
    if (flags & 0x04) { c->state = TCP_RESET; c->got_fin = 1; return; }       /* RST */

    if (c->state == TCP_SYN_SENT) {
        if ((flags & 0x12) == 0x12 && ackn == c->seq + 1) {                   /* SYN+ACK на наш SYN */
            c->ack = seq + 1;
            c->seq = c->seq + 1;
            c->state = TCP_ESTABLISHED;
            tcp_send_seg(c, 0x10, NULL, 0);
        }
        return;
    }
    if (c->state != TCP_ESTABLISHED) return;

    int fin = (flags & 0x01) != 0;
    if (dlen == 0 && !fin) return;                       /* чистый ACK от сервера */

    int32_t diff = (int32_t)(seq - c->ack);
    if (diff > 0) { tcp_send_seg(c, 0x10, NULL, 0); return; }      /* дыра: просим повторить с нужного места */
    if (diff < 0) {                                                   /* повтор или перекрытие */
        uint32_t skip = (uint32_t)(-diff);
        if (skip >= dlen + (fin ? 1u : 0u)) { tcp_send_seg(c, 0x10, NULL, 0); return; }   /* всё это уже есть */
        data += skip; dlen -= skip;
    }
    size_t room = TCP_RXCAP - c->rxlen;
    size_t take = dlen < room ? dlen : room;
    if (take) { memcpy(c->rx + c->rxlen, data, take); c->rxlen += take; c->ack += (uint32_t)take; }
    if (take < dlen) fin = 0;                           /* не всё влезло — остаток и FIN придут повторно */
    if (fin) { c->ack += 1; c->got_fin = 1; }
    tcp_send_seg(c, 0x10, NULL, 0);
}

int tcp_connect(uint32_t ip, uint16_t port, int timeout_ms) {
    int i = tcp_alloc();
    if (i < 0) return -1;
    struct tcp_conn *c = &tcpc[i];
    memset(c, 0, sizeof *c);
    c->rx = kmalloc(TCP_RXCAP);
    if (!c->rx) return -3;
    c->rip = ip; c->rport = port;
    c->lport = tcp_lport++;
    if (tcp_lport < 0xC000) tcp_lport = 0xC000;
    c->seq = 0x1000u + (uint32_t)timer_ticks * 7919u + port;
    c->state = TCP_SYN_SENT;
    int per_try = timeout_ms / 3; if (per_try < 200) per_try = 200;
    for (int attempt = 0; attempt < 3 && c->state == TCP_SYN_SENT; attempt++) {
        tcp_send_seg(c, 0x02, NULL, 0);
        uint64_t dl = deadline_ms(per_try);
        while (timer_ticks < dl && c->state == TCP_SYN_SENT) net_poll();
    }
    if (c->state != TCP_ESTABLISHED) { kfree(c->rx); c->rx = NULL; c->state = TCP_CLOSED; return -2; }
    return i;
}

int tcp_send(int id, const void *data, size_t len) {
    if (id < 0 || id >= TCP_MAX) return -1;
    struct tcp_conn *c = &tcpc[id];
    if (c->state != TCP_ESTABLISHED) return -2;
    const uint8_t *d = data;
    size_t sent = 0;
    while (sent < len) {
        size_t chunk = len - sent;
        if (chunk > 1400) chunk = 1400;
        if (tcp_send_seg(c, 0x18, d + sent, chunk) < 0) return -3;   /* PSH+ACK */
        c->seq += (uint32_t)chunk;
        sent += chunk;
        net_poll();                                                    /* заодно разбираем пришедшее */
    }
    return 0;
}

/* Отдаёт накопленное в буфере (ждёт до timeout_ms, если пока пусто). 0 — таймаут или конец (FIN/RST). */
int tcp_recv(int id, void *buf, size_t maxlen, int timeout_ms) {
    if (id < 0 || id >= TCP_MAX) return -1;
    struct tcp_conn *c = &tcpc[id];
    if (!c->rx) return -1;
    uint64_t dl = deadline_ms(timeout_ms);
    while (c->rxlen == 0 && !c->got_fin && timer_ticks < dl) net_poll();
    if (c->rxlen == 0) return 0;
    size_t n = c->rxlen < maxlen ? c->rxlen : maxlen;
    size_t was_free = TCP_RXCAP - c->rxlen;
    memcpy(buf, c->rx, n);
    memmove(c->rx, c->rx + n, c->rxlen - n);
    c->rxlen -= n;
    if (was_free < 2 * 1460 && c->state == TCP_ESTABLISHED) tcp_send_seg(c, 0x10, NULL, 0);   /* окно снова открылось */
    return (int)n;
}

int tcp_read_all(int id, void *buf, size_t maxlen, int timeout_ms) {
    if (id < 0 || id >= TCP_MAX) return -1;
    struct tcp_conn *c = &tcpc[id];
    size_t total = 0;
    uint64_t dl = deadline_ms(timeout_ms);
    while (total < maxlen && timer_ticks < dl) {
        int n = tcp_recv(id, (uint8_t *)buf + total, maxlen - total, 100);
        if (n > 0) total += (size_t)n;
        else if (c->got_fin && c->rxlen == 0) break;
    }
    return (int)total;
}

void tcp_close(int id) {
    if (id < 0 || id >= TCP_MAX) return;
    struct tcp_conn *c = &tcpc[id];
    if (c->state == TCP_ESTABLISHED) {
        tcp_send_seg(c, 0x11, NULL, 0);   /* FIN+ACK */
        c->seq += 1;
        uint64_t dl = deadline_ms(200);
        while (timer_ticks < dl) net_poll();
    }
    c->state = TCP_CLOSED;
    if (c->rx) { kfree(c->rx); c->rx = NULL; }
    c->rxlen = 0;
}

/* ---------- HTTP / HTTPS ---------- */

static int ci_contains(const char *s, const char *needle) {
    size_t nl = strlen(needle);
    for (; *s; s++) {
        size_t j = 0;
        for (; j < nl; j++) {
            char a = s[j]; if (!a) return 0;
            if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
            if (a != needle[j]) break;
        }
        if (j == nl) return 1;
    }
    return 0;
}

static int parse_status(const char *out, size_t n) {
    if (n >= 12 && memcmp(out, "HTTP/", 5) == 0) {
        const char *sp = out + 9;
        if (sp[0] >= '0' && sp[0] <= '9' && sp[1] >= '0' && sp[1] <= '9' && sp[2] >= '0' && sp[2] <= '9')
            return (sp[0] - '0') * 100 + (sp[1] - '0') * 10 + (sp[2] - '0');
    }
    return 0;
}

static size_t find_body(const char *out, size_t n) {
    for (size_t i = 0; i + 3 < n; i++)
        if (out[i] == '\r' && out[i + 1] == '\n' && out[i + 2] == '\r' && out[i + 3] == '\n') return i + 4;
    return 0;
}

int http_header(const char *r, size_t headers_len, const char *name, char *out, size_t outmax) {
    size_t nl = strlen(name);
    for (size_t i = 0; i + nl + 1 < headers_len; i++) {
        if (r[i] == '\n') {
            size_t s = i + 1, j = 0;
            for (; j < nl && s + j < headers_len; j++) {
                char a = r[s + j]; if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
                char b = name[j]; if (b >= 'A' && b <= 'Z') b = (char)(b + 32);
                if (a != b) break;
            }
            if (j == nl && s + j < headers_len && r[s + j] == ':') {
                size_t v = s + j + 1;
                while (v < headers_len && r[v] == ' ') v++;
                size_t o = 0;
                while (v < headers_len && r[v] != '\r' && r[v] != '\n' && o + 1 < outmax) out[o++] = r[v++];
                out[o] = 0;
                return 0;
            }
        }
    }
    return -1;
}

/* Ответ уже получен целиком? (чтобы не ждать таймаут, если сервер не закрывает соединение) */
static int http_complete(const char *r, size_t n) {
    size_t bo = find_body(r, n);
    if (!bo) return 0;
    int st = parse_status(r, n);
    if (st == 204 || st == 304 || (st >= 100 && st < 200)) return 1;
    char v[48];
    if (http_header(r, bo, "Transfer-Encoding", v, sizeof v) == 0 && ci_contains(v, "chunked"))
        return n >= bo + 5 && memcmp(r + n - 5, "0\r\n\r\n", 5) == 0;
    if (http_header(r, bo, "Content-Length", v, sizeof v) == 0) {
        size_t len = 0; for (const char *q = v; *q >= '0' && *q <= '9'; q++) len = len * 10 + (size_t)(*q - '0');
        return n - bo >= len;
    }
    return 0;
}

static void fill_result(char *out, size_t total, int *status, size_t *body_off) {
    out[total] = 0;
    if (status) *status = parse_status(out, total);
    if (body_off) *body_off = find_body(out, total);
}

/* UA вида "Lynx/..." в открытую называет нас текстовым браузером без JS — и именно поэтому
 * Google теперь вообще отказывает в поиске (с 2025 года ему жёстко нужен JS, никакой UA это
 * не обойдёт), а html.duckduckgo.com отвечает 403: многие сайты банят по заголовкам именно
 * нераспознанные/"консольные" UA. Обычная практика любого минималистичного клиента (как и у
 * настоящего Lynx, когда он утыкается в такое) — представиться как современный браузер; это
 * не обман сайта в чём-то вредном, страница просто перестаёт откатываться в "блокировку старых
 * браузеров". YouTube это всё равно не откроет — ему нужен не UA, а реальный JS-движок и видео-
 * кодеки, которых у Citrus нет и в обозримом будущем не будет. */
static int build_request(char *req, size_t cap, const char *host, const char *path) {
    return ksnprintf(req, cap,
        "GET %s HTTP/1.1\r\nHost: %s\r\n"
        "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36\r\n"
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
        "Accept-Language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n", path, host);
}

int http_get(const char *host, uint16_t port, const char *path,
             char *out, size_t outmax, int *status, size_t *body_off) {
    uint32_t ip;
    if (net_resolve(host, &ip) != 0) return -1;
    int id = tcp_connect(ip, port, 4000);
    if (id < 0) return -2;
    char req[1024];
    int rn = build_request(req, sizeof req, host, path);
    tcp_send(id, req, (size_t)rn);
    size_t total = 0;
    while (outmax > 1 && total + 1 < outmax) {
        int n = tcp_recv(id, out + total, outmax - 1 - total, 6000);
        if (n <= 0) break;
        total += (size_t)n;
        if (http_complete(out, total)) break;
    }
    tcp_close(id);
    fill_result(out, total, status, body_off);
    return (int)total;
}

/* ---------- HTTPS (TLS 1.3 поверх tcp_send/tcp_recv) ---------- */

static int last_tls_err, last_tls_alert;
int net_last_tls_error(void) { return last_tls_err; }
int net_last_tls_alert(void) { return last_tls_alert; }

static int tls_io_send(void *ctx, const uint8_t *data, size_t len) {
    int id = *(int *)ctx;
    return tcp_send(id, data, len) == 0 ? 0 : -1;
}
static int tls_io_recv(void *ctx, uint8_t *buf, size_t len, int timeout_ms) {
    int id = *(int *)ctx;
    int n = tcp_recv(id, buf, len, timeout_ms);
    return n > 0 ? n : 0;
}

/* Ошибки: -1 нет DNS, -2 нет соединения, -3 нет памяти, а ошибка TLS r (отрицательная) -> -100 + r.
 * (раньше было -10 - r: все ошибки TLS попадали в -9..-5 и показывались как «нет ответа») */
int https_get(const char *host, const char *path, char *out, size_t outmax, int *status, size_t *body_off) {
    uint32_t ip;
    last_tls_err = 0; last_tls_alert = 0;
    if (net_resolve(host, &ip) != 0) return -1;
    int id = tcp_connect(ip, 443, 4000);
    if (id < 0) return id == -3 ? -3 : -2;

    struct tls_conn tc;
    int r = tls_connect(&tc, tls_io_send, tls_io_recv, &id, host);
    if (r != TLS_OK) {
        last_tls_err = r; last_tls_alert = tc.alert_code;
        tls_close(&tc); tcp_close(id);
        return -100 + r;
    }

    char req[1024];
    int rn = build_request(req, sizeof req, host, path);
    tls_write(&tc, (const uint8_t *)req, (size_t)rn);

    size_t total = 0;
    while (outmax > 1 && total + 1 < outmax) {
        int n = tls_read(&tc, (uint8_t *)out + total, outmax - 1 - total, 6000);
        if (n <= 0) break;
        total += (size_t)n;
        if (http_complete(out, total)) break;
    }
    tls_close(&tc);
    tcp_close(id);
    fill_result(out, total, status, body_off);
    return (int)total;
}

void net_describe_error(int n, char *out, size_t max) {
    if (n == -1) ksnprintf(out, max, "Не удалось узнать адрес сайта (DNS)");
    else if (n == -2) ksnprintf(out, max, "Нет соединения: сервер не отвечает или порт закрыт");
    else if (n == -3) ksnprintf(out, max, "Не хватило памяти");
    else if (n <= -100) {
        int r = n + 100;
        if (r == TLS_ERR_ALERT) ksnprintf(out, max, "TLS: сервер отклонил соединение (alert %d)", net_last_tls_alert());
        else ksnprintf(out, max, "TLS: %s", tls_err_str(r));
    } else ksnprintf(out, max, "Сервер ничего не ответил");
}

/* ---------- web_get: URL целиком, переходы (301/302/303/307/308), сборка chunked ---------- */

struct url { int tls; uint16_t port; char host[64]; char path[640]; };

static int url_parse(const char *s, struct url *u) {
    memset(u, 0, sizeof *u);
    u->port = 80;
    if (strncmp(s, "https://", 8) == 0) { u->tls = 1; u->port = 443; s += 8; }
    else if (strncmp(s, "http://", 7) == 0) s += 7;
    size_t h = 0;
    while (*s && *s != '/' && *s != ':' && h < sizeof u->host - 1) u->host[h++] = *s++;
    u->host[h] = 0;
    if (h == 0) return -1;
    if (*s == ':') { s++; unsigned p = 0; while (*s >= '0' && *s <= '9') p = p * 10 + (unsigned)(*s++ - '0'); if (p) u->port = (uint16_t)p; }
    if (*s != '/') { u->path[0] = '/'; u->path[1] = 0; }
    else { size_t n = 0; while (*s && n < sizeof u->path - 1) u->path[n++] = *s++; u->path[n] = 0; }
    return 0;
}

static void url_str(const struct url *u, char *out, size_t max) {
    int def = u->tls ? 443 : 80;
    if (u->port == def) ksnprintf(out, max, "%s://%s%s", u->tls ? "https" : "http", u->host, u->path);
    else ksnprintf(out, max, "%s://%s:%d%s", u->tls ? "https" : "http", u->host, (int)u->port, u->path);
}

/* склеивает адрес перехода с текущим */
static int url_redirect(struct url *u, const char *loc) {
    if (strncmp(loc, "http://", 7) == 0 || strncmp(loc, "https://", 8) == 0) return url_parse(loc, u);
    if (loc[0] == '/' && loc[1] == '/') {
        char tmp[700]; ksnprintf(tmp, sizeof tmp, "%s:%s", u->tls ? "https" : "http", loc);
        return url_parse(tmp, u);
    }
    if (loc[0] == '/') { size_t n = 0; while (loc[n] && n < sizeof u->path - 1) { u->path[n] = loc[n]; n++; } u->path[n] = 0; return 0; }
    /* относительный путь: заменяем последний сегмент */
    size_t last = 0; for (size_t i = 0; u->path[i]; i++) if (u->path[i] == '/') last = i;
    size_t n = last + 1;
    for (size_t i = 0; loc[i] && n < sizeof u->path - 1; i++) u->path[n++] = loc[i];
    u->path[n] = 0;
    return 0;
}

/* склеивает base и ссылку ref (как браузер); фрагмент #... отбрасывается */
int net_url_join(const char *base, const char *ref, char *out, size_t max) {
    struct url u;
    if (url_parse(base, &u) != 0) return -1;
    char r[640]; size_t k = 0;
    while (ref[k] && ref[k] != '#' && k < sizeof r - 1) { r[k] = ref[k]; k++; }
    r[k] = 0;
    if (r[0] == '?') {                                    /* только запрос: путь тот же */
        size_t p = 0; while (u.path[p] && u.path[p] != '?') p++;
        size_t j = 0; while (r[j] && p + j < sizeof u.path - 1) { u.path[p + j] = r[j]; j++; }
        u.path[p + j] = 0;
    } else if (r[0] && url_redirect(&u, r) != 0) return -1;
    url_str(&u, out, max);
    return 0;
}

/* разбирает Transfer-Encoding: chunked прямо в буфере; возвращает новую общую длину */
static size_t dechunk(char *out, size_t body_off, size_t total) {
    size_t rd = body_off, wr = body_off;
    while (rd < total) {
        size_t len = 0; int any = 0;
        while (rd < total && out[rd] != '\r' && out[rd] != '\n' && out[rd] != ';') {
            char ch = out[rd]; int d;
            if (ch >= '0' && ch <= '9') d = ch - '0';
            else if ((ch | 32) >= 'a' && (ch | 32) <= 'f') d = (ch | 32) - 'a' + 10;
            else break;
            len = len * 16 + (size_t)d; any = 1; rd++;
        }
        if (!any) break;
        while (rd < total && out[rd] != '\n') rd++;
        rd++;                                              /* после LF начинаются данные */
        if (len == 0) break;
        if (rd + len > total) len = total - rd;            /* оборванный ответ — берём что есть */
        memmove(out + wr, out + rd, len);
        wr += len; rd += len;
        if (rd < total && out[rd] == '\r') rd++;
        if (rd < total && out[rd] == '\n') rd++;
    }
    out[wr] = 0;
    return wr;
}

int web_get(const char *url_in, char *out, size_t outmax, int *status, size_t *body_off,
            char *final_url, size_t final_max) {
    struct url u;
    if (url_parse(url_in, &u) != 0) return -1;
    for (int hop = 0; hop < 6; hop++) {
        int st = 0; size_t bo = 0;
        int n = u.tls ? https_get(u.host, u.path, out, outmax, &st, &bo)
                      : http_get(u.host, u.port, u.path, out, outmax, &st, &bo);
        if (final_url) url_str(&u, final_url, final_max);
        if (n <= 0) { if (status) *status = 0; if (body_off) *body_off = 0; return n; }
        if ((st == 301 || st == 302 || st == 303 || st == 307 || st == 308) && bo) {
            char loc[640];
            if (http_header(out, bo, "Location", loc, sizeof loc) == 0 && url_redirect(&u, loc) == 0) continue;
        }
        char te[48];
        if (bo && http_header(out, bo, "Transfer-Encoding", te, sizeof te) == 0 && ci_contains(te, "chunked"))
            n = (int)dechunk(out, bo, (size_t)n);
        if (status) *status = st;
        if (body_off) *body_off = bo;
        return n;
    }
    if (status) *status = 310;                              /* слишком много переходов */
    if (body_off) *body_off = 0;
    return 0;
}

/* ---------- приём ---------- */

static void ip_rx(const uint8_t *p, size_t n) {
    if (n < 20 || (p[0] >> 4) != 4) return;
    size_t ihl = (size_t)(p[0] & 15) * 4;
    if (ihl < 20 || n < ihl) return;
    size_t tl = rd16(p + 2);
    if (tl < ihl || tl > n) return;
    if (csum(p, ihl) != 0) return;
    uint32_t dst = rd32(p + 16);
    if (ni.ip && dst != ni.ip && dst != 0xFFFFFFFF) return;
    if (rd16(p + 6) & 0x3FFF) return;                  /* фрагменты пока не собираем */
    uint32_t src = rd32(p + 12);
    const uint8_t *pl = p + ihl;
    size_t len = tl - ihl;
    if (p[9] == 1) icmp_rx(src, pl, len);
    else if (p[9] == 17) udp_rx(pl, len);
    else if (p[9] == 6) tcp_rx(src, pl, len);
}

void net_poll(void) {
    if (!ni.present) return;
    for (int i = 0; i < 16; i++) {
        int n = nic_recv(rxb, sizeof rxb);
        if (n < 14) break;
        uint16_t type = rd16(rxb + 12);
        if (type == 0x0806) arp_rx(rxb + 14, (size_t)n - 14);
        else if (type == 0x0800) ip_rx(rxb + 14, (size_t)n - 14);
    }
}

int net_init(void) {
    if (nic_init() != 0) return -1;
    ni.present = 1;
    memcpy(ni.mac, nic_mac(), 6);
    ni.nic = nic_name();
    return 0;
}

const struct netinfo *net_info(void) {
    ni.link = ni.present ? nic_link() : 0;
    return &ni;
}
