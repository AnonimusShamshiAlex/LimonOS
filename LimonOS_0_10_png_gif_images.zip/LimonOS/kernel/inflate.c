#include "inflate.h"

/* Канонический Хаффман (RFC 1951, §3.2.2): по длине кода каждого символа строим
 * для каждой длины код первого символа этой длины и таблицу символов, упорядоченную
 * так, что коды одной длины идут подряд по возрастанию значения кода. */
struct huff { uint16_t count[16]; uint16_t symbol[288]; };

struct state {
    const uint8_t *in; size_t inlen, inpos;
    uint32_t bitbuf; int bitcnt;
    uint8_t *out; size_t outcap, outpos;
    int err;
};

static int getbit(struct state *s) {
    if (s->bitcnt == 0) {
        if (s->inpos >= s->inlen) { s->err = INFL_ERR_INPUT; return 0; }
        s->bitbuf = s->in[s->inpos++];
        s->bitcnt = 8;
    }
    int bit = (int)(s->bitbuf & 1);
    s->bitbuf >>= 1; s->bitcnt--;
    return bit;
}

static uint32_t getbits(struct state *s, int n) {
    uint32_t v = 0;
    for (int i = 0; i < n; i++) v |= (uint32_t)getbit(s) << i;
    return v;
}

static void build_huff(struct huff *h, const uint8_t *lengths, int n) {
    for (int i = 0; i < 16; i++) h->count[i] = 0;
    for (int i = 0; i < n; i++) h->count[lengths[i]]++;
    h->count[0] = 0;
    uint16_t offs[16]; offs[0] = 0; offs[1] = 0;
    for (int len = 1; len < 15; len++) offs[len + 1] = (uint16_t)(offs[len] + h->count[len]);
    for (int i = 0; i < n; i++) if (lengths[i]) h->symbol[offs[lengths[i]]++] = (uint16_t)i;
}

/* Читает биты по одному и идёт по длинам кода 1..15, пока значение не попадёт
 * в диапазон кодов этой длины — так за один проход декодируется ровно один символ. */
static int decode_sym(struct state *s, const struct huff *h) {
    int code = 0, first = 0, index = 0;
    for (int len = 1; len <= 15; len++) {
        code |= getbit(s);
        int count = h->count[len];
        if (code - first < count) return h->symbol[index + (code - first)];
        index += count;
        first += count;
        first <<= 1;
        code <<= 1;
        if (s->err) return -1;
    }
    return -1;
}

static void out_byte(struct state *s, uint8_t b) {
    if (s->outpos >= s->outcap) { s->err = INFL_ERR_OUTPUT; return; }
    s->out[s->outpos++] = b;
}

static const uint16_t LEN_BASE[29]  = { 3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258 };
static const uint8_t  LEN_EXTRA[29] = { 0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0 };
static const uint16_t DIST_BASE[30]  = { 1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577 };
static const uint8_t  DIST_EXTRA[30] = { 0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13 };
static const uint8_t  CLEN_ORDER[19] = { 16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15 };

static void inflate_block_data(struct state *s, const struct huff *lit, const struct huff *dist) {
    for (;;) {
        int sym = decode_sym(s, lit);
        if (s->err || sym < 0) { s->err = s->err ? s->err : INFL_ERR_CODE; return; }
        if (sym < 256) { out_byte(s, (uint8_t)sym); if (s->err) return; continue; }
        if (sym == 256) return;                      /* конец блока */
        sym -= 257;
        if (sym >= 29) { s->err = INFL_ERR_CODE; return; }
        uint32_t len = LEN_BASE[sym] + getbits(s, LEN_EXTRA[sym]);
        int dsym = decode_sym(s, dist);
        if (s->err || dsym < 0 || dsym >= 30) { s->err = s->err ? s->err : INFL_ERR_CODE; return; }
        uint32_t distance = DIST_BASE[dsym] + getbits(s, DIST_EXTRA[dsym]);
        if (distance > s->outpos) { s->err = INFL_ERR_OUTPUT; return; }
        size_t from = s->outpos - distance;
        for (uint32_t i = 0; i < len; i++) {           /* побайтно: источник и цель могут перекрываться */
            if (s->outpos >= s->outcap) { s->err = INFL_ERR_OUTPUT; return; }
            s->out[s->outpos] = s->out[from + i];
            s->outpos++;
        }
    }
}

static void fixed_trees(struct huff *lit, struct huff *dist) {
    uint8_t ll[288];
    int i = 0;
    for (; i < 144; i++) ll[i] = 8;
    for (; i < 256; i++) ll[i] = 9;
    for (; i < 280; i++) ll[i] = 7;
    for (; i < 288; i++) ll[i] = 8;
    build_huff(lit, ll, 288);
    uint8_t dl[30];
    for (i = 0; i < 30; i++) dl[i] = 5;
    build_huff(dist, dl, 30);
}

static void dynamic_trees(struct state *s, struct huff *lit, struct huff *dist) {
    int hlit = (int)getbits(s, 5) + 257;
    int hdist = (int)getbits(s, 5) + 1;
    int hclen = (int)getbits(s, 4) + 4;
    if (s->err) return;
    uint8_t clen[19] = { 0 };
    for (int i = 0; i < hclen; i++) clen[CLEN_ORDER[i]] = (uint8_t)getbits(s, 3);
    struct huff clh; build_huff(&clh, clen, 19);

    uint8_t lengths[288 + 32]; int n = 0;
    int total = hlit + hdist;
    while (n < total) {
        int sym = decode_sym(s, &clh);
        if (s->err || sym < 0) { s->err = s->err ? s->err : INFL_ERR_CODE; return; }
        if (sym < 16) { lengths[n++] = (uint8_t)sym; continue; }
        int rep; uint8_t val;
        if (sym == 16) { if (n == 0) { s->err = INFL_ERR_CODE; return; } val = lengths[n - 1]; rep = 3 + (int)getbits(s, 2); }
        else if (sym == 17) { val = 0; rep = 3 + (int)getbits(s, 3); }
        else { val = 0; rep = 11 + (int)getbits(s, 7); }
        while (rep-- > 0 && n < total) lengths[n++] = val;
    }
    if (s->err || n != total) { s->err = s->err ? s->err : INFL_ERR_CODE; return; }
    build_huff(lit, lengths, hlit);
    build_huff(dist, lengths + hlit, hdist);
}

int inflate_raw(const uint8_t *src, size_t srclen, uint8_t *dst, size_t dstcap, size_t *outlen) {
    struct state s = { src, srclen, 0, 0, 0, dst, dstcap, 0, 0 };
    int final = 0;
    while (!final) {
        final = getbit(&s);
        int btype = (int)getbits(&s, 2);
        if (s.err) { if (outlen) *outlen = s.outpos; return s.err; }
        if (btype == 0) {
            s.bitbuf = 0; s.bitcnt = 0;                 /* до границы байта */
            if (s.inpos + 4 > s.inlen) { if (outlen) *outlen = s.outpos; return INFL_ERR_INPUT; }
            uint32_t len = (uint32_t)s.in[s.inpos] | ((uint32_t)s.in[s.inpos + 1] << 8);
            s.inpos += 4;                                /* LEN (2) + NLEN (2), NLEN не перепроверяем */
            if (s.inpos + len > s.inlen) { if (outlen) *outlen = s.outpos; return INFL_ERR_INPUT; }
            for (uint32_t i = 0; i < len; i++) { out_byte(&s, s.in[s.inpos + i]); if (s.err) { if (outlen) *outlen = s.outpos; return s.err; } }
            s.inpos += len;
        } else if (btype == 1 || btype == 2) {
            struct huff lit, dist;
            if (btype == 1) fixed_trees(&lit, &dist);
            else { dynamic_trees(&s, &lit, &dist); if (s.err) { if (outlen) *outlen = s.outpos; return s.err; } }
            inflate_block_data(&s, &lit, &dist);
            if (s.err) { if (outlen) *outlen = s.outpos; return s.err; }
        } else {
            if (outlen) *outlen = s.outpos;
            return INFL_ERR_UNSUPPORTED;
        }
    }
    if (outlen) *outlen = s.outpos;
    return INFL_OK;
}
