#ifndef LIMON_INFLATE_H
#define LIMON_INFLATE_H
#include <stddef.h>
#include <stdint.h>

/* Свой декодер DEFLATE (RFC 1951) — то, чем сжаты данные внутри PNG (чанки IDAT,
 * без 2-байтного zlib-заголовка и 4-байтного Adler32 в конце — это снимает вызывающий
 * код, см. image_png.c). Без внешних библиотек, как и всё остальное ядро.
 *
 * src/srclen — сжатые данные; dst/dstcap — куда пишем (это всегда данные известного
 * размера: PNG знает ширину/высоту/число каналов заранее). *outlen — сколько реально
 * записали. Возвращает 0 — успех, иначе код ошибки (см. INFL_ERR_*). */
int inflate_raw(const uint8_t *src, size_t srclen, uint8_t *dst, size_t dstcap, size_t *outlen);

enum {
    INFL_OK = 0,
    INFL_ERR_INPUT = 1,      /* обрезанный/битый поток */
    INFL_ERR_CODE = 2,       /* неверный код Хаффмана или данные блока */
    INFL_ERR_OUTPUT = 3,     /* не влезло в dstcap, либо back-reference за пределы начала */
    INFL_ERR_UNSUPPORTED = 4 /* заявленный, но не поддержанный тип блока */
};

#endif
