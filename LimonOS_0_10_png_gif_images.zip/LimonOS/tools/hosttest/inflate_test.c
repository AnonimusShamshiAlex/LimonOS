#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../../kernel/inflate.c"

static int fails;

static unsigned char *read_file(const char *path, long *len) {
    FILE *f = fopen(path, "rb");
    if (!f) { printf("FAIL: cannot open %s\n", path); fails++; return NULL; }
    fseek(f, 0, SEEK_END); *len = ftell(f); fseek(f, 0, SEEK_SET);
    unsigned char *buf = malloc((size_t)*len + 1);
    fread(buf, 1, (size_t)*len, f);
    fclose(f);
    return buf;
}

static void check_case(const char *name) {
    char p1[256], p2[256];
    snprintf(p1, sizeof p1, "fixtures/%s.raw", name);
    snprintf(p2, sizeof p2, "fixtures/%s.deflate", name);
    long rawlen, complen;
    unsigned char *expected = read_file(p1, &rawlen);
    unsigned char *compressed = read_file(p2, &complen);
    if (!expected || !compressed) return;

    size_t cap = (size_t)rawlen + 16;
    unsigned char *got = malloc(cap);
    size_t outlen = 0;
    int rc = inflate_raw(compressed, (size_t)complen, got, cap, &outlen);
    if (rc != INFL_OK) { printf("FAIL %-8s: inflate_raw returned %d (expected 0)\n", name, rc); fails++; }
    else if (outlen != (size_t)rawlen) { printf("FAIL %-8s: outlen=%zu expected=%ld\n", name, outlen, rawlen); fails++; }
    else if (rawlen > 0 && memcmp(got, expected, (size_t)rawlen) != 0) { printf("FAIL %-8s: content mismatch\n", name); fails++; }
    else printf("ok   %-8s (%ld -> %ld bytes)\n", name, complen, rawlen);

    free(expected); free(compressed); free(got);
}

/* Отдельно: слишком маленький dstcap должен аккуратно вернуться ошибкой, а не переполнить буфер */
static void check_overflow_guard(void) {
    long rawlen, complen;
    unsigned char *expected = read_file("fixtures/text.raw", &rawlen);
    unsigned char *compressed = read_file("fixtures/text.deflate", &complen);
    if (!expected || !compressed) return;
    unsigned char small[10];
    size_t outlen = 0;
    int rc = inflate_raw(compressed, (size_t)complen, small, sizeof small, &outlen);
    if (rc == INFL_OK) { printf("FAIL overflow: должен был отказать, а не поместиться в 10 байт\n"); fails++; }
    else printf("ok   overflow guard (код ошибки %d)\n", rc);
    free(expected); free(compressed);
}

int main(void) {
    const char *names[] = { "empty", "hello", "repeat", "text", "binary", "zeros", "stored" };
    for (size_t i = 0; i < sizeof names / sizeof names[0]; i++) check_case(names[i]);
    check_overflow_guard();
    if (fails == 0) printf("все проверки inflate (DEFLATE) пройдены\n");
    return fails ? 1 : 0;
}
