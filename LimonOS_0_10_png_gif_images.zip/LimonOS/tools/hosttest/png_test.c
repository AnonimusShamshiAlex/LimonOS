#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void *kmalloc(size_t n) { return malloc(n); }
void  kfree(void *p) { free(p); }
#include "../../kernel/inflate.c"
#include "../../kernel/image_png.c"

void image_free(struct img_rgb *im) { if (im->pix) kfree(im->pix); im->pix = NULL; }

static int fails;

static uint8_t *read_file(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *buf = malloc((size_t)n);
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) { free(buf); fclose(f); return NULL; }
    fclose(f);
    *len = (size_t)n;
    return buf;
}

static void check_case(const char *name) {
    char p1[256], p2[256];
    snprintf(p1, sizeof p1, "fixtures/%s.png", name);
    snprintf(p2, sizeof p2, "fixtures/%s.expected.rgb", name);
    size_t plen, elen;
    uint8_t *png = read_file(p1, &plen);
    uint8_t *exp = read_file(p2, &elen);
    if (!png || !exp) { printf("FAIL %-14s: не нашёл файлы фикстур\n", name); fails++; return; }
    int ew = *(int32_t *)exp, eh = *(int32_t *)(exp + 4);
    const uint8_t *exprgb = exp + 8;

    struct img_rgb im;
    int rc = png_decode(png, plen, &im, 2048, 2048);
    if (rc != IMG_OK) { printf("FAIL %-14s: png_decode вернул %d (ожидался 0)\n", name, rc); fails++; }
    else if (im.w != ew || im.h != eh) { printf("FAIL %-14s: размер %dx%d, ожидался %dx%d\n", name, im.w, im.h, ew, eh); fails++; }
    else if (memcmp(im.pix, exprgb, (size_t)ew * (size_t)eh * 3) != 0) {
        printf("FAIL %-14s: пиксели не совпадают с эталоном PIL\n", name); fails++;
        for (int i = 0; i < ew * eh * 3; i++) {
            if (im.pix[i] != exprgb[i]) { printf("       первое расхождение на байте %d: получили %d, ожидали %d\n", i, im.pix[i], exprgb[i]); break; }
        }
    } else {
        printf("ok   %-14s %dx%d, %zu байт PNG\n", name, im.w, im.h, plen);
    }
    if (rc == IMG_OK) image_free(&im);
    free(png); free(exp);
}

int main(void) {
    const char *names[] = { "rgb_gradient", "rgba_alpha", "gray", "palette", "noise", "solid" };
    for (size_t i = 0; i < sizeof names / sizeof names[0]; i++) check_case(names[i]);

    /* интерлейс и 16-бит должны вежливо отклоняться, а не падать/вылетать за буфер */
    {
        size_t len; uint8_t *d = read_file("fixtures/interlaced2.png", &len);
        struct img_rgb im;
        int rc = d ? png_decode(d, len, &im, 2048, 2048) : -1;
        if (rc != IMG_ERR_FORMAT) { printf("FAIL interlaced   : ожидался IMG_ERR_FORMAT, получили %d\n", rc); fails++; }
        else printf("ok   interlaced     вежливо отклонён (код %d)\n", rc);
        if (rc == IMG_OK) image_free(&im);
        free(d);
    }
    {
        size_t len; uint8_t *d = read_file("fixtures/depth16.png", &len);
        struct img_rgb im;
        int rc = d ? png_decode(d, len, &im, 2048, 2048) : -1;
        if (rc != IMG_ERR_FORMAT) { printf("FAIL depth16      : ожидался IMG_ERR_FORMAT, получили %d\n", rc); fails++; }
        else printf("ok   depth16        вежливо отклонён (код %d)\n", rc);
        if (rc == IMG_OK) image_free(&im);
        free(d);
    }
    /* заведомо не-PNG данные */
    {
        const uint8_t junk[] = "not a png file at all, just text";
        struct img_rgb im;
        int rc = png_decode(junk, sizeof junk, &im, 2048, 2048);
        if (rc != IMG_ERR_FORMAT) { printf("FAIL junk         : ожидался IMG_ERR_FORMAT, получили %d\n", rc); fails++; }
        else printf("ok   junk           не-PNG данные отклонены (код %d)\n", rc);
    }
    /* слишком большое изображение относительно max_w/max_h */
    {
        size_t len; uint8_t *d = read_file("fixtures/noise.png", &len);
        struct img_rgb im;
        int rc = d ? png_decode(d, len, &im, 8, 8) : -1;
        if (rc != IMG_ERR_TOO_BIG) { printf("FAIL too_big      : ожидался IMG_ERR_TOO_BIG, получили %d\n", rc); fails++; }
        else printf("ok   too_big        предел размера соблюдён (код %d)\n", rc);
        if (rc == IMG_OK) image_free(&im);
        free(d);
    }

    if (fails == 0) printf("все проверки PNG-декодера пройдены\n");
    return fails ? 1 : 0;
}
