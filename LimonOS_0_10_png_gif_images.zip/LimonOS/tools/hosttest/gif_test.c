#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void *kmalloc(size_t n) { return malloc(n); }
void  kfree(void *p) { free(p); }
#include "../../kernel/image_gif.c"

void image_free(struct img_rgb *im) { if (im->pix) kfree(im->pix); im->pix = NULL; }

static int fails;

static uint8_t *read_file(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *buf = malloc((size_t)n);
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) { free(buf); fclose(f); return NULL; }
    fclose(f);
    *len = (size_t)n;
    return buf;
}

static void check_case(const char *name) {
    char p1[256], p2[256];
    snprintf(p1, sizeof p1, "fixtures/%s.gif", name);
    snprintf(p2, sizeof p2, "fixtures/%s.gexpected.rgb", name);
    size_t glen, elen;
    uint8_t *gif = read_file(p1, &glen);
    uint8_t *exp = read_file(p2, &elen);
    if (!gif || !exp) { printf("FAIL %-16s: не нашёл файлы фикстур\n", name); fails++; return; }
    int ew = *(int32_t *)exp, eh = *(int32_t *)(exp + 4);
    const uint8_t *exprgb = exp + 8;

    struct img_rgb im;
    int rc = gif_decode(gif, glen, &im, 2048, 2048);
    if (rc != IMG_OK) { printf("FAIL %-16s: gif_decode вернул %d (ожидался 0)\n", name, rc); fails++; }
    else if (im.w != ew || im.h != eh) { printf("FAIL %-16s: размер %dx%d, ожидался %dx%d\n", name, im.w, im.h, ew, eh); fails++; }
    else if (memcmp(im.pix, exprgb, (size_t)ew * (size_t)eh * 3) != 0) {
        printf("FAIL %-16s: пиксели не совпадают с эталоном PIL\n", name); fails++;
        for (int i = 0; i < ew * eh * 3; i++)
            if (im.pix[i] != exprgb[i]) { printf("       первое расхождение на байте %d (x=%d,y=%d,канал=%d): получили %d, ожидали %d\n",
                                                   i, (i/3)%ew, (i/3)/ew, i%3, im.pix[i], exprgb[i]); break; }
    } else {
        printf("ok   %-16s %dx%d, %zu байт GIF\n", name, im.w, im.h, glen);
    }
    if (rc == IMG_OK) image_free(&im);
    free(gif); free(exp);
}

int main(void) {
    const char *names[] = { "gif_simple", "gif_big", "gif_solid", "gif_transparent", "gif_interlaced" };
    for (size_t i = 0; i < sizeof names / sizeof names[0]; i++) check_case(names[i]);

    /* не-GIF данные */
    {
        const uint8_t junk[] = "definitely not a gif";
        struct img_rgb im;
        int rc = gif_decode(junk, sizeof junk, &im, 2048, 2048);
        if (rc != IMG_ERR_FORMAT) { printf("FAIL junk            : ожидался IMG_ERR_FORMAT, получили %d\n", rc); fails++; }
        else printf("ok   junk              не-GIF данные отклонены (код %d)\n", rc);
    }
    /* предел размера */
    {
        size_t len; uint8_t *d = read_file("fixtures/gif_big.gif", &len);
        struct img_rgb im;
        int rc = d ? gif_decode(d, len, &im, 4, 4) : -1;
        if (rc != IMG_ERR_TOO_BIG) { printf("FAIL too_big         : ожидался IMG_ERR_TOO_BIG, получили %d\n", rc); fails++; }
        else printf("ok   too_big           предел размера соблюдён (код %d)\n", rc);
        if (rc == IMG_OK) image_free(&im);
        free(d);
    }

    if (fails == 0) printf("все проверки GIF-декодера пройдены\n");
    return fails ? 1 : 0;
}
