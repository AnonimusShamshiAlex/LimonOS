#ifndef LIMON_TLS_H
#define LIMON_TLS_H
#include <stdint.h>
#include <stddef.h>
#include "sha256.h"
#include "aes.h"

/* Транспорт TLS не знает, откуда берутся байты — только эти две функции.
 * send: вернуть 0 при успехе. recv: прочитать ДО len байт (необязательно все сразу),
 * вернуть >0 — сколько реально прочитано, 0 — таймаут/соединение закрыто, <0 — ошибка. */
typedef int (*tls_send_fn)(void *ctx, const uint8_t *data, size_t len);
typedef int (*tls_recv_fn)(void *ctx, uint8_t *buf, size_t len, int timeout_ms);

#define TLS_OK                0
#define TLS_ERR_IO           -1
#define TLS_ERR_PROTOCOL     -2   /* сервер прислал что-то, что мы не разобрали/не ждали */
#define TLS_ERR_ALERT        -3   /* сервер прислал предупреждение/ошибку (TLS alert) */
#define TLS_ERR_FINISHED     -4   /* проверка Finished не совпала — подмена или наша ошибка */
#define TLS_ERR_NOMEM        -5

struct tls_conn {
    tls_send_fn send;
    tls_recv_fn recv;
    void *io_ctx;

    struct aes128 c_hs_aes, s_hs_aes, c_ap_aes, s_ap_aes;
    uint8_t c_hs_iv[12], s_hs_iv[12], c_ap_iv[12], s_ap_iv[12];
    uint64_t c_seq, s_seq;         /* счётчики записей (сбрасываются при смене фазы ключей) */
    int app_phase;                 /* 0 — ещё рукопожатие (используем *_hs_*), 1 — приложение (*_ap_*) */
    int s_hs_iv_unset;             /* 1, пока ключи рукопожатия ещё не выведены (alert до них идёт открытым текстом) */

    struct sha256_ctx transcript;  /* нарастающий хэш всех handshake-сообщений */

    uint8_t rxbuf[2048];           /* расшифрованные handshake-байты, ждущие разбора */
    size_t rxlen, rxpos;

    uint8_t net_in[4096];          /* сырые байты из сети, ещё не выделенные в целую запись */
    size_t net_len;

    int established;
    int alert_code;
    char err[64];
};

/* Выполняет полное рукопожатие TLS 1.3 (ClientHello..Finished) с заданным хостом (SNI).
 * ВНИМАНИЕ: сертификат сервера НЕ проверяется (нет разбора X.509/RSA/ECDSA) — это читает
 * шифрованный канал, но не удостоверяет личность сервера (как curl -k). */
int tls_connect(struct tls_conn *c, tls_send_fn send, tls_recv_fn recv, void *io_ctx, const char *sni_host);
int tls_write(struct tls_conn *c, const uint8_t *data, size_t len);
int tls_read(struct tls_conn *c, uint8_t *buf, size_t maxlen, int timeout_ms);
void tls_close(struct tls_conn *c);

#endif
