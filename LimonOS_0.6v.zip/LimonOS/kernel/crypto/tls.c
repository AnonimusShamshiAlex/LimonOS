/* LimonOS Vine-TLS — минимальный клиент TLS 1.3 (RFC 8446), один комплект шифров:
 * TLS_AES_128_GCM_SHA256, группа x25519.
 *
 * ВАЖНО, честно: сертификат сервера НЕ проверяется (нет разбора X.509, нет RSA/ECDSA
 * проверки подписи, нет доверенных корневых сертификатов). Канал зашифрован и защищён
 * от пассивного прослушивания, Finished-сообщения подтверждают целостность рукопожатия,
 * но ничто не удостоверяет, что на другом конце именно тот сервер, за кого он себя выдаёт
 * (как curl -k / --insecure). Полноценная проверка сертификата — отдельная большая задача.
 *
 * Случайность (приватный ключ x25519, ClientHello.random) берётся через RDRAND (см. rng.c);
 * на процессорах без RDRAND (редкость — всё от Ivy Bridge/Zen и новее его имеет, включая
 * обычные настройки VirtualBox и QEMU) используется более слабый резервный генератор.
 */
#include "tls.h"
#include "hmac.h"
#include "hkdf.h"
#include "gcm.h"
#include "x25519.h"
#include "kstring.h"
#include "rng.h"

/* ---------- сеть мелкими порциями, с накоплением в net_in ---------- */

static int net_fill(struct tls_conn *c, size_t need, int timeout_ms) {
    while (c->net_len < need) {
        if (need > sizeof c->net_in) return -1;
        int n = c->recv(c->io_ctx, c->net_in + c->net_len, sizeof c->net_in - c->net_len, timeout_ms);
        if (n <= 0) return -1;
        c->net_len += (size_t)n;
    }
    return 0;
}
static void net_consume(struct tls_conn *c, size_t n) {
    memmove(c->net_in, c->net_in + n, c->net_len - n);
    c->net_len -= n;
}

static void nonce_for(uint8_t out[12], const uint8_t iv[12], uint64_t seq) {
    memcpy(out, iv, 12);
    for (int i = 0; i < 8; i++) out[11 - i] ^= (uint8_t)(seq >> (8 * i));
}

/* Читает и расшифровывает ОДНУ запись уровня записи TLS (может потребовать нескольких
 * чтений из сети). change_cipher_spec (сырой тип 20) пропускает сама (это пустышка для
 * совместимости со старыми посредниками, в TLS 1.3 ничего не значит).
 * Возвращает TLS_OK и заполняет *inner_type/content/content_len, либо код ошибки. */
static int read_record(struct tls_conn *c, int timeout_ms, uint8_t *inner_type, uint8_t *content, size_t *content_len, size_t cap) {
    for (;;) {
        if (net_fill(c, 5, timeout_ms) < 0) return TLS_ERR_IO;
        uint8_t wire_type = c->net_in[0];
        size_t rlen = ((size_t)c->net_in[3] << 8) | c->net_in[4];
        if (net_fill(c, 5 + rlen, timeout_ms) < 0) return TLS_ERR_IO;
        uint8_t hdr[5] = { c->net_in[0], c->net_in[1], c->net_in[2], c->net_in[3], c->net_in[4] };
        uint8_t *rec = c->net_in + 5;

        if (wire_type == 20) { net_consume(c, 5 + rlen); continue; }       /* change_cipher_spec */
        if (wire_type != 23 && wire_type != 21) { net_consume(c, 5 + rlen); continue; }

        /* Alert до появления ключей рукопожатия (очень ранний отказ сервера) приходит НЕзашифрованным */
        if (wire_type == 21 && rlen == 2 && c->s_hs_iv_unset) {
            c->alert_code = rec[1];
            net_consume(c, 5 + rlen);
            return TLS_ERR_ALERT;
        }

        if (rlen < 16 + 1) { net_consume(c, 5 + rlen); return TLS_ERR_PROTOCOL; }
        const struct aes128 *aes = c->app_phase ? &c->s_ap_aes : &c->s_hs_aes;
        const uint8_t *iv = c->app_phase ? c->s_ap_iv : c->s_hs_iv;
        uint8_t nonce[12]; nonce_for(nonce, iv, c->s_seq++);

        size_t clen = rlen - 16;
        if (clen > cap + 1) { net_consume(c, 5 + rlen); return TLS_ERR_NOMEM; }
        uint8_t plain[2048];
        if (clen > sizeof plain) { net_consume(c, 5 + rlen); return TLS_ERR_NOMEM; }
        int ok = gcm_decrypt(aes, nonce, hdr, 5, rec, clen, rec + clen, plain);
        net_consume(c, 5 + rlen);
        if (!ok) return TLS_ERR_PROTOCOL;

        size_t real = clen;
        while (real > 0 && plain[real - 1] == 0) real--;
        if (real == 0) continue;                 /* пустая запись-заполнитель — читаем следующую */
        uint8_t itype = plain[real - 1];
        size_t ilen = real - 1;
        if (itype == 21) {                        /* зашифрованный alert */
            c->alert_code = ilen >= 2 ? plain[1] : 0;
            return TLS_ERR_ALERT;
        }
        if (ilen > cap) return TLS_ERR_NOMEM;
        memcpy(content, plain, ilen);
        *content_len = ilen;
        *inner_type = itype;
        return TLS_OK;
    }
}

/* ---------- ключевой график TLS 1.3 (RFC 8446 §7.1) ---------- */

static void derive_secret(const uint8_t secret[32], const char *label, const uint8_t hash[32], uint8_t out[32]) {
    tls_hkdf_expand_label(secret, label, hash, 32, out, 32);
}
static void traffic_keys(const uint8_t secret[32], struct aes128 *aes, uint8_t iv[12]) {
    uint8_t key[16];
    tls_hkdf_expand_label(secret, "key", NULL, 0, key, 16);
    tls_hkdf_expand_label(secret, "iv", NULL, 0, iv, 12);
    aes128_init(aes, key);
}

/* ---------- отправка зашифрованной записи (приложение или handshake-после-ключей) ---------- */

static int send_record(struct tls_conn *c, uint8_t inner_type, const uint8_t *content, size_t len) {
    uint8_t plain[1800];
    if (len + 1 > sizeof plain) return TLS_ERR_NOMEM;
    memcpy(plain, content, len);
    plain[len] = inner_type;
    size_t plen = len + 1;

    const struct aes128 *aes = c->app_phase ? &c->c_ap_aes : &c->c_hs_aes;
    const uint8_t *iv = c->app_phase ? c->c_ap_iv : c->c_hs_iv;
    uint8_t nonce[12]; nonce_for(nonce, iv, c->c_seq++);

    uint8_t hdr[5] = { 23, 3, 3, (uint8_t)((plen + 16) >> 8), (uint8_t)((plen + 16) & 0xFF) };
    uint8_t ct[1800], tag[16];
    gcm_encrypt(aes, nonce, hdr, 5, plain, plen, ct, tag);

    if (c->send(c->io_ctx, hdr, 5) != 0) return TLS_ERR_IO;
    if (c->send(c->io_ctx, ct, plen) != 0) return TLS_ERR_IO;
    if (c->send(c->io_ctx, tag, 16) != 0) return TLS_ERR_IO;
    return TLS_OK;
}

/* ---------- ClientHello ---------- */

static void put16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)(v >> 8); p[1] = (uint8_t)v; }

static size_t build_client_hello(uint8_t *out, const uint8_t rnd[32], const uint8_t sess[32],
                                  const uint8_t pub[32], const char *host) {
    uint8_t body[600]; size_t n = 0;
    put16(body + n, 0x0303); n += 2;
    memcpy(body + n, rnd, 32); n += 32;
    body[n++] = 32; memcpy(body + n, sess, 32); n += 32;
    put16(body + n, 2); n += 2; put16(body + n, 0x1301); n += 2;
    body[n++] = 1; body[n++] = 0;

    uint8_t ext[500]; size_t e = 0;
    size_t hlen = strlen(host);
    put16(ext + e, 0x0000); e += 2;
    put16(ext + e, (uint16_t)(hlen + 5)); e += 2;
    put16(ext + e, (uint16_t)(hlen + 3)); e += 2;
    ext[e++] = 0; put16(ext + e, (uint16_t)hlen); e += 2;
    memcpy(ext + e, host, hlen); e += hlen;

    put16(ext + e, 0x000a); e += 2; put16(ext + e, 4); e += 2;
    put16(ext + e, 2); e += 2; put16(ext + e, 0x001d); e += 2;

    put16(ext + e, 0x000d); e += 2; put16(ext + e, 6); e += 2;
    put16(ext + e, 4); e += 2; put16(ext + e, 0x0804); e += 2; put16(ext + e, 0x0403); e += 2;

    put16(ext + e, 0x0033); e += 2;
    put16(ext + e, 38); e += 2; put16(ext + e, 36); e += 2;
    put16(ext + e, 0x001d); e += 2; put16(ext + e, 32); e += 2;
    memcpy(ext + e, pub, 32); e += 32;

    put16(ext + e, 0x002b); e += 2; put16(ext + e, 3); e += 2;
    ext[e++] = 2; put16(ext + e, 0x0304); e += 2;

    put16(body + n, (uint16_t)e); n += 2;
    memcpy(body + n, ext, e); n += e;

    out[0] = 1; out[1] = 0; out[2] = (uint8_t)(n >> 8); out[3] = (uint8_t)n;
    memcpy(out + 4, body, n);
    return n + 4;
}

static int parse_server_hello(const uint8_t *m, size_t n, uint8_t srv_pub[32], int *got_pub) {
    *got_pub = 0;
    if (n < 2 + 32 + 1) return -1;
    size_t p = 2 + 32;
    uint8_t sidlen = m[p]; p += 1 + sidlen;
    if (p + 3 > n) return -1;
    p += 2;    /* cipher_suite */
    p += 1;    /* compression */
    if (p + 2 > n) return -1;
    size_t extlen = ((size_t)m[p] << 8) | m[p + 1]; p += 2;
    size_t end = p + extlen; if (end > n) end = n;
    while (p + 4 <= end) {
        uint16_t etype = (uint16_t)((m[p] << 8) | m[p + 1]);
        size_t elen = ((size_t)m[p + 2] << 8) | m[p + 3];
        p += 4;
        if (p + elen > end) break;
        if (etype == 0x0033 && elen >= 4) {
            uint16_t glen = (uint16_t)((m[p + 2] << 8) | m[p + 3]);
            if (glen == 32 && p + 4 + 32 <= end) { memcpy(srv_pub, m + p + 4, 32); *got_pub = 1; }
        }
        p += elen;
    }
    return 0;
}

static int ct_eq(const uint8_t *a, const uint8_t *b, size_t n) {
    uint8_t d = 0; for (size_t i = 0; i < n; i++) d = (uint8_t)(d | (a[i] ^ b[i])); return d == 0;
}

/* Читает ОДНО полное handshake-сообщение (может понадобиться несколько записей —
 * редко, но сообщение Certificate у крупных цепочек может не влезть в одну запись).
 * Добавляет его байты (заголовок+тело) в транскрипт САМ ВЫЗЫВАЮЩИЙ — эта функция только
 * читает и возвращает указатель на буфер msgbuf. */
static int read_handshake_msg(struct tls_conn *c, uint8_t *msgbuf, size_t cap, size_t *msglen, int timeout_ms) {
    uint8_t itype; size_t ilen;
    uint8_t tmp[2048];
    size_t have = 0;
    for (;;) {
        int r = read_record(c, timeout_ms, &itype, tmp, &ilen, sizeof tmp);
        if (r != TLS_OK) return r;
        if (itype != 22) continue;               /* не handshake-контент (не ждём тут ничего другого) */
        if (have + ilen > cap) return TLS_ERR_NOMEM;
        memcpy(msgbuf + have, tmp, ilen);
        have += ilen;
        if (have < 4) continue;
        size_t need = 4 + (((size_t)msgbuf[1] << 16) | ((size_t)msgbuf[2] << 8) | msgbuf[3]);
        if (have < need) continue;                /* сообщение пришло несколькими записями — ждём остаток */
        *msglen = need;                            /* лишнее (следующее сообщение) в tmp не бывает: ilen — ровно одна запись */
        return TLS_OK;
    }
}

int tls_connect(struct tls_conn *c, tls_send_fn send, tls_recv_fn recv, void *io_ctx, const char *sni_host) {
    memset(c, 0, sizeof *c);
    c->send = send; c->recv = recv; c->io_ctx = io_ctx;
    c->s_hs_iv_unset = 1;
    sha256_init(&c->transcript);

    uint8_t priv[32], pub[32], rnd[32], sess[32];
    rng_bytes(priv, 32);
    rng_bytes(rnd, 32);
    rng_bytes(sess, 32);
    x25519_base(pub, priv);

    uint8_t ch[700];
    size_t chlen = build_client_hello(ch, rnd, sess, pub, sni_host);
    sha256_update(&c->transcript, ch, chlen);
    uint8_t rec_hdr[5] = { 22, 3, 1, (uint8_t)(chlen >> 8), (uint8_t)(chlen & 0xFF) };
    if (c->send(io_ctx, rec_hdr, 5) != 0 || c->send(io_ctx, ch, chlen) != 0) return TLS_ERR_IO;

    /* ServerHello идёт незашифрованным (тип 22 прямо на проводе) */
    if (net_fill(c, 5, 5000) < 0) return TLS_ERR_IO;
    uint8_t first_type = c->net_in[0];
    size_t shlen = ((size_t)c->net_in[3] << 8) | c->net_in[4];
    if (net_fill(c, 5 + shlen, 5000) < 0) return TLS_ERR_IO;
    if (first_type == 21) { c->alert_code = shlen >= 2 ? c->net_in[6] : 0; net_consume(c, 5 + shlen); return TLS_ERR_ALERT; }
    if (first_type != 22) { net_consume(c, 5 + shlen); return TLS_ERR_PROTOCOL; }
    uint8_t sh[2048];
    if (shlen > sizeof sh) return TLS_ERR_NOMEM;
    memcpy(sh, c->net_in + 5, shlen);
    net_consume(c, 5 + shlen);
    if (shlen < 4 || sh[0] != 2) return TLS_ERR_PROTOCOL;
    size_t shblen = ((size_t)sh[1] << 16) | ((size_t)sh[2] << 8) | sh[3];
    if (4 + shblen > shlen) return TLS_ERR_PROTOCOL;
    sha256_update(&c->transcript, sh, 4 + shblen);

    uint8_t srv_pub[32]; int got_pub;
    if (parse_server_hello(sh + 4, shblen, srv_pub, &got_pub) != 0 || !got_pub) return TLS_ERR_PROTOCOL;

    uint8_t shared[32];
    x25519(shared, priv, srv_pub);

    uint8_t zero32[32] = {0}, early[32], hs_derived[32], hshs[32];
    hkdf_extract(NULL, 0, zero32, 32, early);
    { uint8_t h0[32]; sha256(NULL, 0, h0); derive_secret(early, "derived", h0, hs_derived); }
    hkdf_extract(hs_derived, 32, shared, 32, hshs);

    uint8_t ch_sh_hash[32];
    { struct sha256_ctx tc = c->transcript; sha256_final(&tc, ch_sh_hash); }
    uint8_t c_hs_secret[32], s_hs_secret[32];
    derive_secret(hshs, "c hs traffic", ch_sh_hash, c_hs_secret);
    derive_secret(hshs, "s hs traffic", ch_sh_hash, s_hs_secret);
    traffic_keys(c_hs_secret, &c->c_hs_aes, c->c_hs_iv);
    traffic_keys(s_hs_secret, &c->s_hs_aes, c->s_hs_iv);
    c->s_hs_iv_unset = 0;

    uint8_t master_derived[32], master[32];
    { uint8_t h0[32]; sha256(NULL, 0, h0); derive_secret(hshs, "derived", h0, master_derived); }
    hkdf_extract(master_derived, 32, zero32, 32, master);

    int have_enc_ext = 0;
    uint8_t msg[2048]; size_t mlen;
    for (;;) {
        int r = read_handshake_msg(c, msg, sizeof msg, &mlen, 8000);
        if (r != TLS_OK) return r;
        uint8_t htype = msg[0];

        if (htype == 20) {                                  /* Finished сервера */
            if (mlen != 4 + 32) return TLS_ERR_PROTOCOL;
            uint8_t pre_fin_hash[32];
            { struct sha256_ctx tc = c->transcript; sha256_final(&tc, pre_fin_hash); }
            uint8_t fin_key[32], verify[32];
            tls_hkdf_expand_label(s_hs_secret, "finished", NULL, 0, fin_key, 32);
            hmac_sha256(fin_key, 32, pre_fin_hash, 32, verify);
            if (!ct_eq(verify, msg + 4, 32)) return TLS_ERR_FINISHED;
            sha256_update(&c->transcript, msg, mlen);        /* теперь добавляем сам Finished */
            break;
        }
        sha256_update(&c->transcript, msg, mlen);
        if (htype == 8) have_enc_ext = 1;                    /* EncryptedExtensions — содержимое не используем */
        /* htype 11 (Certificate) и 15 (CertificateVerify) — см. предупреждение в начале файла: не проверяем */
    }
    if (!have_enc_ext) return TLS_ERR_PROTOCOL;

    uint8_t ch_sh_sf_hash[32];
    { struct sha256_ctx tc = c->transcript; sha256_final(&tc, ch_sh_sf_hash); }
    uint8_t c_ap_secret[32], s_ap_secret[32];
    derive_secret(master, "c ap traffic", ch_sh_sf_hash, c_ap_secret);
    derive_secret(master, "s ap traffic", ch_sh_sf_hash, s_ap_secret);
    traffic_keys(c_ap_secret, &c->c_ap_aes, c->c_ap_iv);
    traffic_keys(s_ap_secret, &c->s_ap_aes, c->s_ap_iv);

    uint8_t c_fin_key[32], c_verify[32];
    tls_hkdf_expand_label(c_hs_secret, "finished", NULL, 0, c_fin_key, 32);
    hmac_sha256(c_fin_key, 32, ch_sh_sf_hash, 32, c_verify);
    uint8_t cfin[4 + 32] = { 20, 0, 0, 32 };
    memcpy(cfin + 4, c_verify, 32);
    int r = send_record(c, 22, cfin, sizeof cfin);
    if (r != TLS_OK) return r;

    c->app_phase = 1;
    c->c_seq = 0; c->s_seq = 0;
    c->established = 1;
    return TLS_OK;
}

int tls_write(struct tls_conn *c, const uint8_t *data, size_t len) {
    size_t sent = 0;
    while (sent < len) {
        size_t chunk = len - sent; if (chunk > 1024) chunk = 1024;
        int r = send_record(c, 23, data + sent, chunk);
        if (r != TLS_OK) return r;
        sent += chunk;
    }
    return TLS_OK;
}

int tls_read(struct tls_conn *c, uint8_t *buf, size_t maxlen, int timeout_ms) {
    uint8_t itype; size_t ilen;
    for (;;) {
        int r = read_record(c, timeout_ms, &itype, buf, &ilen, maxlen);
        if (r == TLS_ERR_ALERT && c->alert_code == 0) return 0;    /* close_notify — чистое завершение */
        if (r != TLS_OK) return r;
        if (itype == 23) return (int)ilen;
        /* itype==22 (например NewSessionTicket) после рукопожатия — молча пропускаем */
    }
}

void tls_close(struct tls_conn *c) {
    if (!c->established) return;
    uint8_t alert[2] = { 1, 0 };     /* warning, close_notify */
    send_record(c, 21, alert, 2);
}
