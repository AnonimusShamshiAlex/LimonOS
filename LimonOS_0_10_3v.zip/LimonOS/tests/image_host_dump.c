/* Хост-тест декодера: image_host_dump файл [max_w max_h] -> "w h\n" + сырые байты RGB */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../kernel/image.h"
void *kmalloc(size_t n) { return malloc(n); }
void kfree(void *p) { free(p); }
int main(int argc, char **argv) {
    FILE *f = fopen(argv[1], "rb"); if (!f) return 3;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *d = malloc((size_t)n); if (fread(d, 1, (size_t)n, f) != (size_t)n) return 3; fclose(f);
    struct img im;
    int rc = img_decode(d, (size_t)n, argc > 2 ? atoi(argv[2]) : 0, argc > 3 ? atoi(argv[3]) : 0, &im);
    if (rc) { printf("ERR %d\n", rc); return 1; }
    printf("%d %d\n", im.w, im.h);
    for (int i = 0; i < im.w * im.h; i++) { putchar((im.px[i] >> 16) & 255); putchar((im.px[i] >> 8) & 255); putchar(im.px[i] & 255); }
    return 0;
}
