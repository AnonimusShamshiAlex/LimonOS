#!/bin/bash
# разбор файла с API-ключом ИИ (aikey keys.txt)
set -e
cd "$(dirname "$0")"
gcc -O1 -Wall -o /tmp/kf_test keyfile_host_test.c
/tmp/kf_test
