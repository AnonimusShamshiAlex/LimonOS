#!/bin/bash
# распознавание «адрес без имени файла» и страницы-списка папки (grab, aikey)
set -e
cd "$(dirname "$0")"
gcc -O1 -Wall -Wno-unused-function -I../kernel -o /tmp/grabutil_test grabutil_host_test.c
/tmp/grabutil_test
