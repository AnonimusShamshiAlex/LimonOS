#!/bin/bash
# Разбор HTML/CSS и картинок на странице (kernel/browser.c): DOM, селекторы, цвета, формы, внешний CSS, <img>, кодировка
set -e
cd "$(dirname "$0")/.."
gcc -O1 -w -Ikernel -o /tmp/browser_host_test tests/browser_host_test.c kernel/format.c
/tmp/browser_host_test | tail -1
