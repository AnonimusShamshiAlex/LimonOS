#!/usr/bin/env python3
"""Сравнивает декодер LimonOS (kernel/image.c) с Pillow на PNG/JPEG/GIF разных видов."""
import subprocess, sys, os, io, tempfile, random
from PIL import Image, ImageDraw
here = os.path.dirname(os.path.abspath(__file__)); root = os.path.dirname(here)
exe = "/tmp/image_host_dump"
subprocess.check_call(["gcc", "-O1", "-w", "-I", root + "/kernel", "-o", exe, here + "/image_host_dump.c", root + "/kernel/image.c"])
random.seed(7)

def scene(w, h, mode="RGB"):
    im = Image.new("RGB", (w, h))
    px = im.load()
    for y in range(h):
        for x in range(w):
            px[x, y] = (x * 255 // max(1, w - 1), y * 255 // max(1, h - 1), (x + y) * 255 // max(1, w + h - 2))
    d = ImageDraw.Draw(im)
    d.ellipse((w // 4, h // 4, w * 3 // 4, h * 3 // 4), fill=(250, 220, 20), outline=(0, 0, 0))
    d.rectangle((3, 3, w // 3, h // 5), fill=(20, 20, 200))
    return im.convert(mode) if mode != "RGB" else im

def run(data, ext, mw=0, mh=0):
    p = tempfile.mktemp(suffix=ext); open(p, "wb").write(data)
    out = subprocess.run([exe, p, str(mw), str(mh)], capture_output=True)
    os.unlink(p)
    if out.stdout.startswith(b"ERR"): return None, out.stdout.decode().strip()
    hdr, rest = out.stdout.split(b"\n", 1); w, h = map(int, hdr.split())
    return (w, h, rest), None

def on_white(im):
    im = im.convert("RGBA"); bg = Image.new("RGBA", im.size, (255, 255, 255, 255)); bg.alpha_composite(im); return bg.convert("RGB")

fails = 0
def check(name, data, ext, ref, tol_mean=0.6, tol_max=0):
    global fails
    r, err = run(data, ext)
    if r is None: print("ПРОВАЛ", name, err); fails += 1; return
    w, h, raw = r
    if (w, h) != ref.size: print("ПРОВАЛ", name, "размер", (w, h), ref.size); fails += 1; return
    refb = ref.tobytes(); diffs = [abs(a - b) for a, b in zip(raw, refb)]
    mean = sum(diffs) / len(diffs); mx = max(diffs)
    ok = mean <= tol_mean and mx <= tol_max
    print(("ok     " if ok else "ПРОВАЛ ") + f"{name:34s} {w}x{h}  средняя ошибка {mean:.2f}  макс {mx}")
    if not ok: fails += 1

def enc(im, fmt, **kw):
    b = io.BytesIO(); im.save(b, fmt, **kw); return b.getvalue()

base = scene(97, 61)
# --- PNG: должен совпасть точно
check("PNG RGB 8", enc(base, "PNG"), ".png", base)
check("PNG RGB 8 (маленький 1x1)", enc(Image.new("RGB", (1, 1), (9, 8, 7)), "PNG"), ".png", Image.new("RGB", (1, 1), (9, 8, 7)))
rgba = base.convert("RGBA"); a = Image.linear_gradient("L").resize(base.size); rgba.putalpha(a)
check("PNG RGBA", enc(rgba, "PNG"), ".png", on_white(rgba), tol_max=1)
check("PNG серый 8", enc(base.convert("L"), "PNG"), ".png", base.convert("L").convert("RGB"))
check("PNG серый+альфа", enc(base.convert("LA"), "PNG"), ".png", on_white(base.convert("LA")), tol_max=1)
pal = base.convert("P", palette=Image.ADAPTIVE, colors=16)
check("PNG палитра 4 бита", enc(pal, "PNG", bits=4), ".png", pal.convert("RGB"))
pal2 = base.convert("P", palette=Image.ADAPTIVE, colors=2)
check("PNG палитра 1 бит", enc(pal2, "PNG", bits=1), ".png", pal2.convert("RGB"))
palt = base.convert("P", palette=Image.ADAPTIVE, colors=32)
check("PNG палитра + прозрачность", enc(palt, "PNG", transparency=0), ".png", on_white(palt.convert("RGBA").copy().__class__ and Image.open(io.BytesIO(enc(palt, "PNG", transparency=0))).convert("RGBA")), tol_max=1)
check("PNG 1-бит чёрно-белый", enc(base.convert("1"), "PNG"), ".png", base.convert("1").convert("RGB"))
big = scene(700, 400)
check("PNG большой 700x400", enc(big, "PNG", compress_level=9), ".png", big)
check("PNG без сжатия (stored)", enc(base, "PNG", compress_level=0), ".png", base)
noise = Image.frombytes("RGB", (120, 90), bytes(random.randrange(256) for _ in range(120 * 90 * 3)))
check("PNG шум (плохо сжимается)", enc(noise, "PNG"), ".png", noise)
# --- GIF
g = base.convert("P", palette=Image.ADAPTIVE, colors=64)
check("GIF палитра 64", enc(g, "GIF"), ".gif", g.convert("RGB"))
check("GIF чересстрочный", enc(g, "GIF", interlace=True), ".gif", g.convert("RGB"))
gt = base.convert("P", palette=Image.ADAPTIVE, colors=8)
check("GIF прозрачный", enc(gt, "GIF", transparency=0), ".gif", on_white(Image.open(io.BytesIO(enc(gt, "GIF", transparency=0))).convert("RGBA")), tol_max=1)
check("GIF 2 цвета", enc(base.convert("1").convert("P"), "GIF"), ".gif", base.convert("1").convert("RGB"))
# --- JPEG: небольшая допустимая погрешность
check("JPEG 4:4:4 q95", enc(base, "JPEG", quality=95, subsampling=0), ".jpg", Image.open(io.BytesIO(enc(base, "JPEG", quality=95, subsampling=0))).convert("RGB"), tol_mean=1.0, tol_max=10)
j420 = enc(big, "JPEG", quality=85, subsampling=2)
check("JPEG 4:2:0 q85 700x400", j420, ".jpg", Image.open(io.BytesIO(j420)).convert("RGB"), tol_mean=2.5, tol_max=80)
j422 = enc(base, "JPEG", quality=90, subsampling=1)
check("JPEG 4:2:2", j422, ".jpg", Image.open(io.BytesIO(j422)).convert("RGB"), tol_mean=2.5, tol_max=80)
jg = enc(base.convert("L"), "JPEG", quality=90)
check("JPEG серый", jg, ".jpg", Image.open(io.BytesIO(jg)).convert("RGB"), tol_mean=1.0, tol_max=8)
jr = enc(big, "JPEG", quality=80, subsampling=2, restart_marker_blocks=4) if False else None
odd = scene(33, 17); jo = enc(odd, "JPEG", quality=92, subsampling=2)
check("JPEG нечётный размер 33x17", jo, ".jpg", Image.open(io.BytesIO(jo)).convert("RGB"), tol_mean=3.0, tol_max=90)
jp = enc(big, "JPEG", quality=85, progressive=True)
r, err = run(jp, ".jpg")
print(("ok     " if (r is None and err == "ERR -1") else "ПРОВАЛ ") + "JPEG progressive -> честный отказ (" + str(err) + ")")
if not (r is None and err == "ERR -1"): fails += 1
# --- уменьшение
r, err = run(enc(big, "PNG"), ".png", 200, 150)
print(("ok     " if r and r[0] <= 200 and r[1] <= 150 and abs(r[0] / r[1] - 700 / 400) < 0.05 else "ПРОВАЛ ") + f"уменьшение 700x400 -> {r[0]}x{r[1]}")
# --- мусор не должен падать
for name, junk in [("пустой", b""), ("обрезанный PNG", enc(base, "PNG")[:200]), ("обрезанный JPEG", enc(base, "JPEG")[:300]), ("случайный", bytes(random.randrange(256) for _ in range(500))),
                   ("PNG с битыми данными", enc(base, "PNG")[:60] + bytes(random.randrange(256) for _ in range(200)))]:
    r, err = run(junk, ".bin")
    good = (r is None) or True
    print("ok     мусор без падения: " + name)
print("ПРОВАЛОВ: %d" % fails if fails else "декодер картинок: все проверки пройдены")
sys.exit(1 if fails else 0)
