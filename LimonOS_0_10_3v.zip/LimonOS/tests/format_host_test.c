#include <stdio.h>
#include <string.h>
#include "../kernel/format.h"
static int fails;
#define EQ(fmt, arg, want) do { char b[100]; ksnprintf(b, sizeof b, fmt, arg); if (strcmp(b, want)) { printf("FAIL %s: [%s] != [%s]\n", fmt, b, want); fails++; } } while (0)
int main(void) {
    EQ("%.47s", "keys.txt", "keys.txt");                 /* именно это ломало grab: файл назывался «%.47s» */
    EQ("%.3s", "abcdef", "abc");
    EQ("%.3s", "ab", "ab");
    EQ("%.4s", "ключи.txt", "ключ");                      /* считаем символы, а не байты */
    EQ("[%6.2s]", "abcdef", "[    ab]");
    EQ("[%-6.2s]", "abcdef", "[ab    ]");
    EQ("%.0s", "abc", "");
    EQ("%s", "полная", "полная");
    EQ("%5s|", "ab", "   ab|");
    printf(fails ? "ПРОВАЛ %d\n" : "format: все проверки пройдены\n", fails);
    return fails != 0;
}
