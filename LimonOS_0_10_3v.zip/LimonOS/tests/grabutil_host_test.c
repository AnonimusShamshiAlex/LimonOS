#include <stdio.h>
#include <string.h>
#include "../kernel/grabutil.h"
#include "../kernel/grabutil.c"
static int fails;
#define CHECK(c) do{ if(!(c)){ printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } }while(0)
int main(void) {
    CHECK(url_has_no_path("http://192.168.0.113:8000"));          /* ровно ваша ошибка */
    CHECK(url_has_no_path("http://192.168.0.113:8000/"));
    CHECK(url_has_no_path("https://example.com"));
    CHECK(!url_has_no_path("http://192.168.0.113:8000/keys.txt"));
    CHECK(!url_has_no_path("https://example.com/a/b?x=1"));
    /* настоящий ответ python3 -m http.server на «/» */
    const char *py = "<!DOCTYPE HTML>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<title>Directory listing for /</title>\n</head>\n<body>\n"
        "<h1>Directory listing for /</h1>\n<hr>\n<ul>\n<li><a href=\"key.txt\">key.txt</a></li>\n<li><a href=\"keys.txt\">keys.txt</a></li>\n"
        "<li><a href=\"sub/\">sub/</a></li>\n</ul>\n<hr>\n</body>\n</html>\n";
    CHECK(looks_like_dir_listing((const uint8_t *)py, strlen(py)));
    char nm[12][64]; int k = listing_names((const uint8_t *)py, strlen(py), nm, 12);
    CHECK(k == 3 && !strcmp(nm[0], "key.txt") && !strcmp(nm[1], "keys.txt") && !strcmp(nm[2], "sub/"));
    const char *nginx = "<html>\n<head><title>Index of /files/</title></head>\n<body>\n<h1>Index of /files/</h1><hr><pre><a href=\"../\">../</a>\n<a href=\"a.zip\">a.zip</a>   01-Jan-2026\n</pre><hr></body>\n</html>\n";
    CHECK(looks_like_dir_listing((const uint8_t *)nginx, strlen(nginx)));
    const char *key = "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\r\n";
    CHECK(!looks_like_dir_listing((const uint8_t *)key, strlen(key)));          /* настоящий файл с ключом — не список */
    const char *page = "<html><body><h1>Мой сайт</h1><p>Directory — не то</p></body></html>";
    CHECK(!looks_like_dir_listing((const uint8_t *)page, strlen(page)));
    CHECK(mem_find((const uint8_t *)"abc<html>", 9, "<html") != NULL && mem_find((const uint8_t *)"abc", 3, "zz") == NULL);
    printf(fails ? "ПРОВАЛ %d\n" : "grabutil: все проверки пройдены\n", fails);
    return fails != 0;
}
