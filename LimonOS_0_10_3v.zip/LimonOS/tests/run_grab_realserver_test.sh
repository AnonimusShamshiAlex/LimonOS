#!/bin/bash
# grab/aikey против НАСТОЯЩЕГО python3 -m http.server: адрес без имени файла даёт список папки, адрес с именем — файл с ключом.
# Нужен root (TAP). Скачивает сетевой стек LimonOS (kernel/net.c, http.c).
cd "$(dirname "$0")/.."
T=/tmp/grabreal; rm -rf $T; mkdir -p $T/www; cd $T/www
printf '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\r\n' > keys.txt
cd - >/dev/null
python3 - <<'PY'
import os, fcntl, struct, socket
fd = os.open("/dev/net/tun", os.O_RDWR)
fcntl.ioctl(fd, 0x400454ca, struct.pack("16sH", b"limon0", 0x0002 | 0x1000))
fcntl.ioctl(fd, 0x400454cb, 1)
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
fcntl.ioctl(s, 0x8916, struct.pack("16sH2s4s8x", b"limon0", socket.AF_INET, b"\0\0", socket.inet_aton("10.0.2.1")))
fcntl.ioctl(s, 0x891c, struct.pack("16sH2s4s8x", b"limon0", socket.AF_INET, b"\0\0", socket.inet_aton("255.255.255.0")))
fl = struct.unpack("16sH14x", fcntl.ioctl(s, 0x8913, struct.pack("16sH14x", b"limon0", 0)))[1]
fcntl.ioctl(s, 0x8914, struct.pack("16sH14x", b"limon0", fl | 1))
PY
gcc -O2 -w -I kernel -I tests tests/netstack_host.c tests/nic_tap.c kernel/net.c kernel/tls.c kernel/crypto.c kernel/http.c kernel/format.c -o $T/ns || exit 1
gcc -O1 -w -I kernel -o $T/check tests/grab_check.c || exit 1
(cd $T/www && python3 -m http.server 8000 --bind 10.0.2.1 >$T/server.log 2>&1) &
SP=$!; sleep 1.5
fail=0
echo "1) как у тебя на скриншоте: адрес БЕЗ имени файла (http://10.0.2.1:8000)"
TMO=8000 LOSS=0 timeout 60 $T/ns http://10.0.2.1:8000 $T/root.bin 2>/dev/null; R=$($T/check $T/root.bin); echo "   $R"
echo "$R" | grep -q "список_папки=1 ключей=0" && echo "   ok   распознан как список папки, ключа нет, имена файлов показаны" || { echo "   FAIL"; fail=1; }
echo "$R" | grep -q "keys.txt" || { echo "   FAIL имена"; fail=1; }
echo "2) правильный адрес: http://10.0.2.1:8000/keys.txt"
TMO=8000 LOSS=0 timeout 60 $T/ns http://10.0.2.1:8000/keys.txt $T/keys.bin 2>/dev/null; R=$($T/check $T/keys.bin); echo "   $R"
echo "$R" | grep -q "список_папки=0 ключей=1" && echo "   ok   ключ найден в файле" || { echo "   FAIL"; fail=1; }
kill $SP 2>/dev/null
[ $fail = 0 ] && echo "grab на настоящем http.server: все проверки пройдены" || echo "ПРОВАЛ"
exit $fail
