#include <stdio.h>
#include <string.h>
#include "../kernel/keyfile.h"
#include "../kernel/keyfile.c"
static int fails;
#define CHECK(c) do{ if(!(c)){ printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } }while(0)
static int run(const char *s, struct keyfile_key *k) { return keyfile_find((const uint8_t *)s, strlen(s), k, KEYFILE_MAX); }
int main(void) {
    struct keyfile_key k[KEYFILE_MAX];
    const char *ant = "sk-ant-api03-AbCdEfGhIjKlMnOpQrStUvWxYz0123456789_-AbCdEfGhIjKlMnOpQrStUvWxYz0123456789_-AAAA";
    const char *orr = "sk-or-v1-0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    char buf[1000];
    CHECK(run(ant, k) == 1 && k[0].provider == 1 && !strcmp(k[0].text, ant));                       /* просто ключ без перевода строки */
    snprintf(buf, sizeof buf, "%s\n", ant);                           CHECK(run(buf, k) == 1 && !strcmp(k[0].text, ant));
    snprintf(buf, sizeof buf, "%s\r\n", orr);                         CHECK(run(buf, k) == 1 && k[0].provider == 2 && !strcmp(k[0].text, orr));   /* Windows */
    snprintf(buf, sizeof buf, "\xEF\xBB\xBF%s\r\n", orr);             CHECK(run(buf, k) == 1 && !strcmp(k[0].text, orr));                         /* BOM от блокнота */
    snprintf(buf, sizeof buf, "  \t%s  \n\n", ant);                   CHECK(run(buf, k) == 1 && !strcmp(k[0].text, ant));
    snprintf(buf, sizeof buf, "ANTHROPIC_API_KEY=%s\n", ant);         CHECK(run(buf, k) == 1 && !strcmp(k[0].text, ant));                         /* .env */
    snprintf(buf, sizeof buf, "key = \"%s\"\n", orr);                 CHECK(run(buf, k) == 1 && !strcmp(k[0].text, orr));                         /* в кавычках */
    snprintf(buf, sizeof buf, "{\"key\": '%s', \"x\": 1}", ant);      CHECK(run(buf, k) == 1 && !strcmp(k[0].text, ant));
    snprintf(buf, sizeof buf, "Anthropic:\n%s\nOpenRouter:\n%s\n", ant, orr);
    CHECK(run(buf, k) == 2 && k[0].provider == 1 && k[1].provider == 2 && !strcmp(k[1].text, orr));  /* два ключа в файле */
    snprintf(buf, sizeof buf, "%s\n%s\n", ant, ant);                  CHECK(run(buf, k) == 1);                                                      /* дубликаты не плодим */
    CHECK(run("", k) == 0);
    CHECK(run("sk-ant-", k) == 0 && run("sk-ant-short", k) == 0);                                    /* обрывки не считаем */
    CHECK(run("пароль: 12345\nничего похожего", k) == 0);
    CHECK(run("sk-proj-abcdefghijklmnopqrstuvwxyz0123456789", k) == 0);                              /* ключи других сервисов не путаем */
    char longk[400]; memset(longk, 'x', sizeof longk); memcpy(longk, "sk-ant-", 7); longk[399] = 0;
    CHECK(run(longk, k) == 0);                                                                       /* слишком длинное — не ключ */
    printf(fails ? "ПРОВАЛ %d\n" : "keyfile: все проверки пройдены\n", fails);
    return fails != 0;
}
