#!/bin/bash
# форматирование строк ядра (kernel/format.c): %s, %d, %.Ns …
set -e
cd "$(dirname "$0")/.."
gcc -O1 -w -Ikernel -o /tmp/format_host_test tests/format_host_test.c kernel/format.c
/tmp/format_host_test
