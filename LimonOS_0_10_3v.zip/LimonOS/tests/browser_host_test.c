#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../kernel/browser.c"
#include "../kernel/image.c"
void *kmalloc(size_t n){return calloc(1,n);} void kfree(void*p){free(p);}
int net_url_join(const char *b,const char *r,char *o,size_t m){
    if(!strncmp(r,"http",4)) snprintf(o,m,"%s",r);
    else if(r[0]=='/') snprintf(o,m,"https://site.org%s",r);
    else if(r[0]=='?') snprintf(o,m,"https://site.org/s%s",r);
    else snprintf(o,m,"https://site.org/%s",r);
    (void)b; return 0; }
static char *flat(struct page *pg, int show){   /* все строки подряд; show: оставить маркеры читаемыми */
    static char out[20000]; size_t o=0;
    for(int i=0;i<pg->nlines;i++){
        for(const char*p=pg->lines[i];*p;p++){
            if(*p==1){ if(show) o+=sprintf(out+o,"<c%c>",p[1]); p++; }
            else if(*p==2){ if(show) o+=sprintf(out+o,"<L%d>",((p[1]-'0')<<6)|(p[2]-'0')); p+=2; }
            else if(*p==3){ if(show) o+=sprintf(out+o,"</L>"); }
            else if(*p==4){ o+=sprintf(out+o,"[INPUT%d]",((p[1]-'0')<<6)|(p[2]-'0')); p+=2; }
            else if(*p==5){ o+=sprintf(out+o,"[BTN%d]",((p[1]-'0')<<6)|(p[2]-'0')); p+=2; }
            else if(*p==6){ if(show) o+=sprintf(out+o,"<#%.6s>",p+1); p+=6; }
            else if(*p==7){ if(show) o+=sprintf(out+o,"<b%c>",p[1]); p++; }
            else if(*p==8){ if(show) o+=sprintf(out+o,"<BG%.6s>",p+1); p+=6; }
            else out[o++]=*p;
        } out[o++]='\n'; }
    out[o]=0; return out;
}
static int img_calls; static char img_urls[8][100];
static int fake_img(const char *url, int mw, int mh, struct img *out){
    if (strstr(url, "bad")) return -1;
    if (img_calls < 8) snprintf(img_urls[img_calls], 100, "%s", url);
    img_calls++;
    int w = 100 < mw ? 100 : mw, h = 40 < mh ? 40 : mh;
    out->w = w; out->h = h; out->px = malloc((size_t)w*h*4); for (int i=0;i<w*h;i++) out->px[i]=0x123456; return 0; }
static int fetches; static char fetched_url[200];
static int fake_fetch(const char *url, char *out, size_t max){
    fetches++; snprintf(fetched_url,sizeof fetched_url,"%s",url);
    const char *css = ".ext{color:#ff8800} .bar{background:#112233} .gone{display:none}";
    snprintf(out,max,"%s",css); return (int)strlen(css); }
static int fails;
#define CHECK(c) do{ if(!(c)){ printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } }while(0)
#define HAS(s,x) (strstr((s),(x))!=NULL)

int main(void){
    static struct page pg;
    /* --- разметка, ссылки, формы --- */
    const char *h = "<!DOCTYPE html><html><head><title>Тест &amp; страница</title><style>p{color:red}</style>"
      "<script>var x='<b>no</b>';</script><meta http-equiv=\"refresh\" content=\"0; url=/new?a=1&amp;b=2\"></head><body>"
      "<h1>Заголовок</h1><p>Привет, <b>мир</b>! Это <a href=\"/page?x=1&amp;y=2\">ссылка &lt;тут&gt;</a> и длинный текст который должен перенестись на следующую строку потому что ширина маленькая.</p>"
      "<ul><li>раз<li>два <a href=\"#top\">якорь</a></ul><pre>a  b\n  c</pre>"
      "<form action=\"/search\" method=\"get\"><input type=\"hidden\" name=\"hl\" value=\"ru\"><input name=\"q\" value=\"лимон\">"
      "<input type=submit name=go value=\"Найти\"></form><img src=x.png alt=\"лого\"><noscript>без JS</noscript><!-- коммент --></body></html>";
    page_render(&pg, h, strlen(h), 40, "https://site.org/");
    printf("%s", flat(&pg, 1));
    CHECK(!strcmp(pg.title, "Тест & страница"));
    CHECK(!strcmp(pg.refresh, "https://site.org/new?a=1&b=2"));
    CHECK(pg.nlinks == 1 && !strcmp(pg.links[0], "https://site.org/page?x=1&y=2"));
    CHECK(pg.ninputs == 3 && pg.inputs[1].kind == IN_TEXT && !strcmp(pg.inputs[1].value, "лимон"));
    char u[700]; page_form_url(&pg, 0, 2, u, sizeof u);
    CHECK(!strcmp(u, "https://site.org/search?hl=ru&q=%D0%BB%D0%B8%D0%BC%D0%BE%D0%BD&go=%D0%9D%D0%B0%D0%B9%D1%82%D0%B8"));
    CHECK(!HAS(flat(&pg,0), "var x"));                 /* script не показывается */
    CHECK(HAS(flat(&pg,0), "• раз") && HAS(flat(&pg,0), "• два"));   /* <li> без </li> */
    for(int i=0;i<pg.nlines;i++) { int cols=0; for(const char*p=pg.lines[i];*p;p++){ if(*p==1||*p==7){p++;continue;} if(*p==6){p+=6;continue;} if(*p==2){p+=2;continue;} if(*p==3)continue; if(*p==4){cols+=PG_FIELD_COLS;p+=2;continue;} if(*p==5){cols+=(int)utf8_len(pg.inputs[((p[1]-'0')<<6)|(p[2]-'0')].value)+4;p+=2;continue;} if(((unsigned char)*p&0xC0)!=0x80)cols++; } CHECK(cols<=40); }
    page_free(&pg);

    /* --- CSS --- */
    memset(&pg,0,sizeof pg);
    const char *c =
      "<html><head><style>"
      " .hid{display:none} #big{color:#00f} .big{color:#f00} p.note{font-weight:bold}"
      " div > span{color:rgb(0,128,0)} .imp{color:green !important} /* комментарий */"
      " @media print { p{display:none} } a:hover{color:red} body{background:#202020}"
      " .c{text-align:center} ul li{color:navy}"
      "</style></head><body>"
      "<p class=hid>СКРЫТО-КЛАСС</p><div class=hid><p>СКРЫТО-ПОТОМОК</p></div>"
      "<p style=\"display:none\">СКРЫТО-INLINE</p><p hidden>СКРЫТО-ATTR</p>"
      "<p id=big class=big>цвет-ид</p>"
      "<p class=note>жирный</p>"
      "<div><span>зелёный</span></div><p><span>не-дочерний</span></p>"
      "<p class=big imp style=\"color:#123456\">inline-цвет</p>"
      "<p class=\"big imp\" style=\"color:#abcdef\">важный</p>"
      "<div class=c>центр</div>"
      "<ul><li>флот</li></ul>"
      "<p style=\"color:#000\">чёрный</p><p>виден после print-правила</p></body></html>";
    page_render(&pg, c, strlen(c), 40, "https://site.org/");
    char *t = flat(&pg, 1);
    printf("%s", t);
    CHECK(!HAS(t, "СКРЫТО"));
    CHECK(HAS(t, "<#10000FF>цвет-ид") || HAS(t, "<#1000FF>") || HAS(t, "0000FF>цвет-ид"));   /* #id сильнее .class */
    CHECK(HAS(t, "<b1>жирный"));
    CHECK(HAS(t, "008000>зелёный"));
    CHECK(!HAS(t, "008000>не-дочерний"));
    CHECK(HAS(t, "123456>inline-цвет"));                 /* inline сильнее класса */
    CHECK(HAS(t, "008000>важный"));                      /* !important сильнее inline */
    CHECK(pg.bg == 0x202020 && pg.dark == 1);
    CHECK(HAS(t, "виден после print-правила"));
    CHECK(HAS(t, "         центр") );                     /* центрирование: отступ слева */
    CHECK(HAS(t, "000080>флот") || HAS(t, "000080>"));   /* ul li */
    CHECK(HAS(t, "000000>чёрный"));                      /* чёрный цвет #000 не теряется */
    page_free(&pg);

    /* --- внешний CSS, фон блока, formaction --- */
    memset(&pg,0,sizeof pg);
    page_set_fetch(fake_fetch);
    const char *e =
      "<html><head><link rel=\"stylesheet\" href=\"/s/main.css\"><link rel=stylesheet media=print href=/print.css>"
      "<link rel=\"icon\" href=/f.ico></head><body>"
      "<div class=bar>панель</div><p class=ext>внешний</p><p class=gone>СКРЫТО-ВНЕШНИЙ</p>"
      "<form action=\"/s\"><input name=q value=\"a b\"><input type=submit value=One>"
      "<input type=submit value=Two formaction=\"https://e.org/x?query={q}&z=1\"></form></body></html>";
    page_render(&pg, e, strlen(e), 40, "https://site.org/dir/");
    t = flat(&pg, 1);
    printf("%s", t);
    CHECK(fetches == 1 && !strcmp(fetched_url, "https://site.org/s/main.css"));   /* print и icon не грузятся */
    CHECK(HAS(t, "<BG112233>") && HAS(t, "панель"));
    CHECK(HAS(t, "FF8800>внешний"));
    CHECK(!HAS(t, "СКРЫТО-ВНЕШНИЙ"));
    char fu[700];
    CHECK(pg.ninputs == 3);
    page_form_url(&pg, 0, 2, fu, sizeof fu); printf("форма2: %s\n", fu);
    CHECK(!strcmp(fu, "https://e.org/x?query=a+b&z=1"));
    page_form_url(&pg, 0, 1, fu, sizeof fu);
    CHECK(!strcmp(fu, "https://site.org/s?q=a+b&=One") || !strncmp(fu, "https://site.org/s?q=a+b", 24));
    page_free(&pg);
    page_set_fetch(NULL);

    /* --- textarea как поле, соседние ссылки --- */
    memset(&pg,0,sizeof pg);
    const char *g = "<form action=/search><textarea name=q rows=1></textarea><input type=submit name=btnK value=\"Поиск\"></form>"
                    "<div><a href=/a>Один</a><a href=/b>Два</a></div>";
    page_render(&pg, g, strlen(g), 60, "https://www.google.com/");
    t = flat(&pg, 0);
    printf("%s", t);
    CHECK(pg.ninputs == 2 && pg.inputs[0].kind == IN_TEXT && !strcmp(pg.inputs[0].name, "q"));
    CHECK(HAS(t, "[INPUT0]"));
    CHECK(HAS(t, "Один Два"));
    page_free(&pg);

    /* --- картинки --- */
    memset(&pg,0,sizeof pg);
    page_set_img_fetch(fake_img);
    const char *im =
      "<p>до</p><img src=/a.png alt=лого width=100><p>после</p>"
      "<a href=/go><img src=\"/b.jpg\" alt=\"в ссылке\"></a>"
      "<img src=/bad.png alt=\"запасной текст\"><img src=/px.gif width=1 height=1 alt=пиксель>"
      "<img src=\"data:image/gif;base64,R0lGODlhAQABAAAAACw=\" data-src=\"/lazy.png\">"
      "<div style=\"display:none\"><img src=/hidden.png></div>";
    page_render(&pg, im, strlen(im), 60, "https://site.org/d/");
    t = flat(&pg, 1);
    printf("%s", t);
    CHECK(pg.nimages == 3);                                    /* a.png, b.jpg, lazy.png; bad/tiny/скрытая — нет */
    CHECK(img_calls == 3 && !strcmp(img_urls[0], "https://site.org/a.png") && !strcmp(img_urls[1], "https://site.org/b.jpg") && !strcmp(img_urls[2], "https://site.org/lazy.png"));
    CHECK(HAS(t, "[запасной текст]"));                          /* не вышло — alt */
    CHECK(HAS(t, "[пиксель]") && !HAS(t, "hidden"));   /* крошечная не качается, остаётся alt; скрытая CSS — нет вовсе */
    { int rows = 0, linked = 0; for (int i = 0; i < pg.nlines; i++) { const char *l = pg.lines[i]; for (; *l; l++) if (*l == 9) { rows++; break; } if (strchr(pg.lines[i], 2) && strchr(pg.lines[i], 9)) linked++; }
      CHECK(rows == 3 * 3);                                    /* 40px = 3 строки по 16 px на картинку */
      CHECK(linked == 3); }                                    /* b.jpg внутри <a>: все 3 строки кликабельны */
    page_free(&pg);
    page_set_img_fetch(NULL);

    /* --- подстановка символов --- */
    CHECK(cp_fallback(0x2BB) == '\'' && cp_fallback(0xE9) == 'e' && cp_fallback(0x4B2) == 0x425 && cp_fallback(0x200B) == 0);
    size_t n; char *u8 = cp1251_to_utf8("\xcf\xf0\xe8\xe2\xe5\xf2", 6, &n); CHECK(!strcmp(u8, "Привет")); free(u8);
    printf(fails?"ПРОВАЛ %d\n":"парсер+CSS: все проверки пройдены\n", fails); return fails!=0; }
