/* grab_check root.bin|keys.bin  — что решили бы grab/aikey про скачанный файл */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../kernel/grabutil.h"
#include "../kernel/grabutil.c"
#include "../kernel/keyfile.h"
#include "../kernel/keyfile.c"
int main(int argc, char **argv) {
    FILE *f = fopen(argv[1], "rb"); if (!f) return 2;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *d = malloc((size_t)n + 1); if (fread(d, 1, (size_t)n, f) != (size_t)n) return 2;
    int listing = looks_like_dir_listing(d, (size_t)n);
    struct keyfile_key k[KEYFILE_MAX]; int nk = keyfile_find(d, (size_t)n, k, KEYFILE_MAX);
    char names[12][64]; int nn = listing_names(d, (size_t)n, names, 12);
    printf("%ld байт: список_папки=%d ключей=%d имён_в_списке=%d", n, listing, nk, nn);
    for (int i = 0; i < nn; i++) printf(" %s", names[i]);
    printf("\n");
    return 0;
}
