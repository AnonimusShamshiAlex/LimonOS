#ifndef LIMON_KEYFILE_H
#define LIMON_KEYFILE_H
#include <stddef.h>
#include <stdint.h>

/* Поиск API-ключей ИИ внутри текстового файла (key.txt, keys.txt, .env и т.п.).
 * Находит всё, что выглядит как sk-ant-… (Anthropic) или sk-or-… (OpenRouter), где бы оно ни стояло в строке:
 * «ключ», «ANTHROPIC_API_KEY=ключ», "ключ" в кавычках, с Windows-переводами строк и BOM. */
#define KEYFILE_MAX 8
#define KEYFILE_LEN 200

struct keyfile_key {
    char text[KEYFILE_LEN];
    int provider;                /* 1 — Anthropic, 2 — OpenRouter */
};

/* Возвращает сколько ключей найдено (не больше max) */
int keyfile_find(const uint8_t *data, size_t n, struct keyfile_key *out, int max);

#endif
