#include "keyfile.h"

static int starts(const uint8_t *d, size_t n, size_t i, const char *p) {
    for (size_t k = 0; p[k]; k++) if (i + k >= n || d[i + k] != (uint8_t)p[k]) return 0;
    return 1;
}

int keyfile_find(const uint8_t *d, size_t n, struct keyfile_key *out, int max) {
    int found = 0;
    size_t i = 0;
    while (i < n && found < max) {
        int prov = 0;
        if (starts(d, n, i, "sk-ant-")) prov = 1;
        else if (starts(d, n, i, "sk-or-")) prov = 2;
        if (!prov) { i++; continue; }
        size_t j = i;                                           /* ключ кончается на пробеле, кавычке, запятой, переводе строки */
        while (j < n && d[j] > ' ' && d[j] < 0x7F && d[j] != '"' && d[j] != '\'' && d[j] != ',' && d[j] != ';' && d[j] != '`') j++;
        size_t len = j - i;
        if (len >= 20 && len < KEYFILE_LEN) {
            int dup = 0;
            for (int k = 0; k < found && !dup; k++) {
                size_t m = 0; while (out[k].text[m] && m < len && out[k].text[m] == (char)d[i + m]) m++;
                if (m == len && !out[k].text[m]) dup = 1;
            }
            if (!dup) {
                for (size_t k = 0; k < len; k++) out[found].text[k] = (char)d[i + k];
                out[found].text[len] = 0;
                out[found].provider = prov;
                found++;
            }
        }
        i = j;
    }
    return found;
}
