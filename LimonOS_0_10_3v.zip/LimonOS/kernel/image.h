#ifndef LIMON_IMAGE_H
#define LIMON_IMAGE_H
#include <stddef.h>
#include <stdint.h>

/* Декодер картинок для браузера: PNG, JPEG (baseline), GIF (первый кадр). Всё на целых числах (в ядре нет FPU).
 * Не поддерживается: PNG с чересстрочной развёрткой (Adam7), progressive JPEG, CMYK, WebP/AVIF/SVG. */
struct img {
    int w, h;
    uint32_t *px;                /* w*h пикселей 0x00RRGGBB; прозрачность смешана с белым фоном */
};

#define IMG_E_FORMAT  (-1)       /* формат не поддерживается */
#define IMG_E_CORRUPT (-2)       /* файл повреждён */
#define IMG_E_MEMORY  (-3)       /* не хватило памяти или картинка слишком большая */

/* Расшифровывает картинку и сразу уменьшает так, чтобы влезла в max_w x max_h (увеличивать не будет).
 * 0 — успех (out->px освободить img_free), иначе IMG_E_*. */
int  img_decode(const uint8_t *data, size_t len, int max_w, int max_h, struct img *out);
void img_free(struct img *im);

/* base64 -> байты (для data:image/...;base64,...). Возвращает длину или -1. */
int  base64_decode(const char *s, size_t n, uint8_t *out, size_t max);

#endif
