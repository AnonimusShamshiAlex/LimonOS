#ifndef LIMON_GRABUTIL_H
#define LIMON_GRABUTIL_H
#include <stddef.h>
#include <stdint.h>

/* Помощники для grab/aikey: распознать «адрес без имени файла» и страницу «список папки» веб-сервера. */
const uint8_t *mem_find(const uint8_t *h, size_t n, const char *needle);     /* поиск подстроки в байтах */
int url_has_no_path(const char *url);                                         /* http://host:8000 или http://host:8000/ */
int looks_like_dir_listing(const uint8_t *d, size_t n);                       /* «Directory listing for…», «Index of /…» */
int listing_names(const uint8_t *d, size_t n, char names[][64], int max);     /* имена из href="…" такой страницы; возвращает сколько */

#endif
