/* Рабочий стол LimonOS: окна, панель задач, меню "Лимон", значки, курсор мыши. */
#include "desktop.h"
#include "gfx.h"
#include "font.h"
#include "term.h"
#include "shell.h"
#include "timer.h"
#include "rtc.h"
#include "power.h"
#include "io.h"
#include "sysinfo.h"
#include "net.h"
#include "http.h"
#include "tls.h"
#include "format.h"
#include "kstring.h"
#include "mem.h"
#include "browser.h"
#include "calc.h"

#define TASKBAR_H 32
#define TITLE_H   24
#define PAD       4
#define MAX_WIN   8
#define MAX_TERMS 4
#define MAX_BROWSERS 3
#define MAX_CALCS 2
#define START_W   96
#define TASKBTN_W 150
#define BR_COLS   108
#define BR_ROWS   30
#define TOOL_H    30          /* панель с кнопками и адресом */
#define STAT_H    18          /* строка состояния внизу */
#define SB_W      10          /* полоса прокрутки */
#define BR_HIST   12
#define CALC_W    220
#define CALC_H    300
#define CALC_COLS 4
#define CALC_ROWS 5

enum { WIN_TERM, WIN_ABOUT, WIN_BROWSER, WIN_CALC };

struct hit { int x, y, w, h, kind, idx; };        /* kind: 0 ссылка, 1 поле, 2 кнопка */

struct browser {
    struct page pg;
    int scroll;
    char cur[640];                  /* адрес открытой страницы */
    char addr[640]; int addr_focus; /* редактируемый адрес */
    char status[200];
    char hist[BR_HIST][400]; int hist_n, hist_pos;
    int focus_input;
    struct hit hits[220]; int nhits;
};


struct theme {
    const char *name;
    uint32_t bg_top, bg_bot, accent, on_accent, title_off, taskbar, body, term_bg, term_fg;
};

static const struct theme themes[] = {
    { "lemon",  0x2B3A4A, 0x10161E, 0xF4D91A, 0x14181F, 0x3A4554, 0x151B23, 0x1B222C, 0x0F141B, 0xD8DEE9 },
    { "lime",   0x24402B, 0x0C1A10, 0x8BD13A, 0x10180A, 0x35503B, 0x0F1B13, 0x16241A, 0x0C140F, 0xDDEBDD },
    { "orange", 0x40291A, 0x180D08, 0xFF9F1C, 0x1A1008, 0x55392A, 0x1D120B, 0x2A1A10, 0x150C07, 0xF1E3D6 },
    { "berry",  0x3A2145, 0x140A1A, 0xE0568C, 0x1A0A12, 0x4E3560, 0x1A0F22, 0x251530, 0x110818, 0xEBDDF0 },
    { "night",  0x16233A, 0x04070D, 0x6CB6FF, 0x08101A, 0x2B3C57, 0x0A111C, 0x101A2B, 0x070C14, 0xD6E4F5 },
};
#define NTHEMES ((int)(sizeof themes / sizeof themes[0]))

struct window {
    int used, minimized, type;
    int x, y, w, h;
    char title[32];
    struct term *term;
    struct shell *sh;
    struct browser *br;
    struct calc_state *calc;
    int slot;
};

static struct window wins[MAX_WIN];
static int zorder[MAX_WIN], zcount;
static struct term terms[MAX_TERMS];
static struct shell shells[MAX_TERMS];
static uint8_t term_used[MAX_TERMS];
static struct browser browsers[MAX_BROWSERS];
static uint8_t browser_used[MAX_BROWSERS];
static struct calc_state calcs[MAX_CALCS];
static uint8_t calc_used[MAX_CALCS];

/* раскладка кнопок калькулятора: символ, который видно, и команда, которую он посылает в calc_* */
struct calc_btn { const char *label; char cmd; };
static const struct calc_btn calc_layout[CALC_ROWS][CALC_COLS] = {
    { {"C",'C'}, {"<-",'B'}, {"%",'%'}, {"/",'/'} },
    { {"7",'7'}, {"8",'8'}, {"9",'9'}, {"*",'*'} },
    { {"4",'4'}, {"5",'5'}, {"6",'6'}, {"-",'-'} },
    { {"1",'1'}, {"2",'2'}, {"3",'3'}, {"+",'+'} },
    { {"+/-",'N'}, {"0",'0'}, {".",'.'}, {"=",'='} },
};

static void calc_press(struct calc_state *s, char cmd) {
    if (cmd >= '0' && cmd <= '9') calc_digit(s, cmd);
    else if (cmd == '.') calc_dot(s);
    else if (cmd == 'C') calc_clear(s);
    else if (cmd == 'B') calc_backspace(s);
    else if (cmd == 'N') calc_negate(s);
    else if (cmd == '%') calc_percent(s);
    else if (cmd == '=') calc_equals(s);
    else calc_op(s, cmd);                     /* '+' '-' '*' '/' */
}

static int dw, dh;                 /* размер рабочего стола */
static int cur_theme;
static int redraw = 1;
static int mx, my;
static int prev_left;
static int drag_win = -1, drag_dx, drag_dy;
static int start_open;
static uint64_t last_click_tick;
static int last_click_icon = -1;
static int blink_phase;
static struct rtc_time now;
static uint64_t last_sec = ~0ULL;

static const struct theme *T(void) { return &themes[cur_theme]; }

/* ---------- темы ---------- */

int desktop_theme_count(void) { return NTHEMES; }
int desktop_theme_index(void) { return cur_theme; }
const char *desktop_theme_name(void) { return themes[cur_theme].name; }
const char *desktop_theme_name_at(int i) { return (i >= 0 && i < NTHEMES) ? themes[i].name : "?"; }
uint32_t desktop_theme_accent(int i) { return (i >= 0 && i < NTHEMES) ? themes[i].accent : 0xFFFFFF; }
void desktop_set_theme(int i) { if (i >= 0 && i < NTHEMES) { cur_theme = i; redraw = 1; } }
int desktop_theme_find(const char *name) {
    for (int i = 0; i < NTHEMES; i++) if (strcmp(themes[i].name, name) == 0) return i;
    return -1;
}

/* ---------- окна ---------- */

static int z_find(int idx) { for (int i = 0; i < zcount; i++) if (zorder[i] == idx) return i; return -1; }

static void z_to_top(int idx) {
    int i = z_find(idx);
    if (i < 0) return;
    for (; i < zcount - 1; i++) zorder[i] = zorder[i + 1];
    zorder[zcount - 1] = idx;
}

static void z_remove(int idx) {
    int i = z_find(idx);
    if (i < 0) return;
    for (; i < zcount - 1; i++) zorder[i] = zorder[i + 1];
    zcount--;
}

static int top_window(void) {
    for (int i = zcount - 1; i >= 0; i--)
        if (!wins[zorder[i]].minimized) return zorder[i];
    return -1;
}

static void focus_window(int idx) { wins[idx].minimized = 0; z_to_top(idx); }

static int alloc_window(int type, int w, int h, const char *title) {
    int idx = -1;
    for (int i = 0; i < MAX_WIN; i++) if (!wins[i].used) { idx = i; break; }
    if (idx < 0) return -1;
    struct window *win = &wins[idx];
    memset(win, 0, sizeof *win);
    win->used = 1; win->type = type; win->w = w; win->h = h;
    int k = 0;
    for (int i = 0; i < MAX_WIN; i++) if (wins[i].used && i != idx) k++;
    win->x = 130 + (k % 6) * 28;
    win->y = 20 + (k % 6) * 28;
    if (win->x + w > dw) win->x = dw - w;
    if (win->y + h > dh - TASKBAR_H) win->y = dh - TASKBAR_H - h;
    if (win->x < 0) win->x = 0;
    if (win->y < 0) win->y = 0;
    ksnprintf(win->title, sizeof win->title, "%s", title);
    zorder[zcount++] = idx;
    return idx;
}

int desktop_open_terminal(void) {
    int slot = -1;
    for (int i = 0; i < MAX_TERMS; i++) if (!term_used[i]) { slot = i; break; }
    if (slot < 0) return -1;
    char title[32];
    ksnprintf(title, sizeof title, "Терминал %d", slot + 1);
    int wi = alloc_window(WIN_TERM, TERM_COLS * FONT_W + 2 * PAD + 2, TITLE_H + TERM_ROWS * FONT_H + 2 * PAD + 1, title);
    if (wi < 0) return -1;
    term_used[slot] = 1;
    wins[wi].term = &terms[slot];
    wins[wi].sh = &shells[slot];
    wins[wi].slot = slot;
    term_init(&terms[slot]);
    shell_init(&shells[slot], &terms[slot]);
    focus_window(wi);
    redraw = 1;
    return wi;
}

void desktop_open_about(void) {
    for (int i = 0; i < MAX_WIN; i++)
        if (wins[i].used && wins[i].type == WIN_ABOUT) { focus_window(i); redraw = 1; return; }
    int wi = alloc_window(WIN_ABOUT, 470, 330, "О системе");
    if (wi >= 0) focus_window(wi);
    redraw = 1;
}

static const char home_html[] =
    "<h1>Цитрус</h1><p>Браузер LimonOS. Введи слова и выбери поисковик (или адрес сверху, Ctrl+L):</p>"
    "<form action=\"https://www.mojeek.com/search\" method=\"get\"><input name=\"q\">"
    "<input type=\"submit\" value=\"Mojeek\"> <input type=\"submit\" value=\"Bing\" formaction=\"https://www.bing.com/search?q={q}\">"
    "<input type=\"submit\" value=\"Wiby\" formaction=\"https://wiby.me/?q={q}\">"
    "<input type=\"submit\" value=\"Marginalia\" formaction=\"https://search.marginalia.nu/search?query={q}\">"
    "<input type=\"submit\" value=\"DuckDuckGo\" formaction=\"https://html.duckduckgo.com/html/?q={q}\">"
    "<input type=\"submit\" value=\"Brave\" formaction=\"https://search.brave.com/search?q={q}\"></form>"
    "<p>В адресной строке: слова = поиск; <b>b слова</b> Bing, <b>m</b> Mojeek, <b>w</b> Wiby, <b>n</b> Marginalia, <b>d</b> DuckDuckGo, "
    "<b>br</b> Brave; <b>!b</b> — сделать Bing поиском по умолчанию.</p>"
    "<p>Сайты:</p><ul><li><a href=\"https://en.wikipedia.org/wiki/Lemon\">Wikipedia: Lemon</a></li>"
    "<li><a href=\"https://ru.wikipedia.org/\">Википедия</a></li>"
    "<li><a href=\"https://github.com/AnonimusShamshiAlex/LimonOS\">LimonOS на GitHub</a></li>"
    "<li><a href=\"https://news.ycombinator.com/\">Hacker News</a></li>"
    "<li><a href=\"https://lite.cnn.com/\">CNN Lite</a></li>"
    "<li><a href=\"https://text.npr.org/\">NPR (текстовая версия)</a></li>"
    "<li><a href=\"https://example.com/\">example.com</a></li></ul>"
    "<hr><p>Умеет: ссылки, формы, CSS (в т.ч. внешние файлы), windows-1251. Пока нет: JavaScript (Google, YouTube, соцсети) и картинки.</p>";

struct engine { const char *key, *name, *url; };        /* url: %s — слова запроса */
static const struct engine engines[] = {
    { "m",  "Mojeek",     "https://www.mojeek.com/search?q=%s" },
    { "b",  "Bing",       "https://www.bing.com/search?q=%s" },
    { "w",  "Wiby",       "https://wiby.me/?q=%s" },
    { "n",  "Marginalia", "https://search.marginalia.nu/search?query=%s" },
    { "d",  "DuckDuckGo", "https://html.duckduckgo.com/html/?q=%s" },
    { "br", "Brave",      "https://search.brave.com/search?q=%s" },
};
static int default_engine = 0;

static void set_win_title(struct window *w, const char *title, const char *fallback) {
    const char *t = title[0] ? title : fallback;
    char buf[32] = "Цитрус: ";
    size_t o = strlen(buf);
    const char *p = t;
    while (*p) {
        const char *q = p; utf8_next(&q);
        if (o + (size_t)(q - p) >= sizeof buf) break;
        for (; p < q; p++) buf[o++] = *p;
    }
    buf[o] = 0;
    ksnprintf(w->title, sizeof w->title, "%s", buf);
}

static const char *url_host_part(const char *url) {
    for (const char *p = url; p[0] && p[1] && p[2]; p++)
        if (p[0] == ':' && p[1] == '/' && p[2] == '/') return p + 3;
    return url;
}

static int ct_is(const char *ct, const char *what) {
    for (const char *p = ct; *p; p++) {
        size_t j = 0;
        while (what[j] && p[j] && ((p[j] >= 'A' && p[j] <= 'Z') ? p[j] + 32 : p[j]) == what[j]) j++;
        if (!what[j]) return 1;
    }
    return 0;
}

static void hist_push(struct browser *b, const char *url) {
    if (strlen(url) >= sizeof b->hist[0]) return;
    b->hist_n = b->hist_pos + 1;
    if (b->hist_n >= BR_HIST) {
        for (int i = 1; i < BR_HIST; i++) memcpy(b->hist[i - 1], b->hist[i], sizeof b->hist[0]);
        b->hist_n = BR_HIST - 1;
    }
    memcpy(b->hist[b->hist_n], url, strlen(url) + 1);
    b->hist_pos = b->hist_n;
    b->hist_n++;
}

static struct browser *loading_b;

static int fetch_css(const char *url, char *out, size_t max) {
    if (loading_b) { ksnprintf(loading_b->status, sizeof loading_b->status, "Загрузка стилей %s ...", url_host_part(url)); redraw = 1; desktop_frame(); }
    struct http_opts o; memset(&o, 0, sizeof o);
    o.max_bytes = max - 1; o.timeout_ms = 6000; o.max_redirects = 4;
    struct http_resp r;
    int rc = http_fetch(url, &o, &r);
    if (rc != HTTP_OK || r.status != 200 || !r.len) { http_free(&r); return -1; }
    size_t n = r.len < max ? r.len : max;
    memcpy(out, r.data, n);
    http_free(&r);
    return (int)n;
}

static int images_on = 1;
static int img_counter;

static int fetch_image(const char *url, int mw, int mh, struct img *out) {
    if (!images_on) return -1;
    uint8_t *tmp = NULL; const uint8_t *data = NULL; size_t len = 0;
    struct http_resp r; int have_resp = 0;
    if (strncmp(url, "data:", 5) == 0) {                          /* data:image/png;base64,.... */
        const char *c = url; while (*c && *c != ',') c++;
        if (!*c) return -1;
        int b64 = 0; for (const char *q = url; q + 6 <= c; q++) if (strncmp(q, "base64", 6) == 0) b64 = 1;
        if (!b64) return -1;
        size_t n = strlen(c + 1);
        tmp = kmalloc(n * 3 / 4 + 8);
        if (!tmp) return -1;
        int dl = base64_decode(c + 1, n, tmp, n * 3 / 4 + 8);
        if (dl <= 0) { kfree(tmp); return -1; }
        data = tmp; len = (size_t)dl;
    } else {
        if (loading_b) { ksnprintf(loading_b->status, sizeof loading_b->status, "Картинка %d: %s ...", ++img_counter, url_host_part(url)); redraw = 1; desktop_frame(); }
        struct http_opts o; memset(&o, 0, sizeof o);
        o.max_bytes = 900 * 1024; o.timeout_ms = 7000; o.max_redirects = 3;
        int rc = http_fetch(url, &o, &r);
        have_resp = 1;
        if (rc != HTTP_OK || r.status != 200 || !r.len) { http_free(&r); return -1; }
        data = r.data; len = r.len;
    }
    int rc = img_decode(data, len, mw, mh, out);
    if (tmp) kfree(tmp);
    if (have_resp) http_free(&r);
    return rc == 0 ? 0 : -1;
}

/* Поиск Google без JavaScript не отдаёт результатов: переносим запрос в поисковик по умолчанию.
 * Возвращает 1 и адрес в out, если url — поиск Google. */
static int google_search_rewrite(const char *url, char *out, size_t max) {
    const char *p = url;
    if (strncmp(p, "https://", 8) == 0) p += 8; else if (strncmp(p, "http://", 7) == 0) p += 7; else return 0;
    if (strncmp(p, "www.google.", 11) != 0 && strncmp(p, "google.", 7) != 0) return 0;
    while (*p && *p != '/') p++;
    if (strncmp(p, "/search?", 8) != 0) return 0;
    p += 8;
    while (*p) {
        if (p[0] == 'q' && p[1] == '=') {
            char q[300]; size_t n = 0;
            for (p += 2; *p && *p != '&' && n < sizeof q - 1; p++) q[n++] = *p;
            q[n] = 0;
            if (!n) return 0;
            ksnprintf(out, max, engines[default_engine].url, q);        /* q уже закодирован формой */
            return 1;
        }
        while (*p && *p != '&') p++;
        if (*p == '&') p++;
    }
    return 0;
}

/* Загружает страницу. 0 — успех; -1 — не удалось (старая страница остаётся). */
static int browser_load(struct window *w, struct browser *b, const char *url0, int push) {
    char url[640];
    ksnprintf(url, sizeof url, "%s", url0);
    int via_google = 0;
    { char rw[640]; if (google_search_rewrite(url0, rw, sizeof rw)) { ksnprintf(url, sizeof url, "%s", rw); via_google = 1; } }
    ksnprintf(b->status, sizeof b->status, "Загрузка %s ...", url);
    redraw = 1; desktop_frame();                 /* показать "Загрузка..." перед долгим запросом */

    loading_b = b;
    page_set_fetch(fetch_css);
    page_set_img_fetch(fetch_image);
    img_counter = 0;
    http_set_ua(2);                              /* для сайтов представляемся как Firefox */
    int ok = -1;
    for (int hop = 0; hop < 4; hop++) {
        struct http_opts o; memset(&o, 0, sizeof o);
        o.max_bytes = 2u << 20;                  /* страницы читаем до 2 МиБ */
        struct http_resp r;
        int rc = http_fetch(url, &o, &r);
        if (rc == HTTP_OK && (r.status == 403 || r.status == 406)) {      /* не любит наш User-Agent — пробуем текстовый */
            http_free(&r);
            http_set_ua(1);
            rc = http_fetch(url, &o, &r);
            http_set_ua(2);
        }
        if (rc != HTTP_OK) {
            if (rc == HTTP_E_TLS) ksnprintf(b->status, sizeof b->status, "TLS: %s", tls_strerror(r.tls_err));
            else ksnprintf(b->status, sizeof b->status, "%s", http_strerror(rc));
            http_free(&r);
            break;
        }
        const char *ct = r.content_type;
        const char *body = (const char *)r.data;
        size_t blen = r.len;
        int is_html = !ct[0] || ct_is(ct, "html");
        int is_text = ct_is(ct, "text/") || ct_is(ct, "json") || ct_is(ct, "xml") || ct_is(ct, "javascript");
        if (!is_html && !is_text) {
            ksnprintf(b->status, sizeof b->status, "Тип «%s» не показывается в браузере (%d байт). Скачать в память: grab %s", ct, (int)blen, r.url);
            http_free(&r);
            break;
        }
        char *conv = NULL; size_t clen = 0;
        int cp1251 = ct_is(ct, "1251");
        if (!cp1251 && !ct_is(ct, "charset")) {
            size_t head = blen < 2048 ? blen : 2048;
            char tmp[2049]; for (size_t i = 0; i < head; i++) tmp[i] = body[i]; tmp[head] = 0;
            cp1251 = ct_is(tmp, "windows-1251");
        }
        if (cp1251) { conv = cp1251_to_utf8(body, blen, &clen); if (conv) { body = conv; blen = clen; } }

        page_free(&b->pg);
        if (is_html) page_render(&b->pg, body, blen, BR_COLS, r.url);
        else page_render_text(&b->pg, body, blen, BR_COLS);
        if (conv) kfree(conv);

        b->scroll = 0; b->focus_input = -1; b->addr_focus = 0;
        ksnprintf(b->cur, sizeof b->cur, "%s", r.url);
        ksnprintf(b->status, sizeof b->status, "%s HTTP %d | %d КБ | строк %d",
                  r.https ? "https (сертификат не проверен)" : "http (без шифрования)", r.status, (int)((r.len + 1023) / 1024), b->pg.nlines);
        set_win_title(w, b->pg.title, url_host_part(r.url));
        if (via_google) {
            size_t sl = strlen(b->status);
            ksnprintf(b->status + sl, sizeof b->status - sl, " | Google без JavaScript не ищет: показан %s", engines[default_engine].name);
        }
        if (push) hist_push(b, r.url);
        ok = 0;
        char next[640]; next[0] = 0;
        if (b->pg.refresh[0] && strcmp(b->pg.refresh, r.url) != 0 && hop < 3) ksnprintf(next, sizeof next, "%s", b->pg.refresh);
        http_free(&r);
        if (next[0]) {                                  /* <meta refresh>: идём дальше */
            ksnprintf(url, sizeof url, "%s", next);
            push = 0;
            if (b->hist_pos >= 0 && b->hist_pos < b->hist_n) ksnprintf(b->hist[b->hist_pos], sizeof b->hist[0], "%s", url);
            continue;
        }
        break;
    }
    http_set_ua(0);
    loading_b = NULL;
    redraw = 1;
    return ok;
}

static void browser_show_home(struct window *w, struct browser *b) {
    page_free(&b->pg);
    page_render(&b->pg, home_html, sizeof home_html - 1, BR_COLS, "https://citrus.local/");
    b->scroll = 0; b->focus_input = -1; b->cur[0] = 0;
    ksnprintf(b->status, sizeof b->status, "Готов");
    set_win_title(w, "", "старт");
    if (b->hist_n == 0) { b->hist_pos = -1; }
}

/* то, что человек набрал в адресной строке: адрес или слова для поиска */
static int browser_go_typed(struct window *w, struct browser *b, const char *text) {
    char t[300]; size_t l = 0;
    while (*text == ' ') text++;
    while (*text && l < sizeof t - 1) t[l++] = *text++;
    while (l && t[l - 1] == ' ') l--;
    t[l] = 0;
    if (!l) return -1;
    char url[640];
    int has_space = 0, has_dot = 0;
    for (size_t i = 0; i < l; i++) { if (t[i] == ' ') has_space = 1; if (t[i] == '.') has_dot = 1; }
    if (strncmp(t, "http://", 7) == 0 || strncmp(t, "https://", 8) == 0) return browser_load(w, b, t, 1);
    if (strcmp(t, "!img") == 0) {                                     /* включить/выключить картинки */
        images_on = !images_on;
        ksnprintf(b->status, sizeof b->status, "Картинки: %s (обновить страницу: Ctrl+R)", images_on ? "включены" : "выключены — страницы грузятся быстрее");
        return 0;
    }
    /* "!b" — сделать поисковик по умолчанию */
    if (t[0] == '!' && t[1]) {
        for (unsigned i = 0; i < sizeof engines / sizeof engines[0]; i++)
            if (strcmp(t + 1, engines[i].key) == 0 || strcmp(t + 1, engines[i].name) == 0) {
                default_engine = (int)i;
                ksnprintf(b->status, sizeof b->status, "Поиск по умолчанию: %s", engines[i].name);
                return 0;
            }
        ksnprintf(b->status, sizeof b->status, "Нет такого поисковика: %s", t + 1);
        return -1;
    }
    /* "b слова" — поиск конкретным поисковиком */
    {
        size_t kl = 0; while (t[kl] && t[kl] != ' ') kl++;
        if (t[kl] == ' ' && kl <= 2) {
            for (unsigned i = 0; i < sizeof engines / sizeof engines[0]; i++)
                if (strlen(engines[i].key) == kl && strncmp(engines[i].key, t, kl) == 0) {
                    char q[300]; url_encode(t + kl + 1, q, sizeof q);
                    ksnprintf(url, sizeof url, engines[i].url, q);
                    return browser_load(w, b, url, 1);
                }
        }
    }
    if (has_space || (!has_dot && strncmp(t, "localhost", 9) != 0)) {
        char q[300]; url_encode(t, q, sizeof q);
        ksnprintf(url, sizeof url, engines[default_engine].url, q);
        return browser_load(w, b, url, 1);
    }
    ksnprintf(url, sizeof url, "https://%s", t);
    if (browser_load(w, b, url, 1) == 0) return 0;
    ksnprintf(url, sizeof url, "http://%s", t);                      /* сайт без https */
    return browser_load(w, b, url, 1);
}

int desktop_browse(const char *text) {
    int slot = -1;
    for (int i = 0; i < MAX_BROWSERS; i++) if (!browser_used[i]) { slot = i; break; }
    if (slot < 0) return -1;
    struct browser *b = &browsers[slot];
    memset(b, 0, sizeof *b);
    b->focus_input = -1; b->hist_pos = -1;
    browser_used[slot] = 1;
    int wi = alloc_window(WIN_BROWSER, BR_COLS * FONT_W + 2 * PAD + 2 + SB_W, TITLE_H + TOOL_H + BR_ROWS * FONT_H + STAT_H + 1, "Цитрус");
    if (wi < 0) { browser_used[slot] = 0; return -1; }
    wins[wi].br = b;
    wins[wi].slot = slot;
    wins[wi].x = 20; wins[wi].y = 10;
    focus_window(wi);
    browser_show_home(&wins[wi], b);
    if (text && text[0]) browser_go_typed(&wins[wi], b, text);
    else { b->addr_focus = 1; b->addr[0] = 0; }
    redraw = 1;
    return wi;
}

int desktop_open_browser(const char *url) { return desktop_browse(url); }

int desktop_open_calculator(void) {
    int slot = -1;
    for (int i = 0; i < MAX_CALCS; i++) if (!calc_used[i]) { slot = i; break; }
    if (slot < 0) return -1;
    calc_init(&calcs[slot]);
    calc_used[slot] = 1;
    int wi = alloc_window(WIN_CALC, CALC_W, TITLE_H + CALC_H, "Лимонка");
    if (wi < 0) { calc_used[slot] = 0; return -1; }
    wins[wi].calc = &calcs[slot];
    wins[wi].slot = slot;
    focus_window(wi);
    redraw = 1;
    return wi;
}

static void close_window(int idx) {
    struct window *w = &wins[idx];
    if (w->type == WIN_TERM) term_used[w->slot] = 0;
    else if (w->type == WIN_BROWSER) { page_free(&w->br->pg); browser_used[w->slot] = 0; }
    else if (w->type == WIN_CALC) calc_used[w->slot] = 0;
    w->used = 0;
    z_remove(idx);
    redraw = 1;
}

/* ---------- геометрия ---------- */

static int in_rect(int px, int py, int x, int y, int w, int h) {
    return px >= x && py >= y && px < x + w && py < y + h;
}

static int win_at(int px, int py) {
    for (int i = zcount - 1; i >= 0; i--) {
        struct window *w = &wins[zorder[i]];
        if (!w->minimized && in_rect(px, py, w->x, w->y, w->w, w->h)) return zorder[i];
    }
    return -1;
}

static int close_hit(const struct window *w, int px, int py) { return in_rect(px, py, w->x + w->w - 22, w->y + 4, 18, 16); }
static int min_hit(const struct window *w, int px, int py)   { return in_rect(px, py, w->x + w->w - 44, w->y + 4, 18, 16); }

#define CALC_GAP 6
#define CALC_DISP_H 56
static void calc_btn_rect(const struct window *w, int row, int col, int *bx, int *by, int *bw, int *bh) {
    int avail_w = CALC_W - 2 * CALC_GAP;
    int avail_h = CALC_H - CALC_DISP_H - (CALC_ROWS + 1) * CALC_GAP;
    int cw = (avail_w - (CALC_COLS - 1) * CALC_GAP) / CALC_COLS;
    int ch = avail_h / CALC_ROWS;
    *bw = cw; *bh = ch;
    *bx = w->x + CALC_GAP + col * (cw + CALC_GAP);
    *by = w->y + TITLE_H + CALC_DISP_H + CALC_GAP + row * (ch + CALC_GAP);
}

#define ICON_COUNT 4
static const char *const icon_label[ICON_COUNT] = { "Терминал", "О системе", "Лимонка", "Цитрус" };
static void icon_rect(int i, int *x, int *y) { *x = 12; *y = 16 + i * 100; }

static const char *const menu_items[] = { "Терминал", "О системе", "Лимонка (калькулятор)", "Цитрус (браузер)", "Следующая тема", "Перезагрузка", "Выключение" };
#define MENU_N 7
#define MENU_W 210
#define MENU_ITEM_H 28
static void menu_rect(int *x, int *y, int *w, int *h) {
    *w = MENU_W; *h = MENU_N * MENU_ITEM_H + 8; *x = 0; *y = dh - TASKBAR_H - *h;
}

/* ---------- рисование ---------- */

static void draw_lemon(int cx, int cy, int r, uint32_t alpha) {
    gfx_fill_ellipse_a(cx, cy, r + r / 3, r, 0xF4D91A, alpha);
    gfx_fill_ellipse_a(cx - r / 3, cy - r / 3, r / 3, r / 4, 0xFFF9C4, alpha / 2);
    gfx_fill_ellipse_a(cx + r + r / 3, cy - r / 8, r / 8 + 1, r / 8 + 1, 0xE0C010, alpha);
    gfx_fill_ellipse_a(cx + r / 2, cy - r - r / 6, r / 3, r / 6 + 1, 0x4CAF50, alpha);
}

static void draw_wallpaper(void) {
    const struct theme *t = T();
    gfx_vgradient(0, 0, dw, dh, t->bg_top, t->bg_bot);
    int r = dh / 7;
    draw_lemon(dw * 4 / 5, dh * 2 / 5, r, 26);
    const char *mark = "LimonOS";
    int tw = gfx_text_width(mark, 3);
    gfx_draw_text(dw - tw - 24, dh - TASKBAR_H - 64, mark, gfx_mix(t->bg_bot, t->accent, 70), 3);
}

static void draw_icons(void) {
    const struct theme *t = T();
    for (int i = 0; i < ICON_COUNT; i++) {
        int x, y;
        icon_rect(i, &x, &y);
        if (in_rect(mx, my, x, y, 88, 90)) gfx_blend_rect(x, y, 88, 90, 0xFFFFFF, 28);
        int px = x + 20, py = y + 6;
        if (i == 0) {
            gfx_fill_rect(px, py, 48, 48, 0x0F141B);
            gfx_draw_rect(px, py, 48, 48, t->accent);
            gfx_fill_rect(px, py, 48, 6, t->accent);
            gfx_draw_text(px + 8, py + 12, ">_", t->accent, 2);
        } else if (i == 1) {
            gfx_fill_ellipse(px + 24, py + 24, 24, 24, t->accent);
            gfx_draw_text(px + 16, py + 8, "i", t->on_accent, 2);
        } else if (i == 3) {                                     /* Цитрус: окно браузера с «глобусом» */
            gfx_fill_rect(px, py, 48, 48, 0xF4F6F8);
            gfx_draw_rect(px, py, 48, 48, t->accent);
            gfx_fill_rect(px, py, 48, 10, t->accent);
            gfx_fill_ellipse(px + 24, py + 30, 14, 14, 0x2C7BE5);
            gfx_fill_rect(px + 10, py + 29, 28, 2, 0xF4F6F8);
            gfx_fill_rect(px + 23, py + 16, 2, 28, 0xF4F6F8);
        } else {
            gfx_fill_rect(px, py, 48, 48, 0x202A38);
            gfx_draw_rect(px, py, 48, 48, t->accent);
            gfx_fill_rect(px + 6, py + 6, 36, 12, t->term_bg);
            for (int r = 0; r < 2; r++)
                for (int c = 0; c < 3; c++)
                    gfx_fill_rect(px + 6 + c * 13, py + 24 + r * 13, 9, 9, t->accent);
        }
        int lw = gfx_text_width(icon_label[i], 1);
        gfx_draw_text(x + 44 - lw / 2 + 1, y + 63, icon_label[i], 0x000000, 1);
        gfx_draw_text(x + 44 - lw / 2, y + 62, icon_label[i], 0xFFFFFF, 1);
    }
}

static uint32_t term_color(uint32_t fg) {
    if (fg == TC_DEFAULT) return T()->term_fg;
    if (fg == TC_ACCENT) return T()->accent;
    return fg;
}

static void draw_term_content(struct window *w, int focused) {
    const struct theme *t = T();
    struct term *tm = w->term;
    int cx0 = w->x + 1 + PAD, cy0 = w->y + TITLE_H + PAD;
    gfx_fill_rect(cx0 - PAD, cy0 - PAD, w->w - 2, w->h - TITLE_H - 1, t->term_bg);
    for (int r = 0; r < TERM_ROWS; r++)
        for (int c = 0; c < TERM_COLS; c++) {
            struct tcell *cell = &tm->cell[r][c];
            if (cell->cp != ' ')
                gfx_draw_glyph(cx0 + c * FONT_W, cy0 + r * FONT_H, cell->cp, term_color(cell->fg), 1);
        }
    if (focused && blink_phase == 0 && tm->cx < TERM_COLS) {
        int px = cx0 + tm->cx * FONT_W, py = cy0 + tm->cy * FONT_H;
        gfx_fill_rect(px, py, FONT_W, FONT_H, t->accent);
        uint32_t cp = tm->cell[tm->cy][tm->cx].cp;
        if (cp != ' ') gfx_draw_glyph(px, py, cp, t->term_bg, 1);
    }
}

static uint32_t pg_color(int c, int dark) {
    if (dark) {
        switch (c) {
        case PG_C_HEAD: return 0xFFD84D;
        case PG_C_LINK: return 0x8AB4F8;
        case PG_C_DIM:  return 0x9AA0A6;
        case PG_C_CODE: return 0x9BE564;
        default:        return 0xE6E6E6;
        }
    }
    switch (c) {
    case PG_C_HEAD: return 0x0B3D91;
    case PG_C_LINK: return 0x0B57D0;
    case PG_C_DIM:  return 0x6B7280;
    case PG_C_CODE: return 0x0B6B2A;
    default:        return 0x1F2328;
    }
}

static void add_hit(struct browser *b, int x, int y, int w, int h, int kind, int idx) {
    if (b->nhits >= (int)(sizeof b->hits / sizeof b->hits[0])) return;
    b->hits[b->nhits++] = (struct hit){ x, y, w, h, kind, idx };
}

static uint32_t hex6(const char *p) {
    uint32_t v = 0;
    for (int i = 0; i < 6; i++) { char c = p[i]; v = v * 16 + (uint32_t)(c <= '9' ? c - '0' : c - 'A' + 10); }
    return v;
}

static void draw_page_line(struct browser *b, int x, int y, const char *line, int focused) {
    const struct theme *t = T();
    int dark = b->pg.dark;
    uint32_t fg0 = pg_color(PG_C_TEXT, dark);
    int px = x, link = -1, link_x0 = 0, bold = 0;
    uint32_t col = fg0;
    const char *p = line;
    while (*p) {
        unsigned char c = (unsigned char)*p;
        if (c == PGM_BG) {                                         /* фон блока на всю строку; текст подбираем по яркости */
            uint32_t bgc = hex6(p + 1); p += 7;
            gfx_fill_rect(x - PAD, y, BR_COLS * FONT_W + 2 * PAD, FONT_H, bgc);
            int lum = (int)(((bgc >> 16) & 255) * 30 + ((bgc >> 8) & 255) * 59 + (bgc & 255) * 11) / 100;
            dark = lum < 110;
            fg0 = pg_color(PG_C_TEXT, dark); col = fg0;
            continue;
        }
        if (c == PGM_COLOR) { col = pg_color(p[1] - '0', dark); p += 2; continue; }
        if (c == PGM_RGB) { col = hex6(p + 1); p += 7; continue; }
        if (c == PGM_BOLD) { bold = (p[1] == '1'); p += 2; continue; }
        if (c == PGM_LINK) { link = ((p[1] - '0') << 6) | (p[2] - '0'); link_x0 = px; p += 3; continue; }
        if (c == PGM_LINKEND) {
            if (link >= 0 && px > link_x0) { gfx_fill_rect(link_x0, y + FONT_H - 2, px - link_x0, 1, col); add_hit(b, link_x0, y, px - link_x0, FONT_H, 0, link); }
            link = -1; p++; continue;
        }
        if (c == PGM_IMG) {                                         /* одна 16-пиксельная полоса картинки */
            int idx = ((p[1] - '0') << 6) | (p[2] - '0'), row = ((p[3] - '0') << 6) | (p[4] - '0'); p += 5;
            if (idx < b->pg.nimages) {
                const struct pg_image *im = &b->pg.images[idx];
                for (int yy = 0; yy < FONT_H; yy++) {
                    int sy = row * FONT_H + yy;
                    if (sy >= im->h) break;
                    const uint32_t *src = im->px + (size_t)sy * (size_t)im->w;
                    for (int xx = 0; xx < im->w; xx++) gfx_put_pixel(px + xx, y + yy, src[xx]);
                }
                px += im->w;
            }
            continue;
        }
        if (c == PGM_INPUT) {
            int idx = ((p[1] - '0') << 6) | (p[2] - '0'); p += 3;
            int wpx = PG_FIELD_COLS * FONT_W;
            int foc = focused && b->focus_input == idx;
            gfx_fill_rect(px, y - 1, wpx, FONT_H + 2, dark ? gfx_mix(b->pg.bg, 0xFFFFFF, 14) : 0xFFFFFF);
            gfx_draw_rect(px, y - 1, wpx, FONT_H + 2, foc ? t->accent : (dark ? 0x6A6F76 : 0x8A8F96));
            if (foc) gfx_draw_rect(px + 1, y, wpx - 2, FONT_H, t->accent);
            const struct pg_input *in = &b->pg.inputs[idx];
            char shown[100]; int len = (int)strlen(in->value); if (len > 98) len = 98;
            if (in->password) { for (int i = 0; i < len; i++) shown[i] = '*'; shown[len] = 0; }
            else memcpy(shown, in->value, (size_t)len + 1);
            const char *s = shown; int nch = utf8_len(s);
            while (nch > PG_FIELD_COLS - 2) { utf8_next(&s); nch--; }
            int ex = gfx_draw_text(px + 4, y, s, fg0, 1);
            if (foc && blink_phase == 0) gfx_fill_rect(ex, y, FONT_W, FONT_H, t->accent);
            add_hit(b, px, y, wpx, FONT_H, 1, idx);
            px += wpx; continue;
        }
        if (c == PGM_BUTTON) {
            int idx = ((p[1] - '0') << 6) | (p[2] - '0'); p += 3;
            const char *lab = b->pg.inputs[idx].value;
            int wpx = (utf8_len(lab) + 4) * FONT_W;
            gfx_fill_rect(px, y - 1, wpx, FONT_H + 2, t->accent);
            gfx_draw_text(px + 2 * FONT_W, y, lab, t->on_accent, 1);
            add_hit(b, px, y, wpx, FONT_H, 2, idx);
            px += wpx; continue;
        }
        if (c < 0x20) { p++; continue; }
        const char *q = p;
        uint32_t cp = utf8_next(&q);
        gfx_draw_glyph(px, y, cp, col, 1);
        if (bold) gfx_draw_glyph(px + 1, y, cp, col, 1);          /* «жирный» — двойной удар со сдвигом на пиксель */
        px += FONT_W; p = q;
    }
    if (link >= 0 && px > link_x0) { gfx_fill_rect(link_x0, y + FONT_H - 2, px - link_x0, 1, col); add_hit(b, link_x0, y, px - link_x0, FONT_H, 0, link); }
}

static void draw_browser_content(struct window *w, int focused) {
    const struct theme *t = T();
    struct browser *b = w->br;
    int x0 = w->x + 1, ty = w->y + TITLE_H;
    int cy = ty + TOOL_H;                          /* верх области страницы */
    int cw = w->w - 2 - SB_W;
    /* панель инструментов */
    gfx_fill_rect(x0, ty, w->w - 2, TOOL_H, t->body);
    const char *lab[3] = { "<", ">", "R" };
    for (int i = 0; i < 3; i++) {
        int bx = x0 + 6 + i * 28;
        int en = (i == 0) ? b->hist_pos > 0 : (i == 1) ? b->hist_pos + 1 < b->hist_n : 1;
        gfx_fill_rect(bx, ty + 4, 24, 22, gfx_mix(t->body, 0xFFFFFF, en ? 22 : 8));
        gfx_draw_text(bx + 8, ty + 6, lab[i], en ? t->term_fg : gfx_mix(t->body, 0xFFFFFF, 35), 1);
    }
    int ax = x0 + 6 + 3 * 28 + 4, aw = w->w - 2 - (ax - x0) - 8;
    gfx_fill_rect(ax, ty + 4, aw, 22, gfx_mix(t->term_bg, 0xFFFFFF, 10));
    gfx_draw_rect(ax, ty + 4, aw, 22, (b->addr_focus && focused) ? t->accent : gfx_mix(t->body, 0xFFFFFF, 40));
    {
        const char *txt = b->addr_focus ? b->addr : b->cur;
        int maxch = aw / FONT_W - 2;
        const char *s = txt; int nch = utf8_len(s);
        if (b->addr_focus) { while (nch > maxch - 1) { utf8_next(&s); nch--; } }
        else { /* начало адреса, лишнее обрезаем */ }
        char tmp[200]; size_t o = 0; int cnt = 0;
        while (*s && cnt < maxch && o + 5 < sizeof tmp) { const char *q = s; utf8_next(&q); for (; s < q; s++) tmp[o++] = *s; cnt++; }
        tmp[o] = 0;
        int ex = gfx_draw_text(ax + 6, ty + 7, tmp[0] || b->addr_focus ? tmp : "введи адрес или слова для поиска", tmp[0] ? t->term_fg : gfx_mix(t->body, 0xFFFFFF, 50), 1);
        if (b->addr_focus && focused && blink_phase == 0) gfx_fill_rect(ex, ty + 7, FONT_W, FONT_H, t->accent);
    }
    /* страница */
    uint32_t page_bg = b->pg.bg ? b->pg.bg : 0xFFFFFF;
    gfx_fill_rect(x0, cy, w->w - 2, BR_ROWS * FONT_H + 1, page_bg);
    b->nhits = 0;
    int visible = BR_ROWS;
    for (int r = 0; r < visible; r++) {
        int li = b->scroll + r;
        if (li >= b->pg.nlines) break;
        draw_page_line(b, x0 + PAD, cy + r * FONT_H, b->pg.lines[li], focused);
    }
    if (b->pg.nlines > visible) {
        int track_h = visible * FONT_H;
        int thumb_h = visible * track_h / b->pg.nlines;
        if (thumb_h < 14) thumb_h = 14;
        int max_scroll = b->pg.nlines - visible;
        int thumb_y = cy + (track_h - thumb_h) * b->scroll / max_scroll;
        int bar_x = x0 + cw + 2;
        gfx_fill_rect(bar_x, cy, SB_W - 2, track_h, gfx_mix(page_bg, 0x808080, 40));
        gfx_fill_rect(bar_x, thumb_y, SB_W - 2, thumb_h, focused ? t->accent : t->title_off);
    }
    /* строка состояния: адрес ссылки под мышью или итог загрузки */
    int sy = cy + BR_ROWS * FONT_H + 1;
    gfx_fill_rect(x0, sy, w->w - 2, STAT_H, t->body);
    const char *st = b->status;
    for (int i = 0; i < b->nhits; i++) {
        struct hit *h = &b->hits[i];
        if (h->kind == 0 && in_rect(mx, my, h->x, h->y, h->w, h->h)) { st = b->pg.links[h->idx]; break; }
    }
    char sbuf[140]; size_t o = 0; int cnt = 0, maxc = (w->w - 16) / FONT_W;
    while (*st && cnt < maxc && o + 5 < sizeof sbuf) { const char *q = st; utf8_next(&q); for (; st < q; st++) sbuf[o++] = *st; cnt++; }
    sbuf[o] = 0;
    gfx_draw_text(x0 + 6, sy + 1, sbuf, t->accent, 1);
}

static void draw_calc_content(struct window *w, int focused) {
    const struct theme *t = T();
    struct calc_state *s = w->calc;
    int y1 = w->y + TITLE_H;
    gfx_fill_rect(w->x + 1, y1, w->w - 2, w->h - TITLE_H - 1, t->body);

    gfx_fill_rect(w->x + CALC_GAP, y1 + CALC_GAP, CALC_W - 2 * CALC_GAP, CALC_DISP_H - CALC_GAP, t->term_bg);
    uint32_t dcolor = s->error ? 0xFF6B6B : t->term_fg;
    int tw = gfx_text_width(s->display, 2);
    int tx = w->x + CALC_W - CALC_GAP - 10 - tw; if (tx < w->x + CALC_GAP + 6) tx = w->x + CALC_GAP + 6;
    gfx_draw_text(tx, y1 + CALC_GAP + (CALC_DISP_H - CALC_GAP - FONT_H * 2) / 2, s->display, dcolor, 2);

    for (int r = 0; r < CALC_ROWS; r++) {
        for (int c = 0; c < CALC_COLS; c++) {
            int bx, by, bw, bh; calc_btn_rect(w, r, c, &bx, &by, &bw, &bh);
            char cmd = calc_layout[r][c].cmd;
            uint32_t base;
            if (cmd == '=') base = t->accent;
            else if (cmd == 'C' || cmd == 'B') base = gfx_mix(t->title_off, 0xFF6B6B, 30);
            else if (cmd == '+' || cmd == '-' || cmd == '*' || cmd == '/') base = gfx_mix(t->title_off, t->accent, 40);
            else base = t->title_off;
            int hover = focused && in_rect(mx, my, bx, by, bw, bh);
            gfx_fill_rect(bx, by, bw, bh, hover ? gfx_mix(base, 0xFFFFFF, 25) : base);
            const char *lab = calc_layout[r][c].label;
            int lw = gfx_text_width(lab, 1);
            uint32_t tc = (cmd == '=') ? t->on_accent : 0xE6EAF0;
            gfx_draw_text(bx + (bw - lw) / 2, by + (bh - FONT_H) / 2, lab, tc, 1);
        }
    }
}

static void about_line(int x, int *y, uint32_t color, const char *fmt, ...) {
    char buf[96];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    gfx_draw_text(x, *y, buf, color, 1);
    *y += 18;
}

static void draw_about_content(struct window *w) {
    const struct theme *t = T();
    int x0 = w->x + 1, y0 = w->y + TITLE_H;
    gfx_fill_rect(x0, y0, w->w - 2, w->h - TITLE_H - 1, t->body);
    draw_lemon(x0 + 70, y0 + 70, 38, 255);
    int tx = x0 + 150, y = y0 + 22;
    gfx_draw_text(tx, y, "LimonOS " LIMON_VERSION, t->accent, 2);
    y += 40;
    about_line(tx, &y, t->term_fg, "Собственная операционная");
    about_line(tx, &y, t->term_fg, "система, написанная с нуля.");
    y = y0 + 150;
    x0 += 20;
    char up[16];
    uint64_t sec = timer_ticks / TIMER_HZ;
    ksnprintf(up, sizeof up, "%02d:%02d:%02d", (int)(sec / 3600), (int)(sec / 60 % 60), (int)(sec % 60));
    about_line(x0, &y, t->term_fg, "Экран:     %ux%u", g_sys.fb_w, g_sys.fb_h);
    about_line(x0, &y, t->term_fg, "Процессор: %s", g_sys.cpu.brand[0] ? g_sys.cpu.brand : g_sys.cpu.vendor);
    if (g_sys.mem_valid) about_line(x0, &y, t->term_fg, "Память:    %llu МиБ свободно", (unsigned long long)(g_sys.mem_usable >> 20));
    about_line(x0, &y, t->term_fg, "Работаю:   %s", up);
    {
        const struct netinfo *ni = net_info();
        char ipb[16];
        net_ip_str(ni->ip, ipb);
        about_line(x0, &y, t->term_fg, "Сеть:      %s", ni->configured ? ipb : "нет адреса");
    }
    y += 8;
    about_line(x0, &y, t->accent, "F2 язык   F3 терминал   F4 закрыть окно");
    about_line(x0, &y, t->accent, "F5 тема   Alt+Tab переключить окно");
}

static void draw_window(int idx, int focused) {
    const struct theme *t = T();
    struct window *w = &wins[idx];
    uint32_t bar = focused ? t->accent : t->title_off;
    uint32_t bar_text = focused ? t->on_accent : 0xC8CED8;
    gfx_blend_rect(w->x + 5, w->y + 5, w->w, w->h, 0x000000, 90);
    gfx_fill_rect(w->x, w->y, w->w, w->h, bar);
    gfx_fill_rect(w->x + 1, w->y + TITLE_H, w->w - 2, w->h - TITLE_H - 1, t->body);
    gfx_draw_text(w->x + 8, w->y + 4, w->title, bar_text, 1);
    uint32_t btn = focused ? gfx_mix(t->accent, 0x000000, 45) : gfx_mix(t->title_off, 0x000000, 35);
    int closing = close_hit(w, mx, my), mining = min_hit(w, mx, my);
    gfx_fill_rect(w->x + w->w - 22, w->y + 4, 18, 16, closing ? 0xE5484D : btn);
    gfx_fill_rect(w->x + w->w - 44, w->y + 4, 18, 16, mining ? gfx_mix(btn, 0xFFFFFF, 60) : btn);
    gfx_draw_text(w->x + w->w - 21, w->y + 4, "×", 0xFFFFFF, 1);
    gfx_draw_text(w->x + w->w - 43, w->y + 2, "_", 0xFFFFFF, 1);
    if (w->type == WIN_TERM) draw_term_content(w, focused);
    else if (w->type == WIN_BROWSER) draw_browser_content(w, focused);
    else if (w->type == WIN_CALC) draw_calc_content(w, focused);
    else draw_about_content(w);
}

static void draw_taskbar(int focus) {
    const struct theme *t = T();
    int y = dh - TASKBAR_H;
    gfx_fill_rect(0, y, dw, TASKBAR_H, t->taskbar);
    gfx_fill_rect(0, y, dw, 1, gfx_mix(t->taskbar, t->accent, 90));
    gfx_fill_rect(4, y + 4, START_W - 8, TASKBAR_H - 8, start_open ? gfx_mix(t->accent, 0xFFFFFF, 60) : t->accent);
    gfx_draw_text(4 + (START_W - 8 - gfx_text_width("Лимон", 1)) / 2, y + 8, "Лимон", t->on_accent, 1);

    int n = 0;
    for (int i = 0; i < MAX_WIN; i++) {
        if (!wins[i].used) continue;
        int bx = START_W + 4 + n * (TASKBTN_W + 4);
        uint32_t col = (i == focus) ? gfx_mix(t->taskbar, t->accent, 110) : wins[i].minimized ? t->taskbar : t->title_off;
        gfx_fill_rect(bx, y + 4, TASKBTN_W, TASKBAR_H - 8, col);
        if (i == focus) gfx_fill_rect(bx, y + TASKBAR_H - 6, TASKBTN_W, 2, t->accent);
        char label[24];
        int len = 0;
        const char *p = wins[i].title;
        while (*p && len < 17) { uint32_t cp = utf8_next(&p); len += utf8_encode(cp, label + len); }
        label[len] = 0;
        gfx_draw_text(bx + 8, y + 8, label, wins[i].minimized ? 0x8A94A6 : 0xE6EAF0, 1);
        n++;
    }

    char clock[8];
    ksnprintf(clock, sizeof clock, "%02d:%02d", now.hour, now.min);
    int cw = gfx_text_width(clock, 1);
    gfx_draw_text(dw - cw - 10, y + 8, clock, 0xE6EAF0, 1);
    const char *lang = kbd_layout() == LAYOUT_RU ? "RU" : "EN";
    int lx = dw - cw - 10 - 44;
    {
        const struct netinfo *ni = net_info();
        gfx_draw_text(lx - 36, y + 8, "NET", ni->configured ? 0x58D68D : 0x6B7685, 1);
    }
    gfx_fill_rect(lx, y + 5, 34, TASKBAR_H - 10, t->title_off);
    gfx_draw_text(lx + 9, y + 8, lang, t->accent, 1);
}

static void draw_menu(void) {
    const struct theme *t = T();
    int x, y, w, h;
    menu_rect(&x, &y, &w, &h);
    gfx_blend_rect(x + 4, y + 4, w, h, 0x000000, 90);
    gfx_fill_rect(x, y, w, h, t->taskbar);
    gfx_draw_rect(x, y, w, h, t->accent);
    for (int i = 0; i < MENU_N; i++) {
        int iy = y + 4 + i * MENU_ITEM_H;
        int hover = in_rect(mx, my, x + 2, iy, w - 4, MENU_ITEM_H);
        if (hover) gfx_fill_rect(x + 2, iy, w - 4, MENU_ITEM_H, t->accent);
        gfx_draw_text(x + 14, iy + 6, menu_items[i], hover ? t->on_accent : 0xE6EAF0, 1);
    }
}

static const char *const cursor_art[] = {
    "X          ", "XX         ", "X.X        ", "X..X       ", "X...X      ", "X....X     ",
    "X.....X    ", "X......X   ", "X.......X  ", "X........X ", "X.....XXXXX", "X..X..X    ",
    "X.X X..X   ", "XX  X..X   ", "X    X..X  ", "     XXX   ",
};

static void draw_cursor(void) {
    for (int j = 0; j < 16; j++)
        for (int i = 0; cursor_art[j][i]; i++) {
            char c = cursor_art[j][i];
            if (c == 'X') gfx_put_pixel(mx + i, my + j, 0x000000);
            else if (c == '.') gfx_put_pixel(mx + i, my + j, 0xFFFFFF);
        }
}

static void render(void) {
    draw_wallpaper();
    draw_icons();
    int focus = top_window();
    for (int i = 0; i < zcount; i++) {
        int idx = zorder[i];
        if (!wins[idx].minimized) draw_window(idx, idx == focus);
    }
    draw_taskbar(focus);
    if (start_open) draw_menu();
    draw_cursor();
}

void desktop_refresh(void) { redraw = 1; desktop_frame(); }

void desktop_frame(void) {
    if (!redraw) return;
    render();
    gfx_present();
    redraw = 0;
}

/* ---------- события ---------- */

static void menu_action(int item) {
    switch (item) {
    case 0: desktop_open_terminal(); break;
    case 1: desktop_open_about(); break;
    case 2: desktop_open_calculator(); break;
    case 3: desktop_browse(NULL); break;
    case 4: desktop_set_theme((cur_theme + 1) % NTHEMES); break;
    case 5: desktop_power(1); break;
    case 6: desktop_power(0); break;
    default: break;
    }
}

static void open_icon(int i) {
    if (i == 0) desktop_open_terminal();
    else if (i == 1) desktop_open_about();
    else if (i == 2) desktop_open_calculator();
    else desktop_browse(NULL);
}

/* ---------- управление браузером ---------- */

static void str_append_cp(char *s, size_t max, uint32_t cp) {
    size_t l = strlen(s);
    if (l + 5 >= max) return;
    int n = utf8_encode(cp, s + l);
    s[l + (size_t)n] = 0;
}
static void str_backspace(char *s) {
    size_t l = strlen(s);
    while (l > 0) { l--; if (((unsigned char)s[l] & 0xC0) != 0x80) break; }
    s[l] = 0;
}

static void browser_submit_form(struct window *w, struct browser *b, int form, int clicked) {
    char url[700];
    if (page_form_url(&b->pg, form, clicked, url, sizeof url) == 0) browser_load(w, b, url, 1);
}

static void browser_back_fwd(struct window *w, struct browser *b, int dir) {
    int np = b->hist_pos + dir;
    if (np < 0 || np >= b->hist_n) return;
    char url[400]; memcpy(url, b->hist[np], sizeof url);
    if (browser_load(w, b, url, 0) == 0) b->hist_pos = np;
}

static void browser_key(struct window *w, const struct key_event *ev) {
    struct browser *b = w->br;
    uint32_t cp = ev->cp;
    int printable = cp >= 32 && cp < 0x110000 && !(ev->mods & (MOD_CTRL | MOD_ALT));
    if (b->addr_focus) {
        if (cp == '\n') { b->addr_focus = 0; char t[640]; ksnprintf(t, sizeof t, "%s", b->addr); browser_go_typed(w, b, t); }
        else if (cp == 27) b->addr_focus = 0;
        else if (cp == '\b') str_backspace(b->addr);
        else if ((ev->mods & MOD_CTRL) && (cp == 'u' || cp == 'U')) b->addr[0] = 0;
        else if (printable) str_append_cp(b->addr, sizeof b->addr, cp);
        return;
    }
    if (b->focus_input >= 0 && b->focus_input < b->pg.ninputs) {
        struct pg_input *in = &b->pg.inputs[b->focus_input];
        if (cp == '\n') { int f = in->form; b->focus_input = -1; browser_submit_form(w, b, f, -1); }
        else if (cp == 27) b->focus_input = -1;
        else if (cp == '\b') str_backspace(in->value);
        else if (cp == '\t') {                                   /* следующее поле */
            for (int k = 1; k <= b->pg.ninputs; k++) {
                int j = (b->focus_input + k) % b->pg.ninputs;
                if (b->pg.inputs[j].kind == IN_TEXT) { b->focus_input = j; break; }
            }
        }
        else if (printable) str_append_cp(in->value, sizeof in->value, cp);
        return;
    }
    int visible = BR_ROWS, maxs = b->pg.nlines - visible > 0 ? b->pg.nlines - visible : 0;
    if ((ev->mods & MOD_CTRL) && (cp == 'l' || cp == 'L' || cp == 0x434 /* д */)) { b->addr_focus = 1; ksnprintf(b->addr, sizeof b->addr, "%s", b->cur); return; }
    if (cp == KEY_F(6)) { b->addr_focus = 1; ksnprintf(b->addr, sizeof b->addr, "%s", b->cur); return; }
    if ((ev->mods & MOD_CTRL) && (cp == 'r' || cp == 'R')) { if (b->cur[0]) { char u[640]; ksnprintf(u, sizeof u, "%s", b->cur); browser_load(w, b, u, 0); } return; }
    if ((ev->mods & MOD_ALT) && cp == KEY_LEFT) { browser_back_fwd(w, b, -1); return; }
    if ((ev->mods & MOD_ALT) && cp == KEY_RIGHT) { browser_back_fwd(w, b, +1); return; }
    if (cp == '\b') { browser_back_fwd(w, b, -1); return; }
    if (cp == KEY_UP) b->scroll -= 3;
    else if (cp == KEY_DOWN) b->scroll += 3;
    else if (cp == KEY_PGUP) b->scroll -= visible - 1;
    else if (cp == KEY_PGDN || cp == ' ') b->scroll += visible - 1;
    else if (cp == KEY_HOME) b->scroll = 0;
    else if (cp == KEY_END) b->scroll = maxs;
    if (b->scroll < 0) b->scroll = 0;
    if (b->scroll > maxs) b->scroll = maxs;
}

static void browser_click(struct window *w, int px, int py) {
    struct browser *b = w->br;
    int x0 = w->x + 1, ty = w->y + TITLE_H, cy = ty + TOOL_H;
    int ax = x0 + 6 + 3 * 28 + 4, aw = w->w - 2 - (ax - x0) - 8;
    if (py < cy) {                                             /* панель инструментов */
        for (int i = 0; i < 3; i++)
            if (in_rect(px, py, x0 + 6 + i * 28, ty + 4, 24, 22)) {
                if (i == 0) browser_back_fwd(w, b, -1);
                else if (i == 1) browser_back_fwd(w, b, +1);
                else if (b->cur[0]) { char u[640]; ksnprintf(u, sizeof u, "%s", b->cur); browser_load(w, b, u, 0); }
                return;
            }
        if (in_rect(px, py, ax, ty + 4, aw, 22)) { b->addr_focus = 1; b->focus_input = -1; ksnprintf(b->addr, sizeof b->addr, "%s", b->cur); }
        return;
    }
    if (py >= cy + BR_ROWS * FONT_H + 1) return;               /* строка состояния */
    int visible = BR_ROWS, maxs = b->pg.nlines - visible > 0 ? b->pg.nlines - visible : 0;
    if (px >= x0 + w->w - 2 - SB_W) {                          /* полоса прокрутки */
        b->scroll += (py < cy + BR_ROWS * FONT_H / 2) ? -(visible - 1) : (visible - 1);
        if (b->scroll < 0) b->scroll = 0;
        if (b->scroll > maxs) b->scroll = maxs;
        return;
    }
    b->addr_focus = 0;
    for (int i = 0; i < b->nhits; i++) {
        struct hit *h = &b->hits[i];
        if (!in_rect(px, py, h->x, h->y, h->w, h->h)) continue;
        if (h->kind == 0) { char u[640]; ksnprintf(u, sizeof u, "%s", b->pg.links[h->idx]); b->focus_input = -1; browser_load(w, b, u, 1); }
        else if (h->kind == 1) b->focus_input = h->idx;
        else { b->focus_input = -1; browser_submit_form(w, b, b->pg.inputs[h->idx].form, h->idx); }
        return;
    }
    b->focus_input = -1;
}

static void handle_click(int px, int py) {
    int was_open = start_open;
    start_open = 0;

    if (was_open) {
        int x, y, w, h;
        menu_rect(&x, &y, &w, &h);
        if (in_rect(px, py, x, y, w, h)) {
            int item = (py - y - 4) / MENU_ITEM_H;
            if (item >= 0 && item < MENU_N) menu_action(item);
            return;
        }
    }

    if (py >= dh - TASKBAR_H) {
        if (px < START_W) { start_open = !was_open; return; }
        int n = 0, focus = top_window();
        for (int i = 0; i < MAX_WIN; i++) {
            if (!wins[i].used) continue;
            int bx = START_W + 4 + n * (TASKBTN_W + 4);
            if (in_rect(px, py, bx, dh - TASKBAR_H + 4, TASKBTN_W, TASKBAR_H - 8)) {
                if (wins[i].minimized || i != focus) focus_window(i);
                else wins[i].minimized = 1;
                return;
            }
            n++;
        }
        return;
    }

    int wi = win_at(px, py);
    if (wi >= 0) {
        struct window *w = &wins[wi];
        focus_window(wi);
        if (close_hit(w, px, py)) close_window(wi);
        else if (min_hit(w, px, py)) w->minimized = 1;
        else if (py < w->y + TITLE_H) { drag_win = wi; drag_dx = px - w->x; drag_dy = py - w->y; }
        else if (w->type == WIN_BROWSER) browser_click(w, px, py);
        else if (w->type == WIN_CALC) {
            for (int r = 0; r < CALC_ROWS; r++)
                for (int c = 0; c < CALC_COLS; c++) {
                    int bx, by, bw, bh; calc_btn_rect(w, r, c, &bx, &by, &bw, &bh);
                    if (in_rect(px, py, bx, by, bw, bh)) { calc_press(w->calc, calc_layout[r][c].cmd); redraw = 1; }
                }
        }
        return;
    }

    for (int i = 0; i < ICON_COUNT; i++) {
        int x, y;
        icon_rect(i, &x, &y);
        if (in_rect(px, py, x, y, 88, 90)) {
            if (last_click_icon == i && timer_ticks - last_click_tick < TIMER_HZ * 6 / 10) {
                open_icon(i);
                last_click_icon = -1;
            } else {
                last_click_icon = i;
                last_click_tick = timer_ticks;
            }
            return;
        }
    }
    last_click_icon = -1;
}

void desktop_mouse(const struct mouse_event *e) {
    mx = e->x; my = e->y;
    int left = e->buttons & 1;
    if (drag_win >= 0) {
        if (left) {
            struct window *w = &wins[drag_win];
            w->x = mx - drag_dx;
            w->y = my - drag_dy;
            if (w->y < 0) w->y = 0;
            if (w->y > dh - TASKBAR_H - TITLE_H) w->y = dh - TASKBAR_H - TITLE_H;
            if (w->x < 60 - w->w) w->x = 60 - w->w;
            if (w->x > dw - 60) w->x = dw - 60;
        } else drag_win = -1;
    } else if (left && !prev_left) {
        handle_click(mx, my);
    }
    prev_left = left;
    redraw = 1;
}

void desktop_key(const struct key_event *ev) {
    redraw = 1;
    uint32_t cp = ev->cp;
    if (cp == KEY_F(2)) { kbd_set_layout(kbd_layout() == LAYOUT_RU ? LAYOUT_EN : LAYOUT_RU); return; }
    if (cp == KEY_F(3)) { desktop_open_terminal(); return; }
    if (cp == KEY_F(4)) { int f = top_window(); if (f >= 0) close_window(f); return; }
    if (cp == KEY_F(5)) { desktop_set_theme((cur_theme + 1) % NTHEMES); return; }
    if (cp == 27 && start_open) { start_open = 0; return; }
    if ((ev->mods & MOD_ALT) && cp == '\t') {
        for (int i = 0; i < zcount; i++)         /* самое нижнее видимое окно — наверх */
            if (!wins[zorder[i]].minimized) { z_to_top(zorder[i]); break; }
        return;
    }
    int f = top_window();
    if (f < 0) return;
    if (wins[f].type == WIN_TERM) { shell_key(wins[f].sh, ev); return; }
    if (wins[f].type == WIN_BROWSER) { browser_key(&wins[f], ev); return; }
    if (wins[f].type == WIN_CALC) {
        struct calc_state *s = wins[f].calc;
        if (cp >= '0' && cp <= '9') calc_press(s, (char)cp);
        else if (cp == '.' || cp == ',') calc_press(s, '.');
        else if (cp == '+' || cp == '-' || cp == '*' || cp == '/') calc_press(s, (char)cp);
        else if (cp == '\n' || cp == '=') calc_press(s, '=');
        else if (cp == '\b' || cp == KEY_DELETE) calc_press(s, 'B');
        else if (cp == 27) calc_press(s, 'C');        /* Escape */
        else if (cp == '%') calc_press(s, '%');
    }
}

void desktop_tick(void) {
    uint64_t sec = timer_ticks / TIMER_HZ;
    if (sec != last_sec) {
        last_sec = sec;
        int old_min = now.min;
        rtc_read(&now);
        if (now.min != old_min) redraw = 1;
    }
    int phase = (int)((timer_ticks / (TIMER_HZ / 2)) & 1);
    if (phase != blink_phase) { blink_phase = phase; redraw = 1; }
}

void desktop_power(int reboot) {
    gfx_clear(0x000000);
    const char *msg = reboot ? "LimonOS: перезагрузка..." : "LimonOS: выключение...";
    gfx_draw_text((int)gfx_width() / 2 - gfx_text_width(msg, 2) / 2, (int)gfx_height() / 2 - 16, msg, 0xF4D91A, 2);
    gfx_present();
    if (reboot) power_reboot();
    power_shutdown();
    gfx_clear(0x000000);
    msg = "Теперь можно выключить питание компьютера.";
    gfx_draw_text((int)gfx_width() / 2 - gfx_text_width(msg, 1) / 2, (int)gfx_height() / 2 - 8, msg, 0xF4D91A, 1);
    gfx_present();
    cpu_cli();
    for (;;) cpu_halt();
}

void desktop_init(void) {
    gfx_use_backbuffer();
    dw = (int)gfx_width();
    dh = (int)gfx_height();
    mouse_set_bounds(dw, dh);
    mx = dw / 2; my = dh / 2;
    rtc_read(&now);
    desktop_open_about();
    desktop_open_terminal();
    redraw = 1;
}

void desktop_run(void) {
    for (;;) {
        struct key_event k;
        struct mouse_event m;
        while (kbd_poll(&k)) desktop_key(&k);
        while (mouse_poll(&m)) desktop_mouse(&m);
        desktop_tick();
        desktop_frame();
        cpu_halt();
    }
}
