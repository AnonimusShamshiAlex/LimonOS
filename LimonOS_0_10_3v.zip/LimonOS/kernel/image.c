#include "image.h"
#include "mem.h"
#include "kstring.h"

#define MAX_PIXELS (6u * 1000 * 1000)

/* ================= deflate (по алгоритму puff Марка Адлера) ================= */

struct inf { const uint8_t *in; size_t inlen, incnt; int bitbuf, bitcnt; uint8_t *out; size_t outlen, outcnt; int err; };
struct huff { short count[16]; short symbol[288]; };

static int inf_bits(struct inf *s, int need) {
    long val = s->bitbuf;
    while (s->bitcnt < need) {
        if (s->incnt >= s->inlen) { s->err = 1; return 0; }
        val |= (long)s->in[s->incnt++] << s->bitcnt;
        s->bitcnt += 8;
    }
    s->bitbuf = (int)(val >> need);
    s->bitcnt -= need;
    return (int)(val & ((1L << need) - 1));
}

static int inf_decode(struct inf *s, const struct huff *h) {
    int code = 0, first = 0, index = 0;
    for (int len = 1; len <= 15; len++) {
        code |= inf_bits(s, 1);
        if (s->err) return -1;
        int count = h->count[len];
        if (code - count < first) return h->symbol[index + (code - first)];
        index += count; first += count; first <<= 1; code <<= 1;
    }
    return -1;
}

static int inf_construct(struct huff *h, const short *length, int n) {
    short offs[16];
    for (int len = 0; len <= 15; len++) h->count[len] = 0;
    for (int sym = 0; sym < n; sym++) h->count[length[sym]]++;
    if (h->count[0] == n) return 0;
    int left = 1;
    for (int len = 1; len <= 15; len++) { left <<= 1; left -= h->count[len]; if (left < 0) return left; }
    offs[1] = 0;
    for (int len = 1; len < 15; len++) offs[len + 1] = (short)(offs[len] + h->count[len]);
    for (int sym = 0; sym < n; sym++) if (length[sym] != 0) h->symbol[offs[length[sym]]++] = (short)sym;
    return left;
}

static int inf_codes(struct inf *s, const struct huff *lc, const struct huff *dc) {
    static const short lens[29] = { 3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258 };
    static const short lext[29] = { 0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0 };
    static const short dists[30] = { 1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577 };
    static const short dext[30] = { 0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13 };
    for (;;) {
        int sym = inf_decode(s, lc);
        if (sym < 0) return -1;
        if (sym < 256) {
            if (s->outcnt >= s->outlen) return -2;
            s->out[s->outcnt++] = (uint8_t)sym;
        } else if (sym == 256) return 0;
        else {
            sym -= 257;
            if (sym >= 29) return -1;
            int len = lens[sym] + inf_bits(s, lext[sym]);
            int ds = inf_decode(s, dc);
            if (ds < 0 || ds >= 30) return -1;
            size_t dist = (size_t)dists[ds] + (size_t)inf_bits(s, dext[ds]);
            if (s->err || dist > s->outcnt) return -1;
            if (s->outcnt + (size_t)len > s->outlen) return -2;
            while (len--) { s->out[s->outcnt] = s->out[s->outcnt - dist]; s->outcnt++; }
        }
    }
}

static int inf_dynamic(struct inf *s) {
    static const short order[19] = { 16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15 };
    short lengths[320];
    struct huff lc, dc;
    int nlen = inf_bits(s, 5) + 257, ndist = inf_bits(s, 5) + 1, ncode = inf_bits(s, 4) + 4;
    if (nlen > 286 || ndist > 30) return -1;
    int idx;
    for (idx = 0; idx < ncode; idx++) lengths[order[idx]] = (short)inf_bits(s, 3);
    for (; idx < 19; idx++) lengths[order[idx]] = 0;
    if (inf_construct(&lc, lengths, 19) != 0) return -1;
    idx = 0;
    while (idx < nlen + ndist) {
        int sym = inf_decode(s, &lc);
        if (sym < 0) return -1;
        if (sym < 16) lengths[idx++] = (short)sym;
        else {
            int len = 0, rep;
            if (sym == 16) { if (idx == 0) return -1; len = lengths[idx - 1]; rep = 3 + inf_bits(s, 2); }
            else if (sym == 17) rep = 3 + inf_bits(s, 3);
            else rep = 11 + inf_bits(s, 7);
            if (idx + rep > nlen + ndist) return -1;
            while (rep--) lengths[idx++] = (short)len;
        }
    }
    if (lengths[256] == 0) return -1;
    int err = inf_construct(&lc, lengths, nlen);
    if (err && (err < 0 || nlen != lc.count[0] + lc.count[1])) return -1;
    err = inf_construct(&dc, lengths + nlen, ndist);
    if (err && (err < 0 || ndist != dc.count[0] + dc.count[1])) return -1;
    return inf_codes(s, &lc, &dc);
}

/* zlib-поток -> out (размер известен заранее). Возвращает число байт или -1. */
static long inflate_zlib(const uint8_t *in, size_t inlen, uint8_t *out, size_t outlen) {
    if (inlen < 6 || (in[0] & 15) != 8) return -1;
    struct inf s = { in + 2, inlen - 2, 0, 0, 0, out, outlen, 0, 0 };
    int last;
    do {
        last = inf_bits(&s, 1);
        int type = inf_bits(&s, 2);
        int r;
        if (s.err) return -1;
        if (type == 0) {
            s.bitbuf = 0; s.bitcnt = 0;
            if (s.incnt + 4 > s.inlen) return -1;
            unsigned len = s.in[s.incnt] | (s.in[s.incnt + 1] << 8);
            s.incnt += 4;
            if (s.incnt + len > s.inlen || s.outcnt + len > s.outlen) return -1;
            memcpy(s.out + s.outcnt, s.in + s.incnt, len);
            s.incnt += len; s.outcnt += len;
            r = 0;
        } else if (type == 1) {
            struct huff lc, dc; short lengths[288];
            int sym;
            for (sym = 0; sym < 144; sym++) lengths[sym] = 8;
            for (; sym < 256; sym++) lengths[sym] = 9;
            for (; sym < 280; sym++) lengths[sym] = 7;
            for (; sym < 288; sym++) lengths[sym] = 8;
            inf_construct(&lc, lengths, 288);
            for (sym = 0; sym < 30; sym++) lengths[sym] = 5;
            inf_construct(&dc, lengths, 30);
            r = inf_codes(&s, &lc, &dc);
        } else if (type == 2) r = inf_dynamic(&s);
        else return -1;
        if (r < 0) return (r == -2 && s.outcnt == s.outlen) ? (long)s.outcnt : -1;
    } while (!last);
    return (long)s.outcnt;
}

/* ================= PNG ================= */

static uint32_t be32(const uint8_t *p) { return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }

static uint32_t over_white(int r, int g, int b, int a) {
    if (a >= 255) return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
    r = (r * a + 255 * (255 - a)) / 255; g = (g * a + 255 * (255 - a)) / 255; b = (b * a + 255 * (255 - a)) / 255;
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

static int png_decode(const uint8_t *d, size_t n, struct img *out) {
    if (n < 33 || memcmp(d, "\x89PNG\r\n\x1a\n", 8) != 0) return IMG_E_FORMAT;
    uint32_t w = 0, h = 0; int depth = 0, ctype = 0, interlace = 0;
    uint8_t pal[256][3]; uint8_t palA[256]; int npal = 0;
    memset(palA, 255, sizeof palA);
    uint8_t *idat = NULL; size_t idat_len = 0, idat_cap = 0;
    size_t p = 8; int got_hdr = 0, rc = 0;
    while (p + 12 <= n) {
        uint32_t len = be32(d + p); const uint8_t *type = d + p + 4; const uint8_t *cd = d + p + 8;
        if (len > n || p + 12 + len > n) break;
        if (memcmp(type, "IHDR", 4) == 0 && len >= 13) {
            w = be32(cd); h = be32(cd + 4); depth = cd[8]; ctype = cd[9]; interlace = cd[12]; got_hdr = 1;
        } else if (memcmp(type, "PLTE", 4) == 0) {
            npal = (int)(len / 3); if (npal > 256) npal = 256;
            for (int i = 0; i < npal; i++) { pal[i][0] = cd[i * 3]; pal[i][1] = cd[i * 3 + 1]; pal[i][2] = cd[i * 3 + 2]; }
        } else if (memcmp(type, "tRNS", 4) == 0 && ctype == 3) {
            for (uint32_t i = 0; i < len && i < 256; i++) palA[i] = cd[i];
        } else if (memcmp(type, "IDAT", 4) == 0) {
            if (idat_len + len > idat_cap) {
                size_t nc = (idat_len + len) * 2 + 1024;
                uint8_t *nb = kmalloc(nc);
                if (!nb) { rc = IMG_E_MEMORY; goto done; }
                if (idat) { memcpy(nb, idat, idat_len); kfree(idat); }
                idat = nb; idat_cap = nc;
            }
            memcpy(idat + idat_len, cd, len); idat_len += len;
        } else if (memcmp(type, "IEND", 4) == 0) break;
        p += 12 + len;
    }
    if (!got_hdr || !w || !h) { rc = IMG_E_CORRUPT; goto done; }
    if (interlace) { rc = IMG_E_FORMAT; goto done; }
    if ((uint64_t)w * h > MAX_PIXELS) { rc = IMG_E_MEMORY; goto done; }
    int chans = ctype == 0 ? 1 : ctype == 2 ? 3 : ctype == 3 ? 1 : ctype == 4 ? 2 : ctype == 6 ? 4 : 0;
    if (!chans || (depth != 1 && depth != 2 && depth != 4 && depth != 8 && depth != 16)) { rc = IMG_E_FORMAT; goto done; }
    size_t bpp_bits = (size_t)chans * (size_t)depth;
    size_t stride = ((size_t)w * bpp_bits + 7) / 8;
    size_t rawlen = (stride + 1) * h;
    uint8_t *raw = kmalloc(rawlen);
    if (!raw) { rc = IMG_E_MEMORY; goto done; }
    if (inflate_zlib(idat, idat_len, raw, rawlen) < (long)rawlen) { kfree(raw); rc = IMG_E_CORRUPT; goto done; }
    size_t bpp = bpp_bits >= 8 ? bpp_bits / 8 : 1;
    /* снятие фильтров построчно, на месте */
    for (uint32_t y = 0; y < h; y++) {
        uint8_t *row = raw + y * (stride + 1) + 1; uint8_t ft = row[-1];
        const uint8_t *prev = y ? raw + (y - 1) * (stride + 1) + 1 : NULL;
        for (size_t i = 0; i < stride; i++) {
            int a = i >= bpp ? row[i - bpp] : 0, b = prev ? prev[i] : 0, c = (prev && i >= bpp) ? prev[i - bpp] : 0, x = row[i];
            switch (ft) {
            case 0: break;
            case 1: x += a; break;
            case 2: x += b; break;
            case 3: x += (a + b) / 2; break;
            case 4: { int pa = b - c, pb = a - c, pc = a + b - 2 * c; if (pa < 0) pa = -pa; if (pb < 0) pb = -pb; if (pc < 0) pc = -pc;
                      x += (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c); break; }
            default: kfree(raw); rc = IMG_E_CORRUPT; goto done;
            }
            row[i] = (uint8_t)x;
        }
    }
    uint32_t *px = kmalloc((size_t)w * h * 4);
    if (!px) { kfree(raw); rc = IMG_E_MEMORY; goto done; }
    for (uint32_t y = 0; y < h; y++) {
        const uint8_t *row = raw + y * (stride + 1) + 1;
        for (uint32_t x = 0; x < w; x++) {
            int r, g, b, a = 255;
            if (ctype == 2 || ctype == 6) {
                if (depth == 8) { const uint8_t *q = row + x * (size_t)chans; r = q[0]; g = q[1]; b = q[2]; if (ctype == 6) a = q[3]; }
                else { const uint8_t *q = row + x * (size_t)chans * 2; r = q[0]; g = q[2]; b = q[4]; if (ctype == 6) a = q[6]; }
            } else if (ctype == 4) {
                if (depth == 8) { const uint8_t *q = row + x * 2; r = g = b = q[0]; a = q[1]; }
                else { const uint8_t *q = row + x * 4; r = g = b = q[0]; a = q[2]; }
            } else {                                              /* 0 серый, 3 палитра */
                int v;
                if (depth == 16) v = row[x * 2];
                else if (depth == 8) v = row[x];
                else { size_t bit = (size_t)x * (size_t)depth; v = (row[bit / 8] >> (8 - depth - (int)(bit % 8))) & ((1 << depth) - 1); }
                if (ctype == 3) { if (v >= npal) v = 0; r = pal[v][0]; g = pal[v][1]; b = pal[v][2]; a = palA[v]; }
                else { if (depth < 8) v = v * 255 / ((1 << depth) - 1); r = g = b = v; }
            }
            px[(size_t)y * w + x] = over_white(r, g, b, a);
        }
    }
    kfree(raw);
    out->w = (int)w; out->h = (int)h; out->px = px;
done:
    if (idat) kfree(idat);
    return rc;
}

/* ================= GIF ================= */

static int gif_decode(const uint8_t *d, size_t n, struct img *out) {
    if (n < 13 || (memcmp(d, "GIF87a", 6) != 0 && memcmp(d, "GIF89a", 6) != 0)) return IMG_E_FORMAT;
    int sw = d[6] | (d[7] << 8), sh = d[8] | (d[9] << 8);
    int flags = d[10]; size_t p = 13;
    uint8_t gpal[256][3]; int gn = 0;
    if (flags & 0x80) { gn = 2 << (flags & 7); if (p + (size_t)gn * 3 > n) return IMG_E_CORRUPT; for (int i = 0; i < gn; i++) { gpal[i][0] = d[p]; gpal[i][1] = d[p + 1]; gpal[i][2] = d[p + 2]; p += 3; } }
    int transp = -1;
    (void)sw; (void)sh;
    while (p < n) {
        uint8_t b = d[p++];
        if (b == 0x21) {
            if (p >= n) return IMG_E_CORRUPT;
            uint8_t lbl = d[p++];
            if (lbl == 0xF9 && p + 5 < n && d[p] >= 4) { if (d[p + 1] & 1) transp = d[p + 4]; }
            while (p < n && d[p]) p += (size_t)d[p] + 1;
            p++;
        } else if (b == 0x2C) {
            if (p + 9 > n) return IMG_E_CORRUPT;
            int w = d[p + 4] | (d[p + 5] << 8), h = d[p + 6] | (d[p + 7] << 8), lf = d[p + 8];
            p += 9;
            uint8_t lpal[256][3]; const uint8_t (*pal)[3] = (const uint8_t (*)[3])gpal; int pn = gn;
            if (lf & 0x80) { pn = 2 << (lf & 7); if (p + (size_t)pn * 3 > n) return IMG_E_CORRUPT; for (int i = 0; i < pn; i++) { lpal[i][0] = d[p]; lpal[i][1] = d[p + 1]; lpal[i][2] = d[p + 2]; p += 3; } pal = (const uint8_t (*)[3])lpal; }
            if (w <= 0 || h <= 0 || (uint64_t)w * h > MAX_PIXELS) return IMG_E_MEMORY;
            if (p >= n) return IMG_E_CORRUPT;
            int mincode = d[p++];
            if (mincode < 2 || mincode > 8) return IMG_E_CORRUPT;
            uint8_t *idx = kmalloc((size_t)w * h);
            if (!idx) return IMG_E_MEMORY;
            memset(idx, 0, (size_t)w * h);
            /* LZW */
            static uint16_t prefix[4096]; static uint8_t suffix[4096], stack[4097];
            int clear = 1 << mincode, eoi = clear + 1, next = clear + 2, size = mincode + 1, prev = -1;
            uint32_t acc = 0; int nb = 0; size_t o = 0, total = (size_t)w * h;
            size_t blk_end = 0; size_t q = p;
            int done = 0;
            while (!done && o < total) {
                while (nb < size) {
                    if (q >= blk_end) { if (q >= n) { done = 1; break; } size_t bl = d[q++]; if (!bl) { done = 1; break; } blk_end = q + bl; if (blk_end > n) blk_end = n; }
                    acc |= (uint32_t)d[q++] << nb; nb += 8;
                }
                if (done) break;
                int code = (int)(acc & ((1u << size) - 1)); acc >>= size; nb -= size;
                if (code == clear) { next = clear + 2; size = mincode + 1; prev = -1; continue; }
                if (code == eoi) break;
                int cur = code, sp = 0;
                if (prev < 0) { if (code >= clear) break; idx[o++] = (uint8_t)code; prev = code; continue; }
                if (code >= next) { if (code > next) break; stack[sp++] = 0; cur = prev; }      /* KwKwK */
                while (cur >= clear) { if (sp >= 4096) break; stack[sp++] = suffix[cur]; cur = prefix[cur]; }
                stack[sp++] = (uint8_t)cur;
                uint8_t first = (uint8_t)cur;
                if (code >= next) stack[0] = first;
                while (sp && o < total) idx[o++] = stack[--sp];
                if (next < 4096) { prefix[next] = (uint16_t)prev; suffix[next] = first; next++; if (next == (1 << size) && size < 12) size++; }
                prev = code;
            }
            uint32_t *px = kmalloc((size_t)w * h * 4);
            if (!px) { kfree(idx); return IMG_E_MEMORY; }
            int inter = (lf & 0x40) != 0;
            for (int y = 0; y < h; y++) {
                int sy = y;
                if (inter) {                                       /* чересстрочная: 4 прохода */
                    int pass1 = (h + 7) / 8, pass2 = (h + 3) / 8, pass3 = (h + 1) / 4;
                    if (y < pass1) sy = y * 8; else if (y < pass1 + pass2) sy = (y - pass1) * 8 + 4;
                    else if (y < pass1 + pass2 + pass3) sy = (y - pass1 - pass2) * 4 + 2; else sy = (y - pass1 - pass2 - pass3) * 2 + 1;
                }
                for (int x = 0; x < w; x++) {
                    int v = idx[(size_t)y * w + x];
                    px[(size_t)sy * w + x] = (v == transp || v >= pn) ? 0xFFFFFF : (((uint32_t)pal[v][0] << 16) | ((uint32_t)pal[v][1] << 8) | pal[v][2]);
                }
            }
            kfree(idx);
            out->w = w; out->h = h; out->px = px;
            return 0;
        } else if (b == 0x3B) break;
        else return IMG_E_CORRUPT;
    }
    return IMG_E_CORRUPT;
}

/* ================= JPEG (baseline) ================= */

struct jhuff { uint8_t bits[17]; uint8_t vals[256]; int mincode[17], maxcode[18], valptr[17]; int ok; };
struct jcomp { int id, h, v, tq, td, ta; int pred; uint8_t *buf; int bw, bh; };
struct jpg {
    const uint8_t *d; size_t n, p;
    uint32_t acc; int nb; int hit_marker;
    struct jhuff dc[4], ac[4];
    uint16_t qt[4][64];
};

static const uint8_t zigzag[64] = {
    0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,
    35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63 };

static void jh_build(struct jhuff *h) {
    int code = 0, k = 0;
    for (int l = 1; l <= 16; l++) {
        h->valptr[l] = k;
        h->mincode[l] = code;
        code += h->bits[l]; k += h->bits[l];
        h->maxcode[l] = h->bits[l] ? code - 1 : -1;
        code <<= 1;
    }
    h->ok = 1;
}

static int jbit(struct jpg *j) {
    if (j->nb == 0) {
        uint8_t b = 0;
        if (!j->hit_marker && j->p < j->n) {
            b = j->d[j->p++];
            if (b == 0xFF) {
                uint8_t b2 = j->p < j->n ? j->d[j->p] : 0;
                if (b2 == 0) j->p++;
                else { j->hit_marker = 1; j->p--; b = 0; }
            }
        }
        j->acc = b; j->nb = 8;
    }
    j->nb--;
    return (int)((j->acc >> j->nb) & 1);
}

static int jdecode(struct jpg *j, const struct jhuff *h) {
    int code = 0;
    for (int l = 1; l <= 16; l++) {
        code = (code << 1) | jbit(j);
        if (h->maxcode[l] >= 0 && code <= h->maxcode[l] && code >= h->mincode[l]) return h->vals[h->valptr[l] + code - h->mincode[l]];
    }
    return -1;
}

static int jreceive(struct jpg *j, int s) { int v = 0; while (s--) v = (v << 1) | jbit(j); return v; }
static int jextend(int v, int s) { return (s && v < (1 << (s - 1))) ? v - (1 << s) + 1 : v; }

#define F2F(x) (x)
static void idct(uint8_t *out, int stride, const int *coef) {
    int tmp[64]; int *v = tmp;
    for (int i = 0; i < 8; i++, v++) {
        const int *d = coef + i;
        if (!d[8] && !d[16] && !d[24] && !d[32] && !d[40] && !d[48] && !d[56]) { int dc = d[0] * 4; for (int k = 0; k < 8; k++) v[k * 8] = dc; continue; }
        int p2 = d[16], p3 = d[48];
        int p1 = (p2 + p3) * 2217;
        int t2 = p1 + p3 * -7567, t3 = p1 + p2 * 3135;
        int t0 = (d[0] + d[32]) * 4096, t1 = (d[0] - d[32]) * 4096;
        int x0 = t0 + t3, x3 = t0 - t3, x1 = t1 + t2, x2 = t1 - t2;
        t0 = d[56]; t1 = d[40]; t2 = d[24]; t3 = d[8];
        p3 = t0 + t2; int p4 = t1 + t3; p1 = t0 + t3; p2 = t1 + t2;
        int p5 = (p3 + p4) * 4816;
        t0 *= 1223; t1 *= 8410; t2 *= 12586; t3 *= 6149;
        p1 = p5 + p1 * -3685; p2 = p5 + p2 * -10497; p3 *= -8034; p4 *= -1597;
        t3 += p1 + p4; t2 += p2 + p3; t1 += p2 + p4; t0 += p1 + p3;
        x0 += 512; x1 += 512; x2 += 512; x3 += 512;
        v[0] = (x0 + t3) >> 10; v[56] = (x0 - t3) >> 10; v[8] = (x1 + t2) >> 10; v[48] = (x1 - t2) >> 10;
        v[16] = (x2 + t1) >> 10; v[40] = (x2 - t1) >> 10; v[24] = (x3 + t0) >> 10; v[32] = (x3 - t0) >> 10;
    }
    for (int i = 0; i < 8; i++) {
        const int *r = tmp + i * 8; uint8_t *o = out + i * stride;
        int p2 = r[2], p3 = r[6];
        int p1 = (p2 + p3) * 2217;
        int t2 = p1 + p3 * -7567, t3 = p1 + p2 * 3135;
        int t0 = (r[0] + r[4]) * 4096, t1 = (r[0] - r[4]) * 4096;
        int x0 = t0 + t3, x3 = t0 - t3, x1 = t1 + t2, x2 = t1 - t2;
        t0 = r[7]; t1 = r[5]; t2 = r[3]; t3 = r[1];
        p3 = t0 + t2; int p4 = t1 + t3; p1 = t0 + t3; p2 = t1 + t2;
        int p5 = (p3 + p4) * 4816;
        t0 *= 1223; t1 *= 8410; t2 *= 12586; t3 *= 6149;
        p1 = p5 + p1 * -3685; p2 = p5 + p2 * -10497; p3 *= -8034; p4 *= -1597;
        t3 += p1 + p4; t2 += p2 + p3; t1 += p2 + p4; t0 += p1 + p3;
        int bias = 65536 + (128 << 17);
        x0 += bias; x1 += bias; x2 += bias; x3 += bias;
        int vals[8] = { (x0 + t3) >> 17, (x1 + t2) >> 17, (x2 + t1) >> 17, (x3 + t0) >> 17, (x3 - t0) >> 17, (x2 - t1) >> 17, (x1 - t2) >> 17, (x0 - t3) >> 17 };
        for (int k = 0; k < 8; k++) o[k] = (uint8_t)(vals[k] < 0 ? 0 : vals[k] > 255 ? 255 : vals[k]);
    }
}

static int jpeg_decode(const uint8_t *d, size_t n, struct img *out) {
    if (n < 4 || d[0] != 0xFF || d[1] != 0xD8) return IMG_E_FORMAT;
    struct jpg *j = kmalloc(sizeof *j);
    if (!j) return IMG_E_MEMORY;
    memset(j, 0, sizeof *j);
    j->d = d; j->n = n; j->p = 2;
    struct jcomp comp[3]; int nc = 0, W = 0, H = 0, rst = 0, adobe_tf = -1, rc = IMG_E_CORRUPT;
    memset(comp, 0, sizeof comp);
    uint32_t *px = NULL;
    while (j->p + 4 <= n) {
        if (d[j->p] != 0xFF) { j->p++; continue; }
        uint8_t m = d[j->p + 1];
        if (m == 0xFF) { j->p++; continue; }
        if (m == 0xD8 || (m >= 0xD0 && m <= 0xD7) || m == 0x01 || m == 0) { j->p += 2; continue; }
        if (m == 0xD9) break;
        size_t len = ((size_t)d[j->p + 2] << 8) | d[j->p + 3];
        if (len < 2 || j->p + 2 + len > n) goto fail;
        const uint8_t *s = d + j->p + 4; size_t sl = len - 2;
        if (m == 0xDB) {
            while (sl >= 65 || (sl >= 1 && sl > 0)) {
                int pq = s[0] >> 4, tq = s[0] & 15; size_t need = 1 + (pq ? 128 : 64);
                if (tq > 3 || sl < need) goto fail;
                for (int i = 0; i < 64; i++) j->qt[tq][zigzag[i]] = pq ? (uint16_t)((s[1 + i * 2] << 8) | s[2 + i * 2]) : s[1 + i];
                s += need; sl -= need;
                if (!sl) break;
            }
        } else if (m == 0xC4) {
            while (sl >= 17) {
                int tc = s[0] >> 4, th = s[0] & 15; if (th > 3 || tc > 1) goto fail;
                struct jhuff *h = tc ? &j->ac[th] : &j->dc[th];
                int total = 0; h->bits[0] = 0;
                for (int i = 1; i <= 16; i++) { h->bits[i] = s[i]; total += s[i]; }
                if (total > 256 || (size_t)17 + (size_t)total > sl) goto fail;
                memcpy(h->vals, s + 17, (size_t)total);
                jh_build(h);
                s += 17 + total; sl -= 17 + (size_t)total;
            }
        } else if (m == 0xC0 || m == 0xC1) {
            if (sl < 6 || s[0] != 8) { rc = IMG_E_FORMAT; goto fail; }
            H = (s[1] << 8) | s[2]; W = (s[3] << 8) | s[4]; nc = s[5];
            if ((nc != 1 && nc != 3) || sl < (size_t)6 + (size_t)nc * 3 || W <= 0 || H <= 0) { rc = IMG_E_FORMAT; goto fail; }
            if ((uint64_t)W * H > MAX_PIXELS) { rc = IMG_E_MEMORY; goto fail; }
            for (int i = 0; i < nc; i++) { comp[i].id = s[6 + i * 3]; comp[i].h = s[7 + i * 3] >> 4; comp[i].v = s[7 + i * 3] & 15; comp[i].tq = s[8 + i * 3] & 3;
                                           if (comp[i].h < 1 || comp[i].h > 2 || comp[i].v < 1 || comp[i].v > 2) { rc = IMG_E_FORMAT; goto fail; } }
        } else if (m == 0xC2 || m == 0xC3 || (m >= 0xC5 && m <= 0xCF && m != 0xC8 && m != 0xCC)) { rc = IMG_E_FORMAT; goto fail; }   /* progressive и прочее */
        else if (m == 0xDD) { if (sl >= 2) rst = (s[0] << 8) | s[1]; }
        else if (m == 0xEE) { if (sl >= 12 && memcmp(s, "Adobe", 5) == 0) adobe_tf = s[11]; }
        else if (m == 0xDA) {
            if (!nc || sl < 1 || s[0] != nc) { rc = IMG_E_FORMAT; goto fail; }
            for (int i = 0; i < nc; i++) { int cid = s[1 + i * 2];
                int k; for (k = 0; k < nc; k++) if (comp[k].id == cid) break;
                if (k == nc) goto fail;
                comp[k].td = s[2 + i * 2] >> 4; comp[k].ta = s[2 + i * 2] & 15; if (comp[k].td > 3 || comp[k].ta > 3) goto fail; }
            j->p += 2 + len;
            int hmax = 1, vmax = 1;
            for (int i = 0; i < nc; i++) { if (comp[i].h > hmax) hmax = comp[i].h; if (comp[i].v > vmax) vmax = comp[i].v; }
            int mcux = (W + 8 * hmax - 1) / (8 * hmax), mcuy = (H + 8 * vmax - 1) / (8 * vmax);
            for (int i = 0; i < nc; i++) {
                comp[i].bw = mcux * comp[i].h * 8; comp[i].bh = mcuy * comp[i].v * 8;
                comp[i].buf = kmalloc((size_t)comp[i].bw * comp[i].bh);
                if (!comp[i].buf) { rc = IMG_E_MEMORY; goto fail; }
            }
            int count = 0;
            for (int my = 0; my < mcuy; my++) for (int mx = 0; mx < mcux; mx++) {
                if (rst && count && count % rst == 0) {                  /* RSTn: выровнять и сбросить предсказания */
                    j->nb = 0; j->hit_marker = 0;
                    while (j->p + 1 < n && !(d[j->p] == 0xFF && d[j->p + 1] >= 0xD0 && d[j->p + 1] <= 0xD7)) j->p++;
                    j->p += 2;
                    for (int i = 0; i < nc; i++) comp[i].pred = 0;
                }
                count++;
                for (int ci = 0; ci < nc; ci++) {
                    struct jcomp *c = &comp[ci];
                    for (int by = 0; by < c->v; by++) for (int bx = 0; bx < c->h; bx++) {
                        int coef[64]; memset(coef, 0, sizeof coef);
                        int t = jdecode(j, &j->dc[c->td]);
                        if (t < 0 || t > 16) goto fail;
                        c->pred += jextend(jreceive(j, t), t);
                        coef[0] = c->pred * j->qt[c->tq][0];
                        for (int k = 1; k < 64; ) {
                            int rs = jdecode(j, &j->ac[c->ta]);
                            if (rs < 0) goto fail;
                            int r = rs >> 4, sz = rs & 15;
                            if (!sz) { if (r == 15) { k += 16; continue; } break; }
                            k += r; if (k > 63) break;
                            coef[zigzag[k]] = jextend(jreceive(j, sz), sz) * j->qt[c->tq][zigzag[k]];
                            k++;
                        }
                        idct(c->buf + (size_t)((my * c->v + by) * 8) * (size_t)c->bw + (size_t)(mx * c->h + bx) * 8, c->bw, coef);
                    }
                }
            }
            px = kmalloc((size_t)W * H * 4);
            if (!px) { rc = IMG_E_MEMORY; goto fail; }
            int rgb = (nc == 3 && adobe_tf != 0);
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                int v[3];
                for (int i = 0; i < nc; i++) {
                    const struct jcomp *c = &comp[i];
                    if (c->h == hmax && c->v == vmax) { v[i] = c->buf[(size_t)y * (size_t)c->bw + (size_t)x]; continue; }
                    /* цветность растянута: билинейная интерполяция по центрам пикселей (как «fancy upsampling» libjpeg) */
                    int cw = (W * c->h + hmax - 1) / hmax, ch = (H * c->v + vmax - 1) / vmax;
                    int u = ((2 * x + 1) * c->h * 256) / (2 * hmax) - 128, w2 = ((2 * y + 1) * c->v * 256) / (2 * vmax) - 128;
                    int x0 = u >> 8, fx = u & 255, y0 = w2 >> 8, fy = w2 & 255;
                    int x1 = x0 + 1, y1 = y0 + 1;
                    if (x0 < 0) { x0 = 0; }
                    if (x1 < 0) { x1 = 0; }
                    if (x0 >= cw) { x0 = cw - 1; }
                    if (x1 >= cw) { x1 = cw - 1; }
                    if (y0 < 0) { y0 = 0; }
                    if (y1 < 0) { y1 = 0; }
                    if (y0 >= ch) { y0 = ch - 1; }
                    if (y1 >= ch) { y1 = ch - 1; }
                    int a = c->buf[(size_t)y0 * (size_t)c->bw + (size_t)x0], b = c->buf[(size_t)y0 * (size_t)c->bw + (size_t)x1];
                    int cc = c->buf[(size_t)y1 * (size_t)c->bw + (size_t)x0], dd = c->buf[(size_t)y1 * (size_t)c->bw + (size_t)x1];
                    int top = a * (256 - fx) + b * fx, bot = cc * (256 - fx) + dd * fx;
                    v[i] = (top * (256 - fy) + bot * fy + 32768) >> 16;
                }
                int r, g, b;
                if (nc == 1) r = g = b = v[0];
                else if (rgb) {
                    int Y = v[0], cb = v[1] - 128, cr = v[2] - 128;
                    r = Y + ((91881 * cr) >> 16); g = Y - ((22554 * cb + 46802 * cr) >> 16); b = Y + ((116130 * cb) >> 16);
                } else { r = v[0]; g = v[1]; b = v[2]; }
                r = r < 0 ? 0 : r > 255 ? 255 : r; g = g < 0 ? 0 : g > 255 ? 255 : g; b = b < 0 ? 0 : b > 255 ? 255 : b;
                px[(size_t)y * W + x] = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
            }
            out->w = W; out->h = H; out->px = px; rc = 0;
            goto fail;
        }
        j->p += 2 + len;
    }
fail:
    for (int i = 0; i < 3; i++) if (comp[i].buf) kfree(comp[i].buf);
    if (rc != 0 && px) kfree(px);
    kfree(j);
    return rc;
}

/* ================= общий вход ================= */

int img_decode(const uint8_t *data, size_t len, int max_w, int max_h, struct img *out) {
    struct img im = { 0, 0, NULL };
    int rc;
    if (len >= 8 && memcmp(data, "\x89PNG", 4) == 0) rc = png_decode(data, len, &im);
    else if (len >= 3 && data[0] == 0xFF && data[1] == 0xD8) rc = jpeg_decode(data, len, &im);
    else if (len >= 6 && memcmp(data, "GIF8", 4) == 0) rc = gif_decode(data, len, &im);
    else return IMG_E_FORMAT;
    if (rc != 0) return rc;
    int dw = im.w, dh = im.h;
    if (max_w > 0 && dw > max_w) { dh = (int)((int64_t)dh * max_w / dw); dw = max_w; }
    if (max_h > 0 && dh > max_h) { dw = (int)((int64_t)dw * max_h / dh); dh = max_h; }
    if (dw < 1) dw = 1;
    if (dh < 1) dh = 1;
    if (dw == im.w && dh == im.h) { *out = im; return 0; }
    uint32_t *np = kmalloc((size_t)dw * dh * 4);
    if (!np) { kfree(im.px); return IMG_E_MEMORY; }
    for (int y = 0; y < dh; y++) {                                  /* уменьшение усреднением по площади */
        int sy0 = (int)((int64_t)y * im.h / dh), sy1 = (int)((int64_t)(y + 1) * im.h / dh); if (sy1 <= sy0) sy1 = sy0 + 1;
        for (int x = 0; x < dw; x++) {
            int sx0 = (int)((int64_t)x * im.w / dw), sx1 = (int)((int64_t)(x + 1) * im.w / dw); if (sx1 <= sx0) sx1 = sx0 + 1;
            uint32_t r = 0, g = 0, b = 0, cnt = 0;
            for (int yy = sy0; yy < sy1; yy++) for (int xx = sx0; xx < sx1; xx++) {
                uint32_t c = im.px[(size_t)yy * im.w + xx]; r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255; cnt++;
            }
            np[(size_t)y * dw + x] = ((r / cnt) << 16) | ((g / cnt) << 8) | (b / cnt);
        }
    }
    kfree(im.px);
    out->w = dw; out->h = dh; out->px = np;
    return 0;
}

void img_free(struct img *im) { if (im->px) kfree(im->px); im->px = NULL; im->w = im->h = 0; }

int base64_decode(const char *s, size_t n, uint8_t *out, size_t max) {
    uint32_t acc = 0; int bits = 0; size_t o = 0;
    for (size_t i = 0; i < n; i++) {
        char c = s[i]; int v;
        if (c >= 'A' && c <= 'Z') v = c - 'A'; else if (c >= 'a' && c <= 'z') v = c - 'a' + 26; else if (c >= '0' && c <= '9') v = c - '0' + 52;
        else if (c == '+' || c == '-') v = 62; else if (c == '/' || c == '_') v = 63;
        else if (c == '=' || c == ' ' || c == '\n' || c == '\r') continue; else return -1;
        acc = (acc << 6) | (uint32_t)v; bits += 6;
        if (bits >= 8) { bits -= 8; if (o >= max) return -1; out[o++] = (uint8_t)(acc >> bits); acc &= (1u << bits) - 1; }
    }
    return (int)o;
}
