#ifndef LIMON_BROWSER_H
#define LIMON_BROWSER_H
#include <stddef.h>
#include <stdint.h>
#include "image.h"

/* Citrus 2 — движок страниц: разбирает HTML в готовые строки с оформлением, ссылками и формами.
 * Устройство: HTML -> дерево DOM -> CSS (селекторы тег/#id/.класс/потомок/дочерний, специфичность, !important,
 * display/visibility/opacity, color, background, font-weight, text-align, white-space) -> строки с разметкой.
 * Чего НЕТ: внешние файлы CSS (<link>), float/position/размеры, JavaScript, картинки (пока).
 *
 * В строке, кроме текста UTF-8, бывают служебные коды (в обычном тексте их нет):
 *   PGM_COLOR c      — сменить цвет ('0'+PG_C_*)
 *   PGM_LINK  h l    — начало ссылки №((h-'0')<<6 | (l-'0'))
 *   PGM_LINKEND      — конец ссылки
 *   PGM_INPUT h l    — поле ввода №..., ширина PG_FIELD_COLS столбцов
 *   PGM_BUTTON h l   — кнопка №...; ширина = длина подписи + 4 */
#define PGM_COLOR   1
#define PGM_LINK    2
#define PGM_LINKEND 3
#define PGM_INPUT   4
#define PGM_BUTTON  5
#define PGM_RGB     6     /* + 6 шестнадцатеричных цифр RRGGBB — произвольный цвет текста */
#define PGM_BOLD    7     /* + '1' жирный включить, '0' выключить */
#define PGM_IMG     9     /* + 2 цифры номера картинки + 2 цифры номера строки картинки (высота строки 16 px) */
#define PGM_BG      8     /* + 6 hex цифр: залить всю строку этим цветом (фон блока); ставится в начале строки */

enum { PG_C_TEXT = 0, PG_C_HEAD, PG_C_LINK, PG_C_BOLD, PG_C_DIM, PG_C_CODE };

#define PG_MAXLINES  4000
#define PG_MAXLINKS  600
#define PG_MAXINPUTS 64
#define PG_MAXFORMS  16
#define PG_MAXIMAGES 16
#define PG_FIELD_COLS 26

enum { IN_HIDDEN = 0, IN_TEXT, IN_SUBMIT };

struct pg_input {
    char name[32];
    char value[96];
    uint8_t kind, password;
    int form;
    char fa[200];                 /* formaction кнопки: свой адрес отправки; "{q}" заменяется текстом из поля формы */
};
struct pg_form { char action[640]; int post; };

struct pg_image { uint32_t *px; int w, h; };

struct page {
    char *lines[PG_MAXLINES];
    int nlines;
    char *links[PG_MAXLINKS];            /* готовые абсолютные адреса */
    int nlinks;
    struct pg_input inputs[PG_MAXINPUTS];
    int ninputs;
    struct pg_form forms[PG_MAXFORMS];
    int nforms;
    struct pg_image images[PG_MAXIMAGES];
    int nimages;
    size_t img_bytes;
    char title[80];
    uint32_t bg;                         /* цвет фона страницы 0xRRGGBB (из CSS/bgcolor); 0xFFFFFF по умолчанию */
    int dark;                            /* фон тёмный — палитра по умолчанию светлая */
    char refresh[640];                   /* адрес из <meta http-equiv=refresh>, если есть */
};

/* Загрузчик внешних файлов CSS: кладёт ТЕЛО ответа в out, возвращает длину (<=0 — не вышло). */
typedef int (*page_fetch_fn)(const char *url, char *out, size_t max);
void page_set_fetch(page_fetch_fn fn);

/* Загрузчик картинок: по адресу (или data:-ссылке) получает готовые пиксели, уже уменьшенные до max_w x max_h.
 * 0 — успех (пиксели освобождает страница), иначе картинка пропускается и вместо неё показывается alt. */
typedef int (*page_img_fn)(const char *url, int max_w, int max_h, struct img *out);
void page_set_img_fetch(page_img_fn fn);

/* html — текст в UTF-8; base — адрес страницы (для относительных ссылок); cols — ширина в символах */
void page_render(struct page *pg, const char *html, size_t len, int cols, const char *base);
void page_render_text(struct page *pg, const char *text, size_t len, int cols);   /* text/plain */
void page_free(struct page *pg);

/* собирает адрес отправки формы (GET); clicked — номер нажатой кнопки или -1 */
int  page_form_url(const struct page *pg, int form, int clicked, char *out, size_t max);
void url_encode(const char *s, char *out, size_t max);

/* windows-1251 -> UTF-8 (новая память, освободить kfree) */
char *cp1251_to_utf8(const char *s, size_t n, size_t *out_len);

#endif
