#include "grabutil.h"
#include "kstring.h"

const uint8_t *mem_find(const uint8_t *h, size_t n, const char *needle) {
    size_t nl = strlen(needle);
    if (!nl || n < nl) return NULL;
    for (size_t i = 0; i + nl <= n; i++) if (memcmp(h + i, needle, nl) == 0) return h + i;
    return NULL;
}

int url_has_no_path(const char *u) {
    const char *p = u;
    for (const char *q = u; q[0] && q[1] && q[2]; q++) if (q[0] == ':' && q[1] == '/' && q[2] == '/') { p = q + 3; break; }
    while (*p && *p != '/') p++;
    if (!*p) return 1;
    return p[1] == 0;
}

int looks_like_dir_listing(const uint8_t *d, size_t n) {
    size_t head = n < 1500 ? n : 1500;
    return mem_find(d, head, "Directory listing for") != NULL || mem_find(d, head, "Index of /") != NULL;
}

int listing_names(const uint8_t *d, size_t n, char names[][64], int max) {
    int found = 0;
    for (size_t i = 0; i + 6 < n && found < max; i++) {
        if (memcmp(d + i, "href=\"", 6) != 0) continue;
        size_t j = i + 6, k = 0; char nm[64];
        while (j < n && d[j] != '"' && k < 63) nm[k++] = (char)d[j++];
        nm[k] = 0;
        if (!k || nm[0] == '?' || nm[0] == '/' || nm[0] == '#') continue;
        memcpy(names[found], nm, k + 1);
        found++;
    }
    return found;
}
