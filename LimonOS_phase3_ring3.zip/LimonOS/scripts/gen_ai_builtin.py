#!/usr/bin/env python3
"""Делает kernel/ai_builtin.h из config/ai_key.txt — ключ ИИ, встроенный прямо в kernel.elf/ISO
при сборке, чтобы не вводить его руками в шелле после каждой загрузки.

Запускается автоматически через `make` (ничего руками делать не надо), но можно и напрямую:
    python3 scripts/gen_ai_builtin.py config/ai_key.txt kernel/ai_builtin.h

ВАЖНО, честно: встроенный так ключ лежит в kernel.elf и в ISO ОТКРЫТЫМ ТЕКСТОМ — это не секретное
хранилище, а обычная константа в бинарнике. Кто угодно с доступом к файлу kernel.elf или .iso может
прочитать ключ (например, `strings kernel.elf`). Подходит для своей машины/флешки, которую не отдаёшь
посторонним; не подходит, если образ будет публично доступен. Поэтому и config/ai_key.txt, и
kernel/ai_builtin.h — в .gitignore: ключ никогда не должен попасть в git."""
import sys, os

src = sys.argv[1] if len(sys.argv) > 1 else "config/ai_key.txt"
out = sys.argv[2] if len(sys.argv) > 2 else "kernel/ai_builtin.h"

key = ""
if os.path.exists(src):
    with open(src, encoding="utf-8", errors="replace") as f:
        key = f.read().strip()
    # Файл может быть многострочным (например, скопировали с комментарием) — берём первую непустую
    # строку, похожую на ключ, а не весь текст целиком.
    for line in key.splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            key = line
            break
    else:
        key = ""

if len(key) > 200:
    sys.exit("gen_ai_builtin: содержимое %s длиннее 200 символов — это не похоже на ключ, проверь файл" % src)

def esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')

with open(out, "w", encoding="utf-8") as f:
    f.write("/* Автоматически сгенерировано scripts/gen_ai_builtin.py из %s при каждой сборке.\n" % src)
    f.write(" * НЕ редактируй руками — положи ключ в %s и пересобери (make).\n" % src)
    f.write(" * %s и этот файл — в .gitignore: ключ не должен попасть в git.\n" % src)
    f.write(" * ВНИМАНИЕ: ключ будет лежать в kernel.elf/.iso открытым текстом (см. комментарий\n")
    f.write(" * в начале scripts/gen_ai_builtin.py) — это обычная константа в бинарнике, не сейф. */\n")
    f.write('#define AI_BUILTIN_KEY "%s"\n' % esc(key))

if key:
    print("gen_ai_builtin: ключ из %s встроен в %s (%d симв.)" % (src, out, len(key)))
else:
    print("gen_ai_builtin: %s нет или пуст — %s встроит пустой ключ (aikey как раньше, руками)" % (src, out))
