#!/bin/bash
# Проверки без железа и без эмулятора: формат вывода, игры, FAT32, куча/сборка ядра, снимки рабочего стола.
# Запуск:  tests/run_host_tests.sh   (нужны gcc и python3 с Pillow для PNG)
set -e
cd "$(dirname "$0")/.."
T=/tmp/limon_tests; mkdir -p $T
echo "== format (%.47s и др.)"; gcc -Ikernel tests/format_host.c kernel/format.c kernel/string.c -o $T/fmt && $T/fmt
echo "== игры (ASan+UBSan)"; gcc -Wall -Wextra -O1 -fsanitize=address,undefined -Ikernel tests/games_host.c kernel/games.c -o $T/games && $T/games
echo "== FAT32 (образ собирает tests/mkfat32.py)"; python3 tests/mkfat32.py $T/fat.img
gcc -Wall -Wextra -g -fsanitize=address,undefined -Ikernel tests/fat_host.c kernel/fat32.c -o $T/fat && ASAN_OPTIONS=detect_leaks=0 $T/fat $T/fat.img $T/fat.img.big
echo "== ядро собирается без предупреждений"; make -s 2>&1 | grep -E "warning|error" && exit 1 || true
echo "== снимки рабочего стола -> $T/shot_*.ppm"
SRCS=$(ls kernel/*.c | grep -v -E "kernel/(kernel|mem|interrupts|gdt|idt|pic|ps2|mouse|string|ring3)\.c")
gcc -std=gnu11 -O1 -w -DHOST_TEST -Ikernel tests/desktop_shot.c tests/hoststubs.c kernel/string.c kernel/mouse.c $SRCS -o $T/shot && (cd /tmp && $T/shot 1024 768)
echo "ВСЁ ОК"

echo "== Memoria/VFS (ASan+UBSan)"
gcc -Wall -Wextra -g -fsanitize=address,undefined -Ikernel tests/vfs_host.c kernel/vfs.c kernel/format.c kernel/string.c -o $T/vfs
ASAN_OPTIONS=detect_leaks=0 $T/vfs

echo "== Проводник/Диспетчер задач -> $T/shot_files_*.ppm, shot_taskmgr.ppm"
gcc -std=gnu11 -O1 -w -DHOST_TEST -Ikernel tests/desktop_shot2.c tests/hoststubs.c kernel/string.c kernel/mouse.c $SRCS -o $T/shot2 && (cd /tmp && $T/shot2 1024 768)
echo "ВСЁ ОК (2)"

echo "== ELF64-загрузчик, фаза 1: разбор/проверка (ASan+UBSan) -- docs/USERSPACE_PLAN.md"
gcc -nostdlib -static -no-pie tests/tiny_static.S -o $T/tiny_static
gcc -Wall -Wextra -g -fsanitize=address,undefined -Ikernel tests/elf_host.c kernel/elf.c kernel/string.c -o $T/elf_test
ASAN_OPTIONS=detect_leaks=0 $T/elf_test $T/tiny_static
echo "ELF OK (2)"

echo "== Таблицы страниц на процесс, фаза 2: map/unmap/translate/share (ASan+UBSan) -- docs/USERSPACE_PLAN.md"
gcc -Wall -Wextra -g -fsanitize=address,undefined -DHOST_TEST -Ikernel tests/vmm_host.c kernel/vmm.c kernel/string.c -o $T/vmm_test
ASAN_OPTIONS=detect_leaks=0 $T/vmm_test
echo "VMM OK (2)"

echo "== GDT/TSS, фаза 3: кодирование дескрипторов (чистая арифметика, без asm) -- docs/USERSPACE_PLAN.md"
gcc -Wall -Wextra -g -Ikernel tests/gdt_host.c kernel/gdt.c -o $T/gdt && $T/gdt
echo "ВСЁ ОК (3)"

echo "== config/ai_key.txt -> kernel/ai_builtin.h (встроенный ключ ИИ при сборке)"
tests/ai_builtin_host.sh
echo "ВСЁ ОК (4)"
