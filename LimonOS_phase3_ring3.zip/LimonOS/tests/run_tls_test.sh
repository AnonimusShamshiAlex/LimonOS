#!/bin/bash
# Настоящий OpenSSL-сервер на localhost + наш TLS-клиент. Проверяем оба набора шифров и два типа сертификатов.
set -e
cd "$(dirname "$0")/.."
T=/tmp/tlstest; rm -rf $T; mkdir -p $T/www; cd $T
head -c 3000000 /dev/urandom > www/big.bin
echo "hello from openssl" > www/hello.txt
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -keyout ec.key -out ec.crt -subj "/CN=localhost" -days 2 2>/dev/null
openssl req -x509 -newkey rsa:2048 -nodes -keyout rsa.key -out rsa.crt -subj "/CN=localhost" -days 2 2>/dev/null
cd - >/dev/null
gcc -O2 -Wall -Wextra -I kernel -I tests tests/tls_host_test.c kernel/tls.c kernel/crypto.c -o $T/client
pass=0; fail=0
for cert in ec rsa; do for suite in TLS_CHACHA20_POLY1305_SHA256 TLS_AES_128_GCM_SHA256; do
  port=$((4400 + RANDOM % 500))
  (cd $T/www && exec openssl s_server -accept $port -cert ../$cert.crt -key ../$cert.key -tls1_3 -ciphersuites $suite -WWW -quiet >/dev/null 2>&1) &
  SP=$!; sleep 0.7
  if $T/client $port /big.bin > $T/out.raw 2> $T/err.txt; then
    # отрезаем HTTP-заголовки и сравниваем с оригиналом
    python3 - "$T" <<'PY' && ok=1 || ok=0
import sys,hashlib
T=sys.argv[1]; d=open(T+"/out.raw","rb").read(); i=d.index(b"\r\n\r\n")+4
sys.exit(0 if hashlib.sha256(d[i:]).digest()==hashlib.sha256(open(T+"/www/big.bin","rb").read()).digest() else 1)
PY
  else ok=0; fi
  cipher=$(grep набор $T/err.txt || true)
  if [ "$ok" = 1 ]; then echo "  ok   $cert / $suite  ($cipher), 3 МБ совпали побайтно"; pass=$((pass+1)); else echo "  FAIL $cert / $suite"; cat $T/err.txt; fail=$((fail+1)); fi
  kill $SP 2>/dev/null; wait $SP 2>/dev/null || true
done; done
echo "ПРОШЛО: $pass, ПРОВАЛОВ: $fail"; [ $fail = 0 ]
