/* Проверка кодирования дескрипторов GDT/TSS: чистая арифметика, без ассемблера и без CPU.
   Эталоны — те же магические константы, что годами стоят в коде ядра (0x00AF9A000000FFFF и
   т.п.), плюс ручной разбор побитовым правилам Intel SDM vol.3 §3.4.5 и §7.2.3. */
#include <stdio.h>
#include <stdint.h>
#define HOST_TEST
#include "gdt.h"
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static int fails;

int main(void) {
    /* 1) существующие, годами проверенные константы ядра (kcode/kdata) должна воспроизводить формула */
    CHECK(gdt_make_desc(0, 0xFFFFF, 0x9A, 0xA) == 0x00AF9A000000FFFFULL);
    CHECK(gdt_make_desc(0, 0xFFFFF, 0x92, 0xC) == 0x00CF92000000FFFFULL);

    /* 2) пользовательские сегменты: тот же шаблон, но DPL=3 (биты 45:46 access = 11) */
    uint64_t ucode = gdt_make_desc(0, 0xFFFFF, 0xFA, 0xA);
    uint64_t udata = gdt_make_desc(0, 0xFFFFF, 0xF2, 0xC);
    CHECK(ucode == 0x00AFFA000000FFFFULL);
    CHECK(udata == 0x00CFF2000000FFFFULL);
    /* DPL — биты 45-46 байта access (access лежит в битах 40-47 слова) */
    CHECK(((ucode >> 45) & 3) == 3);
    CHECK(((udata >> 45) & 3) == 3);
    /* P=1 (бит 47), S=1 (бит 44, не system-сегмент) у обоих */
    CHECK(((ucode >> 47) & 1) == 1 && ((ucode >> 44) & 1) == 1);
    CHECK(((udata >> 47) & 1) == 1 && ((udata >> 44) & 1) == 1);

    /* 3) селекторы с RPL=3 — ровно классические 0x1B/0x23 (как в Linux) */
    CHECK(GDT_SEL_UCODE_RPL3 == 0x1B);
    CHECK(GDT_SEL_UDATA_RPL3 == 0x23);
    CHECK(GDT_SEL_TSS == 0x28);

    /* 4) TSS занимает ровно 104 байта, как того требует Intel SDM §7.7 (иначе limit будет не тот) */
    CHECK(sizeof(struct tss64) == 104);

    /* 5) дескриптор TSS: round-trip для не слишком простого (не нулевого, не выровненного красиво) base */
    uint64_t base = 0x00007F1234567890ULL;   /* произвольный "честный" канонический адрес */
    uint32_t limit = sizeof(struct tss64) - 1;
    uint64_t d[2];
    gdt_make_tss_desc(base, limit, d);
    /* разбираем обратно по тем же формулам, что и обычный дескриптор, плюс верхние 32 бита базы из d[1] */
    uint32_t got_limit = (uint32_t)(d[0] & 0xFFFF) | (uint32_t)((d[0] >> 48) & 0xF) << 16;
    uint64_t got_base_lo = ((d[0] >> 16) & 0xFFFFFFu) | (((d[0] >> 56) & 0xFFu) << 24);
    uint64_t got_base = got_base_lo | (d[1] << 32);
    uint8_t got_access = (uint8_t)((d[0] >> 40) & 0xFF);
    CHECK(got_limit == limit);
    CHECK(got_base == base);
    CHECK(got_access == 0x89);              /* P=1, DPL=00, доступный 64-битный TSS (тип 1001) */
    CHECK((d[1] >> 32) == 0);               /* верхняя половина второго слова обязана быть нулём (резерв) */

    /* 6) дескриптор TSS с базой 0 и малым лимитом — крайний случай, не должен ронять формулу */
    uint64_t d0[2];
    gdt_make_tss_desc(0, 103, d0);
    CHECK(d0[0] == 0x0000890000000067ULL);  /* 0x67 = 103, access=0x89, база и верх лимита = 0 */
    CHECK(d0[1] == 0);

    printf(fails ? "FAILED %d\n" : "GDT OK\n", fails);
    return fails != 0;
}
