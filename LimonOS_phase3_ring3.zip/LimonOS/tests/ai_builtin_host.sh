#!/bin/bash
# Проверяет scripts/gen_ai_builtin.py на реальных временных файлах (не выдуманных строках).
set -e
cd "$(dirname "$0")/.."
T=$(mktemp -d)

# 1) обычный ключ
echo "sk-ant-ABCDEF123456" > "$T/key.txt"
python3 scripts/gen_ai_builtin.py "$T/key.txt" "$T/out.h"
grep -q '#define AI_BUILTIN_KEY "sk-ant-ABCDEF123456"' "$T/out.h" || { echo "FAIL: обычный ключ не встроился"; exit 1; }

# 2) файла нет — должен быть пустой ключ, не ошибка
python3 scripts/gen_ai_builtin.py "$T/nope.txt" "$T/out2.h"
grep -q '#define AI_BUILTIN_KEY ""' "$T/out2.h" || { echo "FAIL: отсутствующий файл не дал пустой ключ"; exit 1; }

# 3) кавычки и обратный слеш в содержимом не ломают C-синтаксис (экранирование)
printf 'sk-ant-"with\\quote' > "$T/weird.txt"
python3 scripts/gen_ai_builtin.py "$T/weird.txt" "$T/out3.h"
grep -q '#define AI_BUILTIN_KEY "sk-ant-\\"with\\\\quote"' "$T/out3.h" || { echo "FAIL: экранирование кавычек/слешей"; cat "$T/out3.h"; exit 1; }
gcc -x c -fsyntax-only - <<CEOF || { echo "FAIL: сгенерированный заголовок не компилируется"; exit 1; }
#include "$T/out3.h"
const char *x = AI_BUILTIN_KEY;
int main(void){ return x[0]==0; }
CEOF

# 4) многострочный файл (с комментарием сверху) — берём первую непустую строку, не начинающуюся с #
printf '# мой ключ\nsk-or-v1-XYZ\n' > "$T/comment.txt"
python3 scripts/gen_ai_builtin.py "$T/comment.txt" "$T/out4.h"
grep -q '#define AI_BUILTIN_KEY "sk-or-v1-XYZ"' "$T/out4.h" || { echo "FAIL: многострочный файл с комментарием"; cat "$T/out4.h"; exit 1; }

# 5) слишком длинное содержимое (не похоже на ключ) — скрипт должен отказаться, а не встроить мусор
python3 -c "print('x'*300)" > "$T/toolong.txt"
if python3 scripts/gen_ai_builtin.py "$T/toolong.txt" "$T/out5.h" 2>/dev/null; then echo "FAIL: слишком длинный файл должен быть отклонён"; exit 1; fi

rm -rf "$T"
echo "AI_BUILTIN OK"
