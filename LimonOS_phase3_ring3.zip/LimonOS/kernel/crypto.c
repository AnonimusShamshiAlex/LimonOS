#include "crypto.h"
#include "kstring.h"

/* ====================== утилиты ====================== */

static inline uint32_t rotr32(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }
static inline uint32_t rotl32(uint32_t x, int n) { return (x << n) | (x >> (32 - n)); }
static inline uint32_t ld32le(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
static inline void st32le(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }
static inline uint32_t ld32be(const uint8_t *p) { return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }
static inline void st32be(uint8_t *p, uint32_t v) { p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v; }
static inline uint64_t ld64be(const uint8_t *p) { return ((uint64_t)ld32be(p) << 32) | ld32be(p + 4); }
static inline void st64be(uint8_t *p, uint64_t v) { st32be(p, (uint32_t)(v >> 32)); st32be(p + 4, (uint32_t)v); }

int ct_memcmp(const void *a, const void *b, size_t n) {
    const uint8_t *x = a, *y = b;
    uint8_t d = 0;
    for (size_t i = 0; i < n; i++) d |= (uint8_t)(x[i] ^ y[i]);
    return d;
}

/* ====================== SHA-256 ====================== */

static const uint32_t K256[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

static void sha256_block(struct sha256 *c, const uint8_t *p) {
    uint32_t w[64], a, b, cc, d, e, f, g, h;
    for (int i = 0; i < 16; i++) w[i] = ld32be(p + 4 * i);
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = rotr32(w[i - 15], 7) ^ rotr32(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = rotr32(w[i - 2], 17) ^ rotr32(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    a = c->h[0]; b = c->h[1]; cc = c->h[2]; d = c->h[3]; e = c->h[4]; f = c->h[5]; g = c->h[6]; h = c->h[7];
    for (int i = 0; i < 64; i++) {
        uint32_t S1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25);
        uint32_t ch = (e & f) ^ (~e & g);
        uint32_t t1 = h + S1 + ch + K256[i] + w[i];
        uint32_t S0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22);
        uint32_t mj = (a & b) ^ (a & cc) ^ (b & cc);
        uint32_t t2 = S0 + mj;
        h = g; g = f; f = e; e = d + t1; d = cc; cc = b; b = a; a = t1 + t2;
    }
    c->h[0] += a; c->h[1] += b; c->h[2] += cc; c->h[3] += d; c->h[4] += e; c->h[5] += f; c->h[6] += g; c->h[7] += h;
}

void sha256_init(struct sha256 *c) {
    static const uint32_t iv[8] = { 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 };
    for (int i = 0; i < 8; i++) c->h[i] = iv[i];
    c->len = 0; c->n = 0;
}

void sha256_update(struct sha256 *c, const void *data, size_t len) {
    const uint8_t *p = data;
    c->len += len;
    while (len) {
        size_t k = 64 - c->n;
        if (k > len) k = len;
        memcpy(c->buf + c->n, p, k);
        c->n += k; p += k; len -= k;
        if (c->n == 64) { sha256_block(c, c->buf); c->n = 0; }
    }
}

void sha256_final(struct sha256 *c, uint8_t out[32]) {
    uint64_t bits = c->len * 8;
    uint8_t pad = 0x80;
    sha256_update(c, &pad, 1);
    pad = 0;
    while (c->n != 56) sha256_update(c, &pad, 1);
    uint8_t lb[8];
    st64be(lb, bits);
    sha256_update(c, lb, 8);
    for (int i = 0; i < 8; i++) st32be(out + 4 * i, c->h[i]);
}

void sha256(const void *data, size_t len, uint8_t out[32]) {
    struct sha256 c;
    sha256_init(&c); sha256_update(&c, data, len); sha256_final(&c, out);
}

/* ====================== HMAC / HKDF ====================== */

void hmac_sha256(const uint8_t *key, size_t klen, const void *data, size_t len, uint8_t out[32]) {
    uint8_t k[64], ipad[64], opad[64], inner[32];
    memset(k, 0, 64);
    if (klen > 64) sha256(key, klen, k); else if (klen) memcpy(k, key, klen);
    for (int i = 0; i < 64; i++) { ipad[i] = k[i] ^ 0x36; opad[i] = k[i] ^ 0x5c; }
    struct sha256 c;
    sha256_init(&c); sha256_update(&c, ipad, 64); sha256_update(&c, data, len); sha256_final(&c, inner);
    sha256_init(&c); sha256_update(&c, opad, 64); sha256_update(&c, inner, 32); sha256_final(&c, out);
}

void hkdf_extract(const uint8_t *salt, size_t slen, const uint8_t *ikm, size_t ilen, uint8_t prk[32]) {
    static const uint8_t zeros[32] = { 0 };
    if (!salt || !slen) { salt = zeros; slen = 32; }
    hmac_sha256(salt, slen, ikm, ilen, prk);
}

void hkdf_expand(const uint8_t prk[32], const uint8_t *info, size_t ilen, uint8_t *out, size_t olen) {
    uint8_t t[32], buf[32 + 255 + 1];
    size_t tl = 0, done = 0;
    uint8_t ctr = 1;
    while (done < olen) {
        size_t bl = 0;
        if (tl) { memcpy(buf, t, tl); bl = tl; }
        if (ilen > 255) ilen = 255;
        if (ilen) memcpy(buf + bl, info, ilen);
        bl += ilen;
        buf[bl++] = ctr++;
        hmac_sha256(prk, 32, buf, bl, t);
        tl = 32;
        size_t k = olen - done; if (k > 32) k = 32;
        memcpy(out + done, t, k);
        done += k;
    }
}

void tls13_expand_label(const uint8_t secret[32], const char *label,
                        const uint8_t *ctx, size_t clen, uint8_t *out, size_t olen) {
    uint8_t info[2 + 1 + 6 + 32 + 1 + 64];
    size_t ll = strlen(label), n = 0;
    info[n++] = (uint8_t)(olen >> 8); info[n++] = (uint8_t)olen;
    info[n++] = (uint8_t)(6 + ll);
    memcpy(info + n, "tls13 ", 6); n += 6;
    memcpy(info + n, label, ll); n += ll;
    info[n++] = (uint8_t)clen;
    if (clen) { memcpy(info + n, ctx, clen); n += clen; }
    hkdf_expand(secret, info, n, out, olen);
}

/* ====================== ChaCha20 ====================== */

#define QR(a, b, c, d) \
    a += b; d ^= a; d = rotl32(d, 16); \
    c += d; b ^= c; b = rotl32(b, 12); \
    a += b; d ^= a; d = rotl32(d, 8);  \
    c += d; b ^= c; b = rotl32(b, 7)

static void chacha_block(const uint8_t key[32], uint32_t counter, const uint8_t nonce[12], uint8_t out[64]) {
    uint32_t s[16], x[16];
    s[0] = 0x61707865; s[1] = 0x3320646e; s[2] = 0x79622d32; s[3] = 0x6b206574;
    for (int i = 0; i < 8; i++) s[4 + i] = ld32le(key + 4 * i);
    s[12] = counter;
    for (int i = 0; i < 3; i++) s[13 + i] = ld32le(nonce + 4 * i);
    for (int i = 0; i < 16; i++) x[i] = s[i];
    for (int r = 0; r < 10; r++) {
        QR(x[0], x[4], x[8],  x[12]); QR(x[1], x[5], x[9],  x[13]);
        QR(x[2], x[6], x[10], x[14]); QR(x[3], x[7], x[11], x[15]);
        QR(x[0], x[5], x[10], x[15]); QR(x[1], x[6], x[11], x[12]);
        QR(x[2], x[7], x[8],  x[13]); QR(x[3], x[4], x[9],  x[14]);
    }
    for (int i = 0; i < 16; i++) st32le(out + 4 * i, x[i] + s[i]);
}

static void chacha_xor(const uint8_t key[32], uint32_t counter, const uint8_t nonce[12],
                       const uint8_t *in, uint8_t *out, size_t len) {
    uint8_t ks[64];
    while (len) {
        chacha_block(key, counter++, nonce, ks);
        size_t k = len > 64 ? 64 : len;
        for (size_t i = 0; i < k; i++) out[i] = in[i] ^ ks[i];
        in += k; out += k; len -= k;
    }
}

/* ====================== Poly1305 (26-битные куски) ====================== */

struct poly { uint32_t r[5], h[5], pad[4]; uint8_t buf[16]; size_t n; };

static void poly_init(struct poly *p, const uint8_t key[32]) {
    p->r[0] = ld32le(key + 0) & 0x3ffffff;
    p->r[1] = (ld32le(key + 3) >> 2) & 0x3ffff03;
    p->r[2] = (ld32le(key + 6) >> 4) & 0x3ffc0ff;
    p->r[3] = (ld32le(key + 9) >> 6) & 0x3f03fff;
    p->r[4] = (ld32le(key + 12) >> 8) & 0x00fffff;
    for (int i = 0; i < 5; i++) p->h[i] = 0;
    for (int i = 0; i < 4; i++) p->pad[i] = ld32le(key + 16 + 4 * i);
    p->n = 0;
}

static void poly_block(struct poly *p, const uint8_t *m, uint32_t hibit) {
    uint32_t r0 = p->r[0], r1 = p->r[1], r2 = p->r[2], r3 = p->r[3], r4 = p->r[4];
    uint32_t s1 = r1 * 5, s2 = r2 * 5, s3 = r3 * 5, s4 = r4 * 5;
    uint32_t h0 = p->h[0], h1 = p->h[1], h2 = p->h[2], h3 = p->h[3], h4 = p->h[4];
    h0 += ld32le(m + 0) & 0x3ffffff;
    h1 += (ld32le(m + 3) >> 2) & 0x3ffffff;
    h2 += (ld32le(m + 6) >> 4) & 0x3ffffff;
    h3 += (ld32le(m + 9) >> 6) & 0x3ffffff;
    h4 += (ld32le(m + 12) >> 8) | hibit;
    uint64_t d0 = (uint64_t)h0 * r0 + (uint64_t)h1 * s4 + (uint64_t)h2 * s3 + (uint64_t)h3 * s2 + (uint64_t)h4 * s1;
    uint64_t d1 = (uint64_t)h0 * r1 + (uint64_t)h1 * r0 + (uint64_t)h2 * s4 + (uint64_t)h3 * s3 + (uint64_t)h4 * s2;
    uint64_t d2 = (uint64_t)h0 * r2 + (uint64_t)h1 * r1 + (uint64_t)h2 * r0 + (uint64_t)h3 * s4 + (uint64_t)h4 * s3;
    uint64_t d3 = (uint64_t)h0 * r3 + (uint64_t)h1 * r2 + (uint64_t)h2 * r1 + (uint64_t)h3 * r0 + (uint64_t)h4 * s4;
    uint64_t d4 = (uint64_t)h0 * r4 + (uint64_t)h1 * r3 + (uint64_t)h2 * r2 + (uint64_t)h3 * r1 + (uint64_t)h4 * r0;
    uint32_t c;
    c = (uint32_t)(d0 >> 26); h0 = (uint32_t)d0 & 0x3ffffff;
    d1 += c; c = (uint32_t)(d1 >> 26); h1 = (uint32_t)d1 & 0x3ffffff;
    d2 += c; c = (uint32_t)(d2 >> 26); h2 = (uint32_t)d2 & 0x3ffffff;
    d3 += c; c = (uint32_t)(d3 >> 26); h3 = (uint32_t)d3 & 0x3ffffff;
    d4 += c; c = (uint32_t)(d4 >> 26); h4 = (uint32_t)d4 & 0x3ffffff;
    h0 += c * 5; c = h0 >> 26; h0 &= 0x3ffffff;
    h1 += c;
    p->h[0] = h0; p->h[1] = h1; p->h[2] = h2; p->h[3] = h3; p->h[4] = h4;
}

static void poly_update(struct poly *p, const uint8_t *m, size_t len) {
    while (len) {
        size_t k = 16 - p->n; if (k > len) k = len;
        memcpy(p->buf + p->n, m, k);
        p->n += k; m += k; len -= k;
        if (p->n == 16) { poly_block(p, p->buf, 1u << 24); p->n = 0; }
    }
}

static void poly_final(struct poly *p, uint8_t tag[16]) {
    if (p->n) {
        p->buf[p->n] = 1;
        for (size_t i = p->n + 1; i < 16; i++) p->buf[i] = 0;
        poly_block(p, p->buf, 0);
    }
    uint32_t h0 = p->h[0], h1 = p->h[1], h2 = p->h[2], h3 = p->h[3], h4 = p->h[4], c;
    c = h1 >> 26; h1 &= 0x3ffffff; h2 += c;
    c = h2 >> 26; h2 &= 0x3ffffff; h3 += c;
    c = h3 >> 26; h3 &= 0x3ffffff; h4 += c;
    c = h4 >> 26; h4 &= 0x3ffffff; h0 += c * 5;
    c = h0 >> 26; h0 &= 0x3ffffff; h1 += c;
    uint32_t g0 = h0 + 5; c = g0 >> 26; g0 &= 0x3ffffff;
    uint32_t g1 = h1 + c; c = g1 >> 26; g1 &= 0x3ffffff;
    uint32_t g2 = h2 + c; c = g2 >> 26; g2 &= 0x3ffffff;
    uint32_t g3 = h3 + c; c = g3 >> 26; g3 &= 0x3ffffff;
    uint32_t g4 = h4 + c - (1u << 26);
    uint32_t mask = (g4 >> 31) - 1;            /* 0xffffffff если h >= p */
    g0 &= mask; g1 &= mask; g2 &= mask; g3 &= mask; g4 &= mask;
    mask = ~mask;
    h0 = (h0 & mask) | g0; h1 = (h1 & mask) | g1; h2 = (h2 & mask) | g2; h3 = (h3 & mask) | g3; h4 = (h4 & mask) | g4;
    uint32_t t0 = h0 | (h1 << 26);
    uint32_t t1 = (h1 >> 6) | (h2 << 20);
    uint32_t t2 = (h2 >> 12) | (h3 << 14);
    uint32_t t3 = (h3 >> 18) | (h4 << 8);
    uint64_t f;
    f = (uint64_t)t0 + p->pad[0]; st32le(tag, (uint32_t)f);
    f = (uint64_t)t1 + p->pad[1] + (f >> 32); st32le(tag + 4, (uint32_t)f);
    f = (uint64_t)t2 + p->pad[2] + (f >> 32); st32le(tag + 8, (uint32_t)f);
    f = (uint64_t)t3 + p->pad[3] + (f >> 32); st32le(tag + 12, (uint32_t)f);
}

static void poly_pad16(struct poly *p, size_t len) {
    static const uint8_t z[16] = { 0 };
    if (len % 16) poly_update(p, z, 16 - len % 16);
}

static void chapoly_tag(const uint8_t key[32], const uint8_t nonce[12], const uint8_t *aad, size_t aadlen,
                        const uint8_t *ct, size_t len, uint8_t tag[16]) {
    uint8_t blk[64], lens[16];
    chacha_block(key, 0, nonce, blk);
    struct poly p;
    poly_init(&p, blk);
    poly_update(&p, aad, aadlen); poly_pad16(&p, aadlen);
    poly_update(&p, ct, len);     poly_pad16(&p, len);
    for (int i = 0; i < 8; i++) { lens[i] = (uint8_t)((uint64_t)aadlen >> (8 * i)); lens[8 + i] = (uint8_t)((uint64_t)len >> (8 * i)); }
    poly_update(&p, lens, 16);
    poly_final(&p, tag);
}

void chacha20poly1305_seal(const uint8_t key[32], const uint8_t nonce[12], const uint8_t *aad, size_t aadlen,
                           const uint8_t *pt, size_t len, uint8_t *ct, uint8_t tag[16]) {
    chacha_xor(key, 1, nonce, pt, ct, len);
    chapoly_tag(key, nonce, aad, aadlen, ct, len, tag);
}

int chacha20poly1305_open(const uint8_t key[32], const uint8_t nonce[12], const uint8_t *aad, size_t aadlen,
                          const uint8_t *ct, size_t len, const uint8_t tag[16], uint8_t *pt) {
    uint8_t t[16];
    chapoly_tag(key, nonce, aad, aadlen, ct, len, t);
    if (ct_memcmp(t, tag, 16)) return -1;
    chacha_xor(key, 1, nonce, ct, pt, len);
    return 0;
}

/* ====================== AES-128-GCM ====================== */

static uint8_t sbox[256];
static int sbox_ready;

static void sbox_make(void) {
    uint8_t p = 1, q = 1;
    do {
        p = (uint8_t)(p ^ (uint8_t)(p << 1) ^ ((p & 0x80) ? 0x1B : 0));
        q ^= (uint8_t)(q << 1); q ^= (uint8_t)(q << 2); q ^= (uint8_t)(q << 4);
        if (q & 0x80) q ^= 0x09;
        uint8_t x = (uint8_t)(q ^ ((q << 1) | (q >> 7)) ^ ((q << 2) | (q >> 6)) ^ ((q << 3) | (q >> 5)) ^ ((q << 4) | (q >> 4)));
        sbox[p] = (uint8_t)(x ^ 0x63);
    } while (p != 1);
    sbox[0] = 0x63;
    sbox_ready = 1;
}

struct aes128 { uint8_t rk[176]; };

static void aes128_key(struct aes128 *a, const uint8_t key[16]) {
    if (!sbox_ready) sbox_make();
    memcpy(a->rk, key, 16);
    uint8_t rcon = 1;
    for (int i = 16; i < 176; i += 4) {
        uint8_t t[4];
        memcpy(t, a->rk + i - 4, 4);
        if (i % 16 == 0) {
            uint8_t k = t[0];
            t[0] = (uint8_t)(sbox[t[1]] ^ rcon); t[1] = sbox[t[2]]; t[2] = sbox[t[3]]; t[3] = sbox[k];
            rcon = (uint8_t)((rcon << 1) ^ ((rcon & 0x80) ? 0x1B : 0));
        }
        for (int j = 0; j < 4; j++) a->rk[i + j] = (uint8_t)(a->rk[i - 16 + j] ^ t[j]);
    }
}

static inline uint8_t xtime(uint8_t x) { return (uint8_t)((x << 1) ^ ((x >> 7) * 0x1B)); }

static void aes128_enc(const struct aes128 *a, const uint8_t in[16], uint8_t out[16]) {
    uint8_t s[16], t[16];
    for (int i = 0; i < 16; i++) s[i] = in[i] ^ a->rk[i];
    for (int r = 1; r <= 10; r++) {
        for (int i = 0; i < 16; i++) t[i] = sbox[s[i]];
        /* ShiftRows */
        s[0] = t[0];  s[4] = t[4];  s[8] = t[8];   s[12] = t[12];
        s[1] = t[5];  s[5] = t[9];  s[9] = t[13];  s[13] = t[1];
        s[2] = t[10]; s[6] = t[14]; s[10] = t[2];  s[14] = t[6];
        s[3] = t[15]; s[7] = t[3];  s[11] = t[7];  s[15] = t[11];
        if (r != 10) {
            for (int c = 0; c < 4; c++) {
                uint8_t *col = s + 4 * c;
                uint8_t a0 = col[0], a1 = col[1], a2 = col[2], a3 = col[3];
                uint8_t all = a0 ^ a1 ^ a2 ^ a3;
                col[0] = (uint8_t)(a0 ^ all ^ xtime(a0 ^ a1));
                col[1] = (uint8_t)(a1 ^ all ^ xtime(a1 ^ a2));
                col[2] = (uint8_t)(a2 ^ all ^ xtime(a2 ^ a3));
                col[3] = (uint8_t)(a3 ^ all ^ xtime(a3 ^ a0));
            }
        }
        for (int i = 0; i < 16; i++) s[i] ^= a->rk[16 * r + i];
    }
    memcpy(out, s, 16);
}

/* умножение в GF(2^128) для GHASH: x = x * h */
static void gf128_mul(uint64_t x[2], const uint64_t h[2]) {
    uint64_t zh = 0, zl = 0, vh = h[0], vl = h[1];
    for (int i = 0; i < 128; i++) {
        uint64_t bit = (i < 64) ? (x[0] >> (63 - i)) & 1 : (x[1] >> (127 - i)) & 1;
        uint64_t m = (uint64_t)0 - bit;
        zh ^= vh & m; zl ^= vl & m;
        uint64_t lsb = vl & 1;
        vl = (vl >> 1) | (vh << 63);
        vh = (vh >> 1) ^ (((uint64_t)0 - lsb) & 0xe100000000000000ULL);
    }
    x[0] = zh; x[1] = zl;
}

static void ghash_feed(uint64_t y[2], const uint64_t h[2], const uint8_t *d, size_t len) {
    while (len) {
        uint8_t b[16] = { 0 };
        size_t k = len > 16 ? 16 : len;
        memcpy(b, d, k);
        y[0] ^= ld64be(b); y[1] ^= ld64be(b + 8);
        gf128_mul(y, h);
        d += k; len -= k;
    }
}

static void gcm_ctr(const struct aes128 *a, const uint8_t nonce[12], const uint8_t *in, uint8_t *out, size_t len) {
    uint8_t cb[16], ks[16];
    memcpy(cb, nonce, 12);
    uint32_t ctr = 2;
    while (len) {
        st32be(cb + 12, ctr++);
        aes128_enc(a, cb, ks);
        size_t k = len > 16 ? 16 : len;
        for (size_t i = 0; i < k; i++) out[i] = in[i] ^ ks[i];
        in += k; out += k; len -= k;
    }
}

static void gcm_tag(const struct aes128 *a, const uint8_t nonce[12], const uint8_t *aad, size_t aadlen,
                    const uint8_t *ct, size_t len, uint8_t tag[16]) {
    uint8_t zero[16] = { 0 }, hb[16], j0[16], ek[16], lb[16];
    aes128_enc(a, zero, hb);
    uint64_t h[2] = { ld64be(hb), ld64be(hb + 8) }, y[2] = { 0, 0 };
    ghash_feed(y, h, aad, aadlen);
    ghash_feed(y, h, ct, len);
    st64be(lb, (uint64_t)aadlen * 8); st64be(lb + 8, (uint64_t)len * 8);
    ghash_feed(y, h, lb, 16);
    memcpy(j0, nonce, 12); st32be(j0 + 12, 1);
    aes128_enc(a, j0, ek);
    st64be(tag, y[0]); st64be(tag + 8, y[1]);
    for (int i = 0; i < 16; i++) tag[i] ^= ek[i];
}

void aes128gcm_seal(const uint8_t key[16], const uint8_t nonce[12], const uint8_t *aad, size_t aadlen,
                    const uint8_t *pt, size_t len, uint8_t *ct, uint8_t tag[16]) {
    struct aes128 a;
    aes128_key(&a, key);
    gcm_ctr(&a, nonce, pt, ct, len);
    gcm_tag(&a, nonce, aad, aadlen, ct, len, tag);
}

int aes128gcm_open(const uint8_t key[16], const uint8_t nonce[12], const uint8_t *aad, size_t aadlen,
                   const uint8_t *ct, size_t len, const uint8_t tag[16], uint8_t *pt) {
    struct aes128 a;
    uint8_t t[16];
    aes128_key(&a, key);
    gcm_tag(&a, nonce, aad, aadlen, ct, len, t);
    if (ct_memcmp(t, tag, 16)) return -1;
    gcm_ctr(&a, nonce, ct, pt, len);
    return 0;
}

/* ====================== X25519 ====================== */

typedef int64_t gf[16];
static const gf gf_121665 = { 0xDB41, 1 };

static void car25519(gf o) {
    for (int i = 0; i < 16; i++) {
        o[i] += (int64_t)1 << 16;
        int64_t c = o[i] >> 16;
        o[(i + 1) * (i < 15)] += c - 1 + 37 * (c - 1) * (i == 15);
        o[i] -= c * 65536;
    }
}

static void sel25519(gf p, gf q, int b) {
    int64_t c = ~((int64_t)b - 1);
    for (int i = 0; i < 16; i++) {
        int64_t t = c & (p[i] ^ q[i]);
        p[i] ^= t; q[i] ^= t;
    }
}

static void pack25519(uint8_t *o, const gf n) {
    gf m, t;
    for (int i = 0; i < 16; i++) t[i] = n[i];
    car25519(t); car25519(t); car25519(t);
    for (int j = 0; j < 2; j++) {
        m[0] = t[0] - 0xffed;
        for (int i = 1; i < 15; i++) {
            m[i] = t[i] - 0xffff - ((m[i - 1] >> 16) & 1);
            m[i - 1] &= 0xffff;
        }
        m[15] = t[15] - 0x7fff - ((m[14] >> 16) & 1);
        int b = (int)((m[15] >> 16) & 1);
        m[14] &= 0xffff;
        sel25519(t, m, 1 - b);
    }
    for (int i = 0; i < 16; i++) { o[2 * i] = (uint8_t)(t[i] & 0xff); o[2 * i + 1] = (uint8_t)(t[i] >> 8); }
}

static void unpack25519(gf o, const uint8_t *n) {
    for (int i = 0; i < 16; i++) o[i] = n[2 * i] + ((int64_t)n[2 * i + 1] << 8);
    o[15] &= 0x7fff;
}

static void fadd(gf o, const gf a, const gf b) { for (int i = 0; i < 16; i++) o[i] = a[i] + b[i]; }
static void fsub(gf o, const gf a, const gf b) { for (int i = 0; i < 16; i++) o[i] = a[i] - b[i]; }
static void fmul(gf o, const gf a, const gf b) {
    int64_t t[31];
    for (int i = 0; i < 31; i++) t[i] = 0;
    for (int i = 0; i < 16; i++) for (int j = 0; j < 16; j++) t[i + j] += a[i] * b[j];
    for (int i = 0; i < 15; i++) t[i] += 38 * t[i + 16];
    for (int i = 0; i < 16; i++) o[i] = t[i];
    car25519(o); car25519(o);
}
static void fsq(gf o, const gf a) { fmul(o, a, a); }

static void finv(gf o, const gf i) {
    gf c;
    for (int a = 0; a < 16; a++) c[a] = i[a];
    for (int a = 253; a >= 0; a--) {
        fsq(c, c);
        if (a != 2 && a != 4) fmul(c, c, i);
    }
    for (int a = 0; a < 16; a++) o[a] = c[a];
}

void x25519(uint8_t out[32], const uint8_t scalar[32], const uint8_t point[32]) {
    uint8_t z[32];
    gf x, a, b, c, d, e, f;
    for (int i = 0; i < 32; i++) z[i] = scalar[i];
    z[31] = (uint8_t)((scalar[31] & 127) | 64);
    z[0] &= 248;
    unpack25519(x, point);
    for (int i = 0; i < 16; i++) { b[i] = x[i]; a[i] = c[i] = d[i] = 0; }
    a[0] = d[0] = 1;
    for (int i = 254; i >= 0; i--) {
        int r = (z[i >> 3] >> (i & 7)) & 1;
        sel25519(a, b, r); sel25519(c, d, r);
        fadd(e, a, c); fsub(a, a, c); fadd(c, b, d); fsub(b, b, d);
        fsq(d, e); fsq(f, a); fmul(a, c, a); fmul(c, b, e);
        fadd(e, a, c); fsub(a, a, c); fsq(b, a); fsub(c, d, f);
        fmul(a, c, gf_121665); fadd(a, a, d); fmul(c, c, a);
        fmul(a, d, f); fmul(d, b, x); fsq(b, e);
        sel25519(a, b, r); sel25519(c, d, r);
    }
    finv(c, c);
    fmul(a, a, c);
    pack25519(out, a);
}

void x25519_base(uint8_t out[32], const uint8_t scalar[32]) {
    uint8_t base[32] = { 9 };
    x25519(out, scalar, base);
}

/* ====================== генератор случайных чисел ====================== */

static uint8_t pool[32];
static uint64_t rng_ctr;
static int rng_has_rdrand = -1;

static inline uint64_t rd_tsc(void) {
#if defined(__x86_64__)
    uint32_t lo, hi;
    __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
#else
    return 0;
#endif
}

static int rdrand64(uint64_t *v) {
#if defined(__x86_64__)
    if (rng_has_rdrand < 0) {
        uint32_t a = 1, b, c = 0, d;
        __asm__ volatile("cpuid" : "+a"(a), "=b"(b), "+c"(c), "=d"(d));
        rng_has_rdrand = (c >> 30) & 1;
    }
    if (!rng_has_rdrand) return 0;
    for (int i = 0; i < 10; i++) {
        uint64_t x; unsigned char ok;
        __asm__ volatile("rdrand %0; setc %1" : "=r"(x), "=qm"(ok) : : "cc");
        if (ok) { *v = x; return 1; }
    }
#endif
    (void)v;
    return 0;
}

void rng_add_entropy(const void *data, size_t len) {
    struct sha256 c;
    uint64_t t = rd_tsc();
    sha256_init(&c);
    sha256_update(&c, pool, 32);
    sha256_update(&c, &t, 8);
    sha256_update(&c, data, len);
    sha256_final(&c, pool);
}

void rng_bytes(void *out, size_t len) {
    uint8_t *o = out;
    while (len) {
        uint8_t blk[32], in[24];
        uint64_t hw = 0, t = rd_tsc(), ctr = ++rng_ctr;
        rdrand64(&hw);
        memcpy(in, &hw, 8); memcpy(in + 8, &t, 8); memcpy(in + 16, &ctr, 8);
        hmac_sha256(pool, 32, in, 24, blk);
        size_t k = len > 32 ? 32 : len;
        memcpy(o, blk, k);
        o += k; len -= k;
        /* продвигаем состояние, чтобы вчерашний вывод нельзя было восстановить */
        hmac_sha256(pool, 32, blk, 32, pool);
    }
}
