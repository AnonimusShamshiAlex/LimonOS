#ifndef LIMON_GDT_H
#define LIMON_GDT_H
#include <stdint.h>

/*
 * Фаза 3 плана (docs/USERSPACE_PLAN.md): дескрипторы ring3 и TSS.
 *
 * Как и elf.c/vmm.c, кодирование дескрипторов вынесено в чистые функции над
 * числами (gdt_make_desc/gdt_make_tss_desc) — без единой asm-инструкции,
 * поэтому честно протестировано на хосте (tests/gdt_host.c): там сверяется,
 * что те же формулы воспроизводят уже проверенные годами константы ядра
 * (0x00AF9A000000FFFF и т.д.) и дают для TSS корректный 16-байтный дескриптор
 * (проверено round-trip: собрали -> разобрали -> совпало с исходным base/limit).
 *
 * "Железная" часть — lgdt/ltr/перезагрузка сегментных регистров в gdt_init() —
 * написана по спецификации (Intel SDM vol.3 §3.5, §7.2.3) и, как cr3/invlpg в
 * vmm.h, в этой среде (без QEMU/KVM) нечем проверить на исполнение.
 */

#define GDT_SEL_KCODE 0x08
#define GDT_SEL_KDATA 0x10
#define GDT_SEL_UCODE 0x18        /* + RPL3 при загрузке в CS -> 0x1B */
#define GDT_SEL_UDATA 0x20        /* + RPL3 при загрузке в SS -> 0x23 */
#define GDT_SEL_TSS   0x28        /* system-дескриптор, занимает 16 байт (0x28 и 0x30) */

#define GDT_SEL_UCODE_RPL3 (GDT_SEL_UCODE | 3)
#define GDT_SEL_UDATA_RPL3 (GDT_SEL_UDATA | 3)

/* TSS в long mode (Intel SDM vol.3 §7.7): нам из всей структуры нужен только
 * rsp0 — куда CPU переключает стек при прерывании/исключении, пришедшем из
 * ring3 (иначе процессор использовал бы указатель стека пользователя, а он
 * ему не доверяет). iomap_base = sizeof(tss) означает "карты портов нет". */
struct __attribute__((packed)) tss64 {
    uint32_t reserved0;
    uint64_t rsp0, rsp1, rsp2;
    uint64_t reserved1;
    uint64_t ist1, ist2, ist3, ist4, ist5, ist6, ist7;
    uint64_t reserved2;
    uint16_t reserved3;
    uint16_t iomap_base;
};

/* Собирает одно 64-битное слово обычного (8-байтного) дескриптора сегмента
 * GDT по формуле из Intel SDM vol.3 §3.4.5. Чистая функция — тестируется на
 * хосте без ассемблера. */
uint64_t gdt_make_desc(uint32_t base, uint32_t limit, uint8_t access, uint8_t flags);

/* Собирает 16-байтный system-дескриптор (TSS в long mode, §7.2.3): две
 * машинные "ячейки" GDT. out[0] — младшие 8 байт, out[1] — старшие (верхние
 * 32 бита базового адреса + зарезервированные нули). */
void gdt_make_tss_desc(uint64_t base, uint32_t limit, uint64_t out[2]);

void gdt_init(void);                       /* строит таблицу (null, kcode, kdata, ucode, udata, tss),
                                               lgdt, перезагружает сегментные регистры, ltr */
void gdt_set_kernel_stack(uint64_t rsp0);  /* обновить TSS.rsp0 перед входом в ring3 */
#endif
