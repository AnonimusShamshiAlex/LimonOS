#include "ring3.h"
#include "vmm.h"
#include "gdt.h"
#include "mem.h"
#include "console.h"

#define USER_CODE_VA 0x0000000000400000ULL
#define USER_STACK_VA 0x0000000000500000ULL
#define USER_STACK_TOP (USER_STACK_VA + VMM_PAGE)

static uint64_t ring3_alloc_page(void *ctx) { (void)ctx; return pmm_alloc(1); }
static void *ring3_p2v(uint64_t phys, void *ctx) { (void)ctx; return phys_to_virt(phys); }

extern void ring3_enter(uint64_t entry, uint64_t user_rsp, uint64_t user_cs, uint64_t user_ss);   /* ring3_asm.S */
extern uint64_t ring3_kernel_stack_top(void);                                                      /* ring3_asm.S: текущий RSP, выровненный вниз до страницы */

void ring3_self_test(void) {
    kprintf("--- Самопроверка ring3 (Фаза 3) ---\n");
    kprintf("Пишу по спецификации, не проверял на железе/эмуляторе (нет KVM/QEMU в этой среде).\n");
    kprintf("Ожидаю экран \"общая защита (GPF)\" с CS=0x1B — это и будет доказательством успеха.\n");
    kprintf("Если вместо этого компьютер мгновенно перезагрузится без сообщений — значит, где-то\n");
    kprintf("ошибка в GDT/TSS/таблицах страниц; напиши, что увидел, это и есть нужные данные.\n\n");

    uint64_t code_phys = pmm_alloc(1), stack_phys = pmm_alloc(1), pml4_phys = pmm_alloc(1);
    if (!code_phys || !stack_phys || !pml4_phys) { kprintf("Не хватило физической памяти — отменено.\n"); return; }

    uint8_t *code = phys_to_virt(code_phys);
    code[0] = 0xF4;                 /* hlt */
    code[1] = 0xEB; code[2] = 0xFD; /* jmp $-1 — на случай, если hlt почему-то не вызвал #GP, крутимся на месте, а не улетаем в случайный код */

    struct vmm_space kernel_space = { vmm_read_cr3() };
    struct vmm_space proc_space = { pml4_phys };
    vmm_share_upper_half(&proc_space, &kernel_space, ring3_p2v, NULL);

    if (vmm_map(&proc_space, USER_CODE_VA, code_phys, PTE_USER, ring3_alloc_page, ring3_p2v, NULL) != VMM_OK ||
        vmm_map(&proc_space, USER_STACK_VA, stack_phys, PTE_USER | PTE_WRITE, ring3_alloc_page, ring3_p2v, NULL) != VMM_OK) {
        kprintf("Не удалось отобразить страницы пользователя — отменено.\n");
        return;
    }

    gdt_set_kernel_stack(ring3_kernel_stack_top());
    vmm_load_cr3(proc_space.pml4_phys);
    ring3_enter(USER_CODE_VA, USER_STACK_TOP - 16, GDT_SEL_UCODE_RPL3, GDT_SEL_UDATA_RPL3);
    /* сюда управление не возвращается: ring3_enter делает iretq и не идёт обратно по call stack */
}
