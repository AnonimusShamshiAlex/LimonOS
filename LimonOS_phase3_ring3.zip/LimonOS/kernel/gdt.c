#include "gdt.h"
#include "arch.h"
#include "kstring.h"

uint64_t gdt_make_desc(uint32_t base, uint32_t limit, uint8_t access, uint8_t flags) {
    uint64_t d = 0;
    d |= (uint64_t)(limit & 0xFFFFu);
    d |= (uint64_t)(base & 0xFFFFFFu) << 16;
    d |= (uint64_t)access << 40;
    d |= (uint64_t)((limit >> 16) & 0xFu) << 48;
    d |= (uint64_t)(flags & 0xFu) << 52;
    d |= (uint64_t)((base >> 24) & 0xFFu) << 56;
    return d;
}

void gdt_make_tss_desc(uint64_t base, uint32_t limit, uint64_t out[2]) {
    uint8_t access = 0x89;   /* P=1 DPL=00 S=0 Type=1001 (свободный 64-битный TSS) */
    uint64_t low = 0;
    low |= (uint64_t)(limit & 0xFFFFu);
    low |= (uint64_t)(base & 0xFFFFFFu) << 16;
    low |= (uint64_t)access << 40;
    low |= (uint64_t)((limit >> 16) & 0xFu) << 48;
    low |= (uint64_t)((base >> 24) & 0xFFu) << 56;
    out[0] = low;
    out[1] = (base >> 32) & 0xFFFFFFFFu;   /* старшие 32 бита базы; верхние 32 бита этого слова — резерв, должны быть 0 */
}

#ifndef HOST_TEST
static uint64_t gdt[7];
static struct tss64 the_tss;
static uint8_t ist1_stack[8192] __attribute__((aligned(16)));   /* аварийный стек для двойной ошибки/NMI (IST1) */

struct __attribute__((packed)) gdtr { uint16_t limit; uint64_t base; };

void gdt_set_kernel_stack(uint64_t rsp0) { the_tss.rsp0 = rsp0; }

void gdt_init(void) {
    memset(&the_tss, 0, sizeof the_tss);
    the_tss.iomap_base = sizeof the_tss;                 /* карты портов ввода-вывода нет: iomap_base за концом TSS */
    the_tss.ist1 = (uint64_t)(ist1_stack + sizeof ist1_stack);

    gdt[0] = 0;
    gdt[1] = gdt_make_desc(0, 0xFFFFF, 0x9A, 0xA);        /* 0x08 код ядра (ring0), 64-бит */
    gdt[2] = gdt_make_desc(0, 0xFFFFF, 0x92, 0xC);        /* 0x10 данные ядра */
    gdt[3] = gdt_make_desc(0, 0xFFFFF, 0xFA, 0xA);        /* 0x18 код пользователя (ring3), 64-бит */
    gdt[4] = gdt_make_desc(0, 0xFFFFF, 0xF2, 0xC);        /* 0x20 данные пользователя */
    uint64_t tss_desc[2];
    gdt_make_tss_desc((uint64_t)&the_tss, sizeof the_tss - 1, tss_desc);
    gdt[5] = tss_desc[0];                                  /* 0x28 TSS, младшие 8 байт */
    gdt[6] = tss_desc[1];                                  /* 0x30 TSS, старшие 8 байт (занимает второй слот) */

    struct gdtr g = { sizeof(gdt) - 1, (uint64_t)gdt };
    __asm__ volatile (
        "lgdt %0\n"
        "pushq $0x08\n"
        "leaq 1f(%%rip), %%rax\n"
        "pushq %%rax\n"
        "lretq\n"
        "1:\n"
        "movw $0x10, %%ax\n"
        "movw %%ax, %%ds\n"
        "movw %%ax, %%es\n"
        "movw %%ax, %%ss\n"
        "movw %%ax, %%fs\n"
        "movw %%ax, %%gs\n"
        "movw $0x28, %%ax\n"
        "ltr %%ax\n"
        :: "m"(g) : "rax", "memory");
}
#endif
