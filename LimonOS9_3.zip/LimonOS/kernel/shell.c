/* Терминал LimonOS: ввод строки, история и уникальные "лимонные" команды. */
#include "shell.h"
#include "format.h"
#include "kstring.h"
#include "sysinfo.h"
#include "timer.h"
#include "rtc.h"
#include "desktop.h"
#include "keyboard.h"
#include "gfx.h"
#include "net.h"
#include "pci.h"
#include "mem.h"
#include "http.h"
#include "tls.h"
#include "crypto.h"
#include "store.h"
#include "ai.h"

#define PROMPT      "лимон> "
#define PROMPT_COLS 7

/* ---------- редактирование строки ---------- */

/* Строка ввода может быть длиннее экрана (ключи API, адреса) — прокручиваем её по горизонтали,
   так что курсор всегда виден. Когда что-то скрыто слева или справа, показываем « или » на краю. */
/* Та же задача, что у любой командной строки: строка длиннее экрана, курсор должен быть виден всегда.
   Без прокрутки помещается vis_full-1 символов (последний столбец бережём под курсор сразу за текстом,
   как и раньше). Если не влезает — включаем прокрутку и ВСЕГДА резервируем по столбцу под « и » сразу
   с обеих сторон, даже если нужен только один — так проще и курсор гарантированно не уедет за край. */
static void repaint(struct shell *s) {
    struct term *t = s->t;
    int row = t->cy, col = 0;
    int vis_full = TERM_COLS - PROMPT_COLS;
    int lo, hi, more_left, more_right;
    if (s->len <= vis_full - 1) {
        s->scroll = 0; lo = 0; hi = s->len; more_left = 0; more_right = 0;
    } else {
        int vis = vis_full - 2;
        if (s->pos < s->scroll) s->scroll = s->pos;
        if (s->pos - s->scroll >= vis) s->scroll = s->pos - vis + 1;
        if (s->scroll < 0) s->scroll = 0;
        if (s->scroll > s->len - vis) s->scroll = s->len - vis;
        lo = s->scroll; hi = lo + vis; if (hi > s->len) hi = s->len;
        more_left = lo > 0; more_right = hi < s->len;
    }
    for (int c = 0; c < TERM_COLS; c++) t->cell[row][c] = (struct tcell){ ' ', TC_DEFAULT };
    const char *p = PROMPT;
    while (*p) t->cell[row][col++] = (struct tcell){ utf8_next(&p), TC_ACCENT };
    if (more_left) t->cell[row][col++] = (struct tcell){ 0xAB, TC_GRAY };                         /* « */
    for (int i = lo; i < hi; i++) t->cell[row][col++] = (struct tcell){ s->line[i], TC_DEFAULT };
    if (more_right) t->cell[row][col++] = (struct tcell){ 0xBB, TC_GRAY };                        /* » */
    t->cx = PROMPT_COLS + (more_left ? 1 : 0) + (s->pos - lo);
}

static void show_prompt(struct shell *s) {
    if (s->t->cx != 0) term_putc(s->t, '\n');
    s->len = s->pos = s->scroll = 0;
    s->hist_idx = -1;
    term_set_fg(s->t, TC_DEFAULT);
    repaint(s);
}

static void load_line(struct shell *s, const char *utf8) {
    s->len = 0;
    while (*utf8 && s->len < SH_LINE_MAX) s->line[s->len++] = utf8_next(&utf8);
    s->pos = s->len;
    s->scroll = 0;
}

static void add_history(struct shell *s, const char *line) {
    if (s->hist_count > 0 && strcmp(s->hist[s->hist_count - 1], line) == 0) return;
    if (s->hist_count == SH_HIST) {
        for (int i = 1; i < SH_HIST; i++) memcpy(s->hist[i - 1], s->hist[i], SH_HIST_BYTES);
        s->hist_count--;
    }
    int n = 0;
    while (line[n] && n < SH_HIST_BYTES - 1) { s->hist[s->hist_count][n] = line[n]; n++; }
    s->hist[s->hist_count][n] = 0;
    s->hist_count++;
}

/* ---------- вспомогательное ---------- */

static void uptime_str(char *buf, size_t n) {
    uint64_t sec = timer_ticks / TIMER_HZ;
    ksnprintf(buf, n, "%02d:%02d:%02d", (int)(sec / 3600), (int)(sec / 60 % 60), (int)(sec % 60));
}

static unsigned long long mib(uint64_t bytes) { return (unsigned long long)(bytes >> 20); }

/* ---------- команды ---------- */

struct cmd {
    const char *name, *alt, *desc;
    void (*fn)(struct shell *, int, char **);
};

static void cmd_zest(struct shell *s, int argc, char **argv);

static void cmd_squeeze(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    term_clear(s->t);
}

static void cmd_peel(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    struct term *t = s->t;
    char up[16];
    uptime_str(up, sizeof up);

    char info[12][96];
    int n = 0;
    ksnprintf(info[n++], 96, "limon@os");
    ksnprintf(info[n++], 96, "--------");
    ksnprintf(info[n++], 96, "ОС:        LimonOS %s", LIMON_VERSION);
    ksnprintf(info[n++], 96, "Экран:     %ux%u", g_sys.fb_w, g_sys.fb_h);
    {
        const char *src = g_sys.cpu.brand[0] ? g_sys.cpu.brand : g_sys.cpu.vendor;
        char cpu[37];
        int k = 0;
        while (src[k] && k < 36) { cpu[k] = src[k]; k++; }
        cpu[k] = 0;
        ksnprintf(info[n++], 96, "Процессор: %s", cpu);
    }
    if (g_sys.mem_valid) ksnprintf(info[n++], 96, "Память:    %llu МиБ свободно", mib(g_sys.mem_usable));
    else                 ksnprintf(info[n++], 96, "Память:    нет данных");
    ksnprintf(info[n++], 96, "Работаю:   %s", up);
    ksnprintf(info[n++], 96, "Среда:     %s", cpuinfo_env_name(&g_sys.cpu));
    {
        const struct netinfo *ni = net_info();
        char ipb[16];
        if (ni->configured) { net_ip_str(ni->ip, ipb); ksnprintf(info[n++], 96, "Сеть:      %s", ipb); }
        else ksnprintf(info[n++], 96, "Сеть:      %s", ni->present ? "нет адреса" : "нет карты");
    }
    ksnprintf(info[n++], 96, "Тема:      %s", desktop_theme_name());
    ksnprintf(info[n++], 96, "Раскладка: %s", kbd_layout() == LAYOUT_RU ? "RU" : "EN");

    /* лимон из полублоков: сетка 20x14 "подпикселей" */
    for (int row = 0; row < 8; row++) {
        char art[28 * 3 + 1];
        int pos = 0;
        for (int c = 0; c < 28; c++) {
            int dx = 2 * c - 27;
            int top = 0, bot = 0;
            for (int h = 0; h < 2; h++) {
                int y = row * 2 + h;
                int dy = 2 * y - 15;
                int inside = (dx * dx * 225 + dy * dy * 729) <= 729 * 225;
                if (h == 0) top = inside; else bot = inside;
            }
            const char *ch = (top && bot) ? "█" : top ? "▀" : bot ? "▄" : " ";
            for (int k = 0; ch[k]; k++) art[pos++] = ch[k];
        }
        art[pos] = 0;
        term_set_fg(t, TC_ACCENT);
        term_printf(t, " %s  ", art);
        term_set_fg(t, row == 0 ? TC_ACCENT : TC_DEFAULT);
        if (row < n) term_printf(t, "%s", info[row]);
        term_putc(t, '\n');
    }
    term_set_fg(t, TC_DEFAULT);
    for (int k = 8; k < n; k++) term_printf(t, " %-28s  %s\n", "", info[k]);
}

static void bar(struct term *t, uint64_t part, uint64_t total, int width) {
    int filled = total ? (int)((part * (uint64_t)width) / total) : 0;
    term_set_fg(t, TC_ACCENT);
    for (int i = 0; i < width; i++) term_write(t, i < filled ? "▄" : "_");
    term_set_fg(t, TC_DEFAULT);
}

static void cmd_juice(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    struct term *t = s->t;
    if (!g_sys.mem_valid) {
        term_set_fg(t, TC_RED);
        term_printf(t, "Карта памяти недоступна (загрузчик её не передал).\n");
        term_set_fg(t, TC_DEFAULT);
        return;
    }
    uint64_t total = g_sys.mem_usable + g_sys.mem_reclaim + g_sys.mem_reserved;
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "Сколько сока осталось\n");
    term_set_fg(t, TC_DEFAULT);
    term_printf(t, "  Свободно:        %6llu МиБ  ", mib(g_sys.mem_usable));
    bar(t, g_sys.mem_usable, total, 30); term_putc(t, '\n');
    term_printf(t, "  Освобождаемая:   %6llu МиБ  ", mib(g_sys.mem_reclaim));
    bar(t, g_sys.mem_reclaim, total, 30); term_putc(t, '\n');
    term_printf(t, "  Занято системой: %6llu МиБ  ", mib(g_sys.mem_reserved));
    bar(t, g_sys.mem_reserved, total, 30); term_putc(t, '\n');
    term_printf(t, "  Всего по карте:  %6llu МиБ\n", mib(total));
}

static void cmd_engine(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    struct term *t = s->t;
    const struct cpu_info *c = &g_sys.cpu;
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "Мотор (процессор)\n");
    term_set_fg(t, TC_DEFAULT);
    term_printf(t, "  Производитель: %s\n", c->vendor);
    term_printf(t, "  Модель:        %s\n", c->brand[0] ? c->brand : "(не сообщает)");
    term_printf(t, "  Семейство %u, модель %u, ревизия %u\n", c->family, c->model, c->stepping);
    term_printf(t, "  Логических ядер: %u\n", c->logical);
    term_printf(t, "  Возможности:  ");
    if (c->feat_edx & (1u << 26)) term_printf(t, "SSE2 ");
    if (c->feat_ecx & (1u << 0))  term_printf(t, "SSE3 ");
    if (c->feat_ecx & (1u << 19)) term_printf(t, "SSE4.1 ");
    if (c->feat_ecx & (1u << 20)) term_printf(t, "SSE4.2 ");
    if (c->feat_ecx & (1u << 25)) term_printf(t, "AES ");
    if (c->feat_ecx & (1u << 28)) term_printf(t, "AVX ");
    if (c->feat7_ebx & (1u << 5)) term_printf(t, "AVX2 ");
    term_putc(t, '\n');
    term_printf(t, "  Среда: %s\n", cpuinfo_env_name(c));
}

static void cmd_sundial(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    struct rtc_time r;
    rtc_read(&r);
    term_printf(s->t, "Солнечные часы: %02d.%02d.%04d, %02d:%02d:%02d (часы BIOS)\n",
                r.day, r.month, r.year, r.hour, r.min, r.sec);
}

static void cmd_pulse(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    char up[16];
    uptime_str(up, sizeof up);
    term_printf(s->t, "Пульс стабильный. Работаю уже %s (%llu тиков, %d Гц)\n",
                up, (unsigned long long)timer_ticks, TIMER_HZ);
}

static void cmd_say(struct shell *s, int argc, char **argv) {
    for (int i = 1; i < argc; i++) term_printf(s->t, "%s%s", i > 1 ? " " : "", argv[i]);
    term_putc(s->t, '\n');
}

/* калькулятор: рекурсивный разбор выражения */
struct calc { const char *p; int err; };

static void skip_sp(struct calc *c) { while (*c->p == ' ') c->p++; }
static long long c_expr(struct calc *c);

static long long c_atom(struct calc *c) {
    skip_sp(c);
    if (*c->p == '(') {
        c->p++;
        long long v = c_expr(c);
        skip_sp(c);
        if (*c->p == ')') c->p++; else c->err = 1;
        return v;
    }
    if (*c->p == '-') { c->p++; return -c_atom(c); }
    if (*c->p == '+') { c->p++; return c_atom(c); }
    long long v = 0;
    if (c->p[0] == '0' && (c->p[1] == 'x' || c->p[1] == 'X')) {
        c->p += 2;
        int any = 0;
        for (;; c->p++) {
            int d;
            if (*c->p >= '0' && *c->p <= '9') d = *c->p - '0';
            else if (*c->p >= 'a' && *c->p <= 'f') d = *c->p - 'a' + 10;
            else if (*c->p >= 'A' && *c->p <= 'F') d = *c->p - 'A' + 10;
            else break;
            v = v * 16 + d; any = 1;
        }
        if (!any) c->err = 1;
        return v;
    }
    if (*c->p < '0' || *c->p > '9') { c->err = 1; return 0; }
    while (*c->p >= '0' && *c->p <= '9') v = v * 10 + (*c->p++ - '0');
    return v;
}

static long long c_term(struct calc *c) {
    long long v = c_atom(c);
    for (;;) {
        skip_sp(c);
        char op = *c->p;
        if (op != '*' && op != '/' && op != '%') return v;
        c->p++;
        long long r = c_atom(c);
        if (c->err) return 0;
        if (op == '*') v *= r;
        else if (r == 0) { c->err = 2; return 0; }
        else if (r == -1) v = op == '/' ? -v : 0;
        else v = op == '/' ? v / r : v % r;
    }
}

static long long c_expr(struct calc *c) {
    long long v = c_term(c);
    for (;;) {
        skip_sp(c);
        char op = *c->p;
        if (op != '+' && op != '-') return v;
        c->p++;
        long long r = c_term(c);
        v = op == '+' ? v + r : v - r;
    }
}

static void cmd_abacus(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    char expr[SH_HIST_BYTES];
    int n = 0;
    for (int i = 1; i < argc; i++) {
        if (i > 1 && n < (int)sizeof expr - 1) expr[n++] = ' ';
        for (const char *p = argv[i]; *p && n < (int)sizeof expr - 1; p++) expr[n++] = *p;
    }
    expr[n] = 0;
    if (n == 0) { term_printf(t, "Пример: abacus 2+3*(4-1)\n"); return; }
    struct calc c = { expr, 0 };
    long long v = c_expr(&c);
    skip_sp(&c);
    if (*c.p) c.err = c.err ? c.err : 1;
    if (c.err) {
        term_set_fg(t, TC_RED);
        term_printf(t, c.err == 2 ? "На ноль делить нельзя, даже лимоны этого не позволяют.\n"
                                  : "Не понял выражение. Пример: abacus 2+3*(4-1)\n");
        term_set_fg(t, TC_DEFAULT);
        return;
    }
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "= %lld", v);
    term_set_fg(t, TC_GRAY);
    term_printf(t, "   (0x%llX)\n", (unsigned long long)v);
    term_set_fg(t, TC_DEFAULT);
}

static void cmd_palette(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    struct term *t = s->t;
    term_printf(t, "Темы оформления:\n");
    for (int i = 0; i < desktop_theme_count(); i++) {
        term_set_fg(t, desktop_theme_accent(i));
        term_printf(t, "  ██████  ");
        term_set_fg(t, TC_DEFAULT);
        term_printf(t, "%s%s\n", desktop_theme_name_at(i), i == desktop_theme_index() ? "   ← сейчас" : "");
    }
    static const uint32_t rainbow[] = { 0xFF6B6B, 0xFFA94D, 0xF4D91A, 0x7BD88F, 0x4DD0E1, 0x6CB6FF, 0xB48EF0, 0xF06EAA };
    term_printf(t, "\nЦвета терминала:\n  ");
    for (unsigned i = 0; i < sizeof rainbow / sizeof rainbow[0]; i++) {
        term_set_fg(t, rainbow[i]);
        term_printf(t, "████ ");
    }
    term_set_fg(t, TC_DEFAULT);
    term_printf(t, "\nСмена темы: tint <название>\n");
}

static void cmd_tint(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) {
        term_printf(t, "Темы:");
        for (int i = 0; i < desktop_theme_count(); i++) term_printf(t, " %s", desktop_theme_name_at(i));
        term_printf(t, "\nПример: tint lime\n");
        return;
    }
    int idx = desktop_theme_find(argv[1]);
    if (idx < 0) {
        term_set_fg(t, TC_RED);
        term_printf(t, "Нет такой темы: %s. Список: tint\n", argv[1]);
        term_set_fg(t, TC_DEFAULT);
        return;
    }
    desktop_set_theme(idx);
    term_printf(t, "Тема сменена на ");
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "%s\n", desktop_theme_name());
    term_set_fg(t, TC_DEFAULT);
}

static void cmd_lang(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc >= 2) {
        if (strcmp(argv[1], "ru") == 0) kbd_set_layout(LAYOUT_RU);
        else if (strcmp(argv[1], "en") == 0) kbd_set_layout(LAYOUT_EN);
        else { term_printf(t, "Используй: lang ru  или  lang en\n"); return; }
    }
    term_printf(t, "Раскладка: %s (переключение: F2)\n", kbd_layout() == LAYOUT_RU ? "русская" : "английская");
}

static void cmd_twin(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    if (desktop_open_terminal() < 0) {
        term_set_fg(s->t, TC_RED);
        term_printf(s->t, "Слишком много терминалов (максимум 4).\n");
        term_set_fg(s->t, TC_DEFAULT);
    }
}

static const char *const omens[] = {
    "Если жизнь дала тебе лимон, сделай из него операционную систему.",
    "Кислое сегодня, сладкое завтра. Но компилятор всегда кислый.",
    "Хороший код как лимон: сначала кисло, потом освежает.",
    "Ядро не паникует. Ядро размышляет.",
    "Один бит в день и ОС готова.",
    "Не бойся segfault: лимонад тоже начинается с выжимки.",
    "Сегодня ты напишешь драйвер, и он заработает с первого раза. (Нет.)",
    "Лучший отладчик это стакан чая с лимоном.",
};

static void cmd_omen(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    static uint32_t rng = 12345;
    rng = rng * 1664525u + 1013904223u + (uint32_t)timer_ticks;
    unsigned n = sizeof omens / sizeof omens[0];
    term_set_fg(s->t, TC_ACCENT);
    term_printf(s->t, "Знамение: ");
    term_set_fg(s->t, TC_DEFAULT);
    term_printf(s->t, "%s\n", omens[(rng >> 16) % n]);
}

static void cmd_pci(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    struct term *t = s->t;
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "Шина PCI: найдено устройств %d\n", pci_count());
    term_set_fg(t, TC_DEFAULT);
    for (int i = 0; i < pci_count(); i++) {
        const struct pci_dev *d = pci_get(i);
        term_set_fg(t, TC_GRAY);
        term_printf(t, "  %02x:%02x.%d %04x:%04x ", d->bus, d->dev, d->fn, d->vendor, d->device);
        term_set_fg(t, TC_DEFAULT);
        term_printf(t, "%s\n", pci_device_name(d));
    }
}

static void print_ip(struct term *t, const char *label, uint32_t ip) {
    char b[16];
    net_ip_str(ip, b);
    term_printf(t, "  %-9s %s\n", label, ip ? b : "—");
}

static void cmd_vine(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc >= 2 && strcmp(argv[1], "dhcp") == 0) {
        term_printf(t, "Прошу адрес у сети (DHCP)...\n");
        desktop_refresh();
        if (net_dhcp() != 0) {
            term_set_fg(t, TC_RED);
            term_printf(t, "Адрес не получен. Проверь, что сеть подключена (в VirtualBox: NAT).\n");
            term_set_fg(t, TC_DEFAULT);
            return;
        }
    }
    const struct netinfo *ni = net_info();
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "Лоза (сеть)\n");
    term_set_fg(t, TC_DEFAULT);
    if (!ni->present) {
        term_printf(t, "  Сетевая карта не найдена (поддерживается Intel e1000).\n");
        return;
    }
    term_printf(t, "  Карта:    %s, канал %s\n", ni->nic, ni->link ? "есть" : "нет");
    term_printf(t, "  MAC:      %02x:%02x:%02x:%02x:%02x:%02x\n", ni->mac[0], ni->mac[1], ni->mac[2], ni->mac[3], ni->mac[4], ni->mac[5]);
    print_ip(t, "Адрес:", ni->ip);
    print_ip(t, "Маска:", ni->mask);
    print_ip(t, "Шлюз:", ni->gw);
    print_ip(t, "DNS:", ni->dns);
    if (!ni->configured) term_printf(t, "  Получить адрес: vine dhcp\n");
}

static void cmd_sonar(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: sonar 8.8.8.8  или  sonar example.com\n"); return; }
    if (!net_info()->configured) {
        term_set_fg(t, TC_RED);
        term_printf(t, "Нет сети. Набери: vine dhcp\n");
        term_set_fg(t, TC_DEFAULT);
        return;
    }
    uint32_t ip;
    if (net_resolve(argv[1], &ip) != 0) {
        term_set_fg(t, TC_RED);
        term_printf(t, "Не удалось найти адрес «%s»\n", argv[1]);
        term_set_fg(t, TC_DEFAULT);
        return;
    }
    char b[16];
    net_ip_str(ip, b);
    term_printf(t, "Посылаю сигнал на %s (%s)\n", argv[1], b);
    int ok = 0, total = 4, sum = 0;
    for (int i = 0; i < total; i++) {
        desktop_refresh();
        int rtt = 0;
        if (net_ping(ip, 2000, &rtt) == 0) {
            ok++; sum += rtt;
            term_set_fg(t, TC_GREEN);
            if (rtt < 10) term_printf(t, "  ответ от %s: быстрее 10 мс\n", b);
            else term_printf(t, "  ответ от %s: %d мс\n", b, rtt);
        } else {
            term_set_fg(t, TC_RED);
            term_printf(t, "  нет ответа\n");
        }
        term_set_fg(t, TC_DEFAULT);
    }
    term_printf(t, "Получено %d из %d", ok, total);
    if (ok) term_printf(t, ", среднее %d мс", sum / ok);
    term_putc(t, '\n');
}

static void cmd_lookup(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: lookup example.com\n"); return; }
    if (!net_info()->configured) {
        term_set_fg(t, TC_RED);
        term_printf(t, "Нет сети. Набери: vine dhcp\n");
        term_set_fg(t, TC_DEFAULT);
        return;
    }
    uint32_t ip;
    int r = net_resolve(argv[1], &ip);
    if (r != 0) {
        term_set_fg(t, TC_RED);
        term_printf(t, r == -3 ? "Такого имени нет: %s\n" : "DNS не ответил для %s\n", argv[1]);
        term_set_fg(t, TC_DEFAULT);
        return;
    }
    char b[16];
    net_ip_str(ip, b);
    term_printf(t, "%s = ", argv[1]);
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "%s\n", b);
    term_set_fg(t, TC_DEFAULT);
}

static void need_net_msg(struct term *t) {
    term_set_fg(t, TC_RED);
    term_printf(t, "Нет сети. Набери: vine dhcp\n");
    term_set_fg(t, TC_DEFAULT);
}

static void cmd_citrus(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: citrus example.com  или  citrus https://example.com/страница\n"); return; }
    if (!net_info()->configured) { need_net_msg(t); return; }
    term_printf(t, "Открываю %s ...\n", argv[1]);
    if (desktop_open_browser(argv[1]) < 0) {
        term_set_fg(t, TC_RED);
        term_printf(t, "Слишком много окон браузера (максимум %d).\n", DESKTOP_MAX_BROWSERS);
        term_set_fg(t, TC_DEFAULT);
    }
}

/* ---------- загрузка и отправка файлов ---------- */

struct dl_ctx { struct term *t; size_t next_report; };

static void dl_progress(size_t got, size_t total, void *p) {
    struct dl_ctx *c = p;
    if (got < c->next_report) return;
    c->next_report = got + 256 * 1024;
    if (total) term_printf(c->t, "  %u из %u КиБ\n", (unsigned)(got / 1024), (unsigned)(total / 1024));
    else       term_printf(c->t, "  %u КиБ\n", (unsigned)(got / 1024));
    desktop_refresh();
}

static void print_hex(struct term *t, const uint8_t *d, size_t n) { for (size_t i = 0; i < n; i++) term_printf(t, "%02x", d[i]); }

static void show_tls_summary(struct term *t, const struct http_resp *r) {
    if (!r->https) { term_set_fg(t, TC_ORANGE); term_printf(t, "  соединение: http, без шифрования\n"); term_set_fg(t, TC_DEFAULT); return; }
    term_set_fg(t, TC_GREEN);
    term_printf(t, "  соединение: https, %s\n", r->cipher);
    term_set_fg(t, TC_ORANGE);
    term_printf(t, "  подлинность сервера НЕ проверена (цепочка сертификатов — следующий этап)\n");
    term_set_fg(t, TC_GRAY);
    if (r->have_cert) { term_printf(t, "  отпечаток сертификата SHA-256:\n  "); print_hex(t, r->cert_sha256, 32); term_putc(t, '\n'); }
    term_set_fg(t, TC_DEFAULT);
}

static const char *base_name(const char *url) {
    const char *p = url, *last = url;
    if (strncmp(p, "https://", 8) == 0) p += 8; else if (strncmp(p, "http://", 7) == 0) p += 7;
    while (*p && *p != '?' && *p != '#') { if (*p == '/') last = p + 1; p++; }
    return last;
}

static void cmd_grab(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: grab https://example.com/file.zip [имя]\n"); return; }
    if (!net_info()->configured) { need_net_msg(t); return; }
    char name[48];
    if (argc >= 3) ksnprintf(name, sizeof name, "%.47s", argv[2]);
    else {
        const char *bn = base_name(argv[1]);
        char tmp[48]; int n = 0;
        while (*bn && *bn != '?' && *bn != '#' && n < 47) tmp[n++] = *bn++;
        tmp[n] = 0;
        ksnprintf(name, sizeof name, "%s", n ? tmp : "index.html");
    }
    term_printf(t, "Скачиваю %s ...\n", argv[1]);
    desktop_refresh();
    struct http_opts o; memset(&o, 0, sizeof o);
    o.max_bytes = 24u << 20;
    struct dl_ctx ctx = { t, 256 * 1024 };
    o.progress = dl_progress; o.pctx = &ctx;
    struct http_resp r;
    uint64_t t0 = timer_ticks;
    int rc = http_fetch(argv[1], &o, &r);
    uint64_t ms = (timer_ticks - t0) * 1000 / TIMER_HZ; if (!ms) ms = 1;
    if (rc != HTTP_OK) {
        term_set_fg(t, TC_RED);
        if (rc == HTTP_E_TLS) term_printf(t, "Не вышло: TLS — %s\n", tls_strerror(r.tls_err));
        else term_printf(t, "Не вышло: %s\n", http_strerror(rc));
        term_set_fg(t, TC_DEFAULT);
        http_free(&r);
        return;
    }
    show_tls_summary(t, &r);
    if (r.status < 200 || r.status > 299) {
        term_set_fg(t, TC_RED);
        term_printf(t, "Сервер ответил кодом %d — файл не сохранён.\n", r.status);
        term_set_fg(t, TC_DEFAULT);
        http_free(&r);
        return;
    }
    size_t len = r.len;
    uint8_t *data = r.data; r.data = NULL;
    uint8_t h[32]; sha256(data, len, h);
    if (store_put(name, data, len) != 0) {
        term_set_fg(t, TC_RED); term_printf(t, "Хранилище заполнено (files, drop <имя>).\n"); term_set_fg(t, TC_DEFAULT);
        kfree(data);
        return;
    }
    term_set_fg(t, TC_GREEN);
    term_printf(t, "Сохранено: %s, %u байт за %u мс (%u КиБ/с)\n", name, (unsigned)len, (unsigned)ms, (unsigned)(len * 1000 / ms / 1024));
    term_set_fg(t, TC_GRAY);
    term_printf(t, "  sha256: "); print_hex(t, h, 32); term_putc(t, '\n');
    term_set_fg(t, TC_DEFAULT);
}

static void cmd_files(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    struct term *t = s->t;
    int n = 0;
    for (int i = 0; ; i++) {
        const struct store_file *f = store_at(i);
        if (!f) break;
        term_printf(t, "  %-30s %8u байт\n", f->name, (unsigned)f->len);
        n++;
    }
    if (!n) term_printf(t, "  Пусто. Скачать файл: grab <адрес>\n");
    else term_printf(t, "Итого %d файл(ов), %u КиБ в памяти (до выключения)\n", n, (unsigned)(store_total() / 1024));
}

static void cmd_sha(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: sha file.zip\n"); return; }
    const struct store_file *f = store_get(argv[1]);
    if (!f) { term_set_fg(t, TC_RED); term_printf(t, "Нет файла «%s» (files — список)\n", argv[1]); term_set_fg(t, TC_DEFAULT); return; }
    uint8_t h[32]; sha256(f->data, f->len, h);
    print_hex(t, h, 32); term_printf(t, "  %s\n", f->name);
}

static void cmd_peek(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: peek file.txt  (текст)  или  peek file.bin hex\n"); return; }
    const struct store_file *f = store_get(argv[1]);
    if (!f) { term_set_fg(t, TC_RED); term_printf(t, "Нет файла «%s» (files — список)\n", argv[1]); term_set_fg(t, TC_DEFAULT); return; }
    int hex = argc >= 3 && strcmp(argv[2], "hex") == 0;
    size_t n = f->len < 512 ? f->len : 512;
    if (hex) {
        for (size_t i = 0; i < n; i += 16) {
            term_set_fg(t, TC_GRAY); term_printf(t, "%06x ", (unsigned)i); term_set_fg(t, TC_DEFAULT);
            for (size_t j = i; j < i + 16 && j < n; j++) term_printf(t, "%02x ", f->data[j]);
            term_putc(t, '\n');
        }
    } else {
        for (size_t i = 0; i < n; i++) { uint8_t c = f->data[i]; term_putc(t, (c == '\n' || (c >= 32 && c < 127) || c >= 0x80) ? (char)c : '.'); }
        term_putc(t, '\n');
    }
    if (f->len > n) term_printf(t, "... (показано %u из %u байт)\n", (unsigned)n, (unsigned)f->len);
}

static void cmd_drop(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: drop file.zip\n"); return; }
    if (store_drop(argv[1]) == 0) term_printf(t, "Удалён %s\n", argv[1]);
    else { term_set_fg(t, TC_RED); term_printf(t, "Нет файла «%s»\n", argv[1]); term_set_fg(t, TC_DEFAULT); }
}

/* upload <файл> <адрес> — отправить файл из памяти на сервер (POST); upload <файл> <адрес> put — метод PUT */
static void cmd_upload(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 3) { term_printf(t, "Пример: upload file.zip https://server.example/upload  [put]\n"); return; }
    if (!net_info()->configured) { need_net_msg(t); return; }
    const struct store_file *f = store_get(argv[1]);
    if (!f) { term_set_fg(t, TC_RED); term_printf(t, "Нет файла «%s» (files — список)\n", argv[1]); term_set_fg(t, TC_DEFAULT); return; }
    struct http_opts o; memset(&o, 0, sizeof o);
    o.method = (argc >= 4 && strcmp(argv[3], "put") == 0) ? "PUT" : "POST";
    o.body = f->data; o.body_len = f->len; o.content_type = "application/octet-stream";
    o.max_bytes = 1u << 20;
    term_printf(t, "Отправляю %s (%u байт) на %s ...\n", f->name, (unsigned)f->len, argv[2]);
    desktop_refresh();
    struct http_resp r;
    int rc = http_fetch(argv[2], &o, &r);
    if (rc != HTTP_OK) {
        term_set_fg(t, TC_RED);
        if (rc == HTTP_E_TLS) term_printf(t, "Не вышло: TLS — %s\n", tls_strerror(r.tls_err));
        else term_printf(t, "Не вышло: %s\n", http_strerror(rc));
        term_set_fg(t, TC_DEFAULT);
        http_free(&r); return;
    }
    show_tls_summary(t, &r);
    term_set_fg(t, r.status >= 200 && r.status < 300 ? TC_GREEN : TC_RED);
    term_printf(t, "Ответ сервера: %d\n", r.status);
    term_set_fg(t, TC_DEFAULT);
    if (r.len) { size_t n = r.len < 300 ? r.len : 300; for (size_t i = 0; i < n; i++) { char c = (char)r.data[i]; term_putc(t, (c == '\n' || (c >= 32 && (unsigned char)c < 127)) ? c : ' '); } term_putc(t, '\n'); }
    http_free(&r);
}

/* seal <хост> [порт] — проверить TLS-рукопожатие и показать шифр и отпечаток сертификата */
/* ---------- scan: свой сканер портов (вместо nmap, который на LimonOS не запустить) ---------- */

static const struct { uint16_t port; const char *name; } well_known[] = {
    { 21, "ftp" }, { 22, "ssh" }, { 23, "telnet" }, { 25, "smtp" }, { 53, "dns" },
    { 80, "http" }, { 110, "pop3" }, { 143, "imap" }, { 443, "https" }, { 445, "smb" },
    { 3306, "mysql" }, { 3389, "rdp" }, { 5432, "postgres" }, { 6379, "redis" }, { 8080, "http-alt" },
};
static const char *port_name(uint16_t p) {
    for (size_t i = 0; i < sizeof well_known / sizeof well_known[0]; i++) if (well_known[i].port == p) return well_known[i].name;
    return "";
}

#define SCAN_MAX_PORTS 1024

static void cmd_scan(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: scan 10.0.2.1            (частые порты)\n        scan 10.0.2.1 1-1024    (диапазон)\n        scan 10.0.2.1 22         (один порт)\n"); return; }
    if (!net_info()->configured) { need_net_msg(t); return; }
    uint32_t ip;
    if (net_parse_ip(argv[1], &ip) != 0 && net_resolve(argv[1], &ip) != 0) {
        term_set_fg(t, TC_RED); term_printf(t, "Не нашёл адрес «%s»\n", argv[1]); term_set_fg(t, TC_DEFAULT); return;
    }
    char ipstr[16]; net_ip_str(ip, ipstr);
    unsigned from, to;
    if (argc >= 3) {
        const char *p = argv[2]; from = 0;
        while (*p >= '0' && *p <= '9') from = from * 10 + (unsigned)(*p++ - '0');
        if (*p == '-') { p++; to = 0; while (*p >= '0' && *p <= '9') to = to * 10 + (unsigned)(*p++ - '0'); }
        else to = from;
        if (!from || from > 65535 || to > 65535 || to < from) { term_set_fg(t, TC_RED); term_printf(t, "Порты: число или диапазон 1-65535, например 1-1024\n"); term_set_fg(t, TC_DEFAULT); return; }
        if (to - from + 1 > SCAN_MAX_PORTS) { term_set_fg(t, TC_RED); term_printf(t, "Не больше %d портов за раз (долго без параллельности)\n", SCAN_MAX_PORTS); term_set_fg(t, TC_DEFAULT); return; }
    } else {
        from = to = 0;   /* особое значение: список частых портов */
    }
    term_printf(t, "Сканирую %s ", ipstr);
    if (from) term_printf(t, "(порты %u-%u)...\n", from, to); else term_printf(t, "(частые порты)...\n");
    term_set_fg(t, TC_GRAY); term_printf(t, "ПОРТ       СОСТОЯНИЕ   СЛУЖБА\n"); term_set_fg(t, TC_DEFAULT);
    int open_n = 0, closed_n = 0, filtered_n = 0;
    uint64_t t0 = timer_ticks;
    size_t count = from ? (to - from + 1) : (sizeof well_known / sizeof well_known[0]);
    for (size_t i = 0; i < count; i++) {
        uint16_t port = from ? (uint16_t)(from + i) : well_known[i].port;
        int id = tcp_connect(ip, port, 700);
        if (id >= 0) {
            term_set_fg(t, TC_GREEN); term_printf(t, "%-10u открыт      %s\n", (unsigned)port, port_name(port)); term_set_fg(t, TC_DEFAULT);
            tcp_close(id); open_n++;
        } else if (id == -3) {
            closed_n++;
            if (from == to) { term_set_fg(t, TC_GRAY); term_printf(t, "%-10u закрыт\n", (unsigned)port); term_set_fg(t, TC_DEFAULT); }
        } else {
            filtered_n++;
            if (from == to) { term_set_fg(t, TC_ORANGE); term_printf(t, "%-10u не отвечает (фильтр или выключено)\n", (unsigned)port); term_set_fg(t, TC_DEFAULT); }
        }
        if ((i & 7) == 0) desktop_refresh();     /* обновляем экран по ходу — сканирование не мгновенное */
    }
    uint32_t secs = (uint32_t)((timer_ticks - t0) / TIMER_HZ);
    term_set_fg(t, TC_GRAY);
    term_printf(t, "Готово за %u с. Открыто: %d, закрыто: %d, не ответили: %d (всего проверено %u)\n", secs, open_n, closed_n, filtered_n, (unsigned)count);
    term_set_fg(t, TC_DEFAULT);
}

/* ---------- google: поиск прямо из терминала ---------- */

static void urlencode(const char *s, char *out, size_t cap) {
    size_t o = 0;
    for (; *s && o + 4 < cap; s++) {
        uint8_t c = (uint8_t)*s;
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.')
            out[o++] = (char)c;
        else if (c == ' ') out[o++] = '+';
        else { out[o++] = '%'; out[o++] = "0123456789ABCDEF"[c >> 4]; out[o++] = "0123456789ABCDEF"[c & 15]; }
    }
    out[o] = 0;
}

/* DuckDuckGo отдаёт простую HTML-страницу без скриптов специально для таких случаев —
   результаты лежат в <a ... class="result__a" href="...">. Ссылка обычно завёрнута в их
   редиректор //duckduckgo.com/l/?uddg=НАСТОЯЩИЙ_АДРЕС&... — его нужно раскодировать (%XX). */
static void cmd_google(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: google LimonOS википедия\n"); return; }
    if (!net_info()->configured) { need_net_msg(t); return; }
    char q[256] = {0};
    for (int i = 1; i < argc; i++) { if (i > 1) strncat_s(q, " ", sizeof q); strncat_s(q, argv[i], sizeof q); }
    char enc[512]; urlencode(q, enc, sizeof enc);
    char url[600]; ksnprintf(url, sizeof url, "https://html.duckduckgo.com/html/?q=%s", enc);
    term_printf(t, "Ищу: %s ...\n", q);
    desktop_refresh();
    struct http_opts o; memset(&o, 0, sizeof o);
    o.max_bytes = 1u << 20;
    struct http_resp r;
    int rc = http_fetch(url, &o, &r);
    if (rc != HTTP_OK) {
        term_set_fg(t, TC_RED);
        if (rc == HTTP_E_TLS) term_printf(t, "Не вышло: TLS — %s\n", tls_strerror(r.tls_err));
        else term_printf(t, "Не вышло: %s\n", http_strerror(rc));
        term_set_fg(t, TC_DEFAULT);
        http_free(&r); return;
    }
    show_tls_summary(t, &r);
    const char *p = (const char *)r.data, *end = p + r.len;
    int n = 0;
    while (p < end && n < 10) {
        const char *m = strstr_n(p, end, "class=\"result__a\" href=\"");
        if (!m) m = strstr_n(p, end, "class=\"result__url\" href=\"");
        if (!m) break;
        m = strstr_n(m, end, "href=\"") + 6;
        const char *hend = m; while (hend < end && *hend != '"') hend++;
        char raw[400]; size_t rl = (size_t)(hend - m); if (rl > sizeof raw - 1) rl = sizeof raw - 1;
        memcpy(raw, m, rl); raw[rl] = 0;
        char link[400];
        const char *tag = strstr_n(raw, raw + strlen(raw), "uddg=");
        if (tag) { tag += 5; const char *tend = tag; while (*tend && *tend != '&') tend++; urldecode_n(tag, tend, link, sizeof link); }
        else { if (strncmp(raw, "//", 2) == 0) ksnprintf(link, sizeof link, "https:%s", raw); else ksnprintf(link, sizeof link, "%s", raw); }
        /* титул ссылки — текст сразу после закрывающей > этого же <a> */
        const char *title = hend; while (title < end && *title != '>') title++; title++;
        const char *tclose = title; while (tclose < end && *tclose != '<') tclose++;
        if (strncmp(link, "http", 4) == 0 && !strstr_n(link, link + strlen(link), "duckduckgo.com")) {
            term_set_fg(t, TC_GREEN); term_printf(t, "%d. ", ++n); term_set_fg(t, TC_DEFAULT);
            size_t tl = (size_t)(tclose - title); if (tl > 70) tl = 70;
            if (tl) term_printf(t, "%.*s\n   ", (int)tl, title);
            size_t sh = strlen(link) > 96 ? 96 : strlen(link);
            term_set_fg(t, TC_GRAY); term_printf(t, "%.*s\n", (int)sh, link); term_set_fg(t, TC_DEFAULT);
        }
        p = hend;
    }
    if (!n) { term_set_fg(t, TC_ORANGE); term_printf(t, "Не нашёл ссылок (поисковик мог поменять разметку или показать капчу). Попробуй: citrus https://html.duckduckgo.com/html/?q=%s\n", enc); term_set_fg(t, TC_DEFAULT); }
    else term_printf(t, "Открыть: citrus <ссылка>\n");
    http_free(&r);
}

/* ---------- ai: разговор с Claude (Anthropic API) прямо из терминала ---------- */

static void ai_line_cb(const char *text, void *ctx) {
    struct term *t = ctx;
    term_printf(t, "%s\n", text);
    desktop_refresh();
}

static void cmd_aikey(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) {
        if (ai_has_key()) term_printf(t, "Ключ задан: %s, модель: %s. Чтобы убрать: aikey off\n", ai_provider_name(), ai_model());
        else term_printf(t,
            "Ключ не задан. Понимаю два вида:\n"
            "  aikey sk-ant-...   — ключ Anthropic, получить: https://console.anthropic.com/settings/keys\n"
            "  aikey sk-or-v1-... — ключ OpenRouter,  получить: https://openrouter.ai/keys\n"
            "Поставщик определяется сам по виду ключа. Ключ хранится только в памяти и пропадёт при выключении — в коде LimonOS его нет.\n"
            "Сменить модель: aikey model имя-модели\n"
            "\n"
            "Не хочешь вручную набирать длинный ключ — принеси его из Windows по сети:\n"
            "  1. На Windows (в той же WSL, где собирал систему) положи ключ в файл и подними сервер:\n"
            "     echo твой-ключ > key.txt && python3 -m http.server 8000\n"
            "  2. В LimonOS:  grab http://10.0.2.2:8000/key.txt\n"
            "  3. Потом:      aikey file key.txt\n"
            "  (10.0.2.2 — это адрес хост-компьютера изнутри сети VirtualBox NAT; если не подошёл, посмотри свой через vine)\n");
        return;
    }
    if (strcmp(argv[1], "off") == 0) { ai_set_key(NULL); term_printf(t, "Ключ убран из памяти.\n"); return; }
    if (strcmp(argv[1], "model") == 0 && argc >= 3) { ai_set_model(argv[2]); term_printf(t, "Модель: %s\n", ai_model()); return; }
    if (strcmp(argv[1], "file") == 0) {
        if (argc < 3) { term_printf(t, "Пример: aikey file ключ.txt  (сначала скачай файл: grab http://10.0.2.2:ПОРТ/ключ.txt)\n"); return; }
        const struct store_file *f = store_get(argv[2]);
        if (!f) { term_set_fg(t, TC_RED); term_printf(t, "Нет файла «%s» (files — список; сначала grab)\n", argv[2]); term_set_fg(t, TC_DEFAULT); return; }
        size_t n = f->len;
        while (n > 0 && (f->data[n-1] == '\n' || f->data[n-1] == '\r' || f->data[n-1] == ' ' || f->data[n-1] == '\t')) n--;   /* обрезаем перевод строки и пробелы по краям файла */
        size_t start = 0;
        while (start < n && (f->data[start] == ' ' || f->data[start] == '\t')) start++;
        n -= start;
        if (!n || n >= 160) { term_set_fg(t, TC_RED); term_printf(t, "В файле «%s» после обрезки пробелов %u байт — не похоже на ключ.\n", argv[2], (unsigned)n); term_set_fg(t, TC_DEFAULT); return; }
        char key[160]; memcpy(key, f->data + start, n); key[n] = 0;
        ai_set_key(key);
        if (ai_get_provider() == AI_PROVIDER_NONE) {
            term_set_fg(t, TC_RED); term_printf(t, "Прочитал %u байт из файла, но не узнал поставщика по виду ключа (жду sk-ant-... или sk-or-v1-...).\n", (unsigned)n); term_set_fg(t, TC_DEFAULT);
            return;
        }
        term_set_fg(t, TC_GREEN);
        term_printf(t, "Ключ %s принят из файла «%s» (%u символов), модель: %s.\n", ai_provider_name(), argv[2], (unsigned)n, ai_model());
        term_set_fg(t, TC_DEFAULT);
        return;
    }
    ai_set_key(argv[1]);
    if (ai_get_provider() == AI_PROVIDER_NONE) {
        term_set_fg(t, TC_RED);
        term_printf(t, "Не узнал поставщика по виду ключа (жду sk-ant-... или sk-or-v1-...). Ключ не сохранён.\n");
        term_set_fg(t, TC_DEFAULT);
        return;
    }
    term_set_fg(t, TC_GREEN);
    term_printf(t, "Ключ %s принят, модель по умолчанию: %s (хранится только в памяти этого сеанса).\n", ai_provider_name(), ai_model());
    term_set_fg(t, TC_DEFAULT);
}

static void cmd_ai(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) {
        term_printf(t,
            "Пример: ai как устроен TCP?\nКлюч: aikey sk-ant-... (однократно на сеанс)\n"
            "Если сервер отвечает ошибкой и непонятно почему: ai dump твой вопрос\n"
            "  — покажет РОВНО то, что уйдёт на сервер (адрес, заголовки, ключ как он есть, тело запроса),\n"
            "    ничего не отправляя. Сверь ключ в этом выводе посимвольно с панелью поставщика.\n");
        return;
    }
    int dump = strcmp(argv[1], "dump") == 0;
    int qstart = dump ? 2 : 1;
    if (dump && argc < 3) { term_printf(t, "Пример: ai dump твой вопрос\n"); return; }
    char q[1800] = {0};
    for (int i = qstart; i < argc; i++) { if (i > qstart) strncat_s(q, " ", sizeof q); strncat_s(q, argv[i], sizeof q); }
    if (dump) { ai_dump_request(q, ai_line_cb, t); return; }
    if (!net_info()->configured) { need_net_msg(t); return; }
    if (!ai_has_key()) { term_set_fg(t, TC_RED); term_printf(t, "Сначала: aikey sk-ant-твой-ключ или sk-or-v1-твой-ключ\n"); term_set_fg(t, TC_DEFAULT); return; }
    term_set_fg(t, TC_GRAY); term_printf(t, "(%s думает...)\n", ai_model()); term_set_fg(t, TC_DEFAULT);
    desktop_refresh();
    ai_ask(q, ai_line_cb, t);
}

static int seal_send(void *ctx, const void *d, size_t n) { return tcp_send(*(int *)ctx, d, n); }
static int seal_recv(void *ctx, void *b, size_t m, int to) { return tcp_recv(*(int *)ctx, b, m, to); }

static void cmd_seal(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2) { term_printf(t, "Пример: seal github.com\n"); return; }
    if (!net_info()->configured) { need_net_msg(t); return; }
    uint32_t ip;
    if (net_resolve(argv[1], &ip) != 0) { term_set_fg(t, TC_RED); term_printf(t, "Не нашёл адрес «%s»\n", argv[1]); term_set_fg(t, TC_DEFAULT); return; }
    int port = 443;
    if (argc >= 3) { port = 0; for (const char *p = argv[2]; *p >= '0' && *p <= '9'; p++) port = port * 10 + (*p - '0'); }
    char b[16]; net_ip_str(ip, b);
    term_printf(t, "Соединяюсь с %s:%d (%s) ...\n", argv[1], port, b);
    desktop_refresh();
    uint64_t t0 = timer_ticks;
    int id = tcp_connect(ip, (uint16_t)port, 6000);
    if (id < 0) { term_set_fg(t, TC_RED); term_printf(t, "TCP не соединился\n"); term_set_fg(t, TC_DEFAULT); return; }
    uint64_t t1 = timer_ticks;
    struct tls_io io = { seal_send, seal_recv, &id };
    int err = 0;
    struct tls *tl = tls_open(&io, argv[1], &err);
    uint64_t t2 = timer_ticks;
    if (!tl) {
        term_set_fg(t, TC_RED); term_printf(t, "TLS не вышел: %s (код %d)\n", tls_strerror(err), err); term_set_fg(t, TC_DEFAULT);
        tcp_close(id); return;
    }
    const struct tls_info *ti = tls_info(tl);
    term_set_fg(t, TC_GREEN); term_printf(t, "TLS 1.3 установлен, шифр: %s\n", ti->cipher); term_set_fg(t, TC_DEFAULT);
    term_printf(t, "  TCP: %u мс, рукопожатие: %u мс\n", (unsigned)((t1 - t0) * 1000 / TIMER_HZ), (unsigned)((t2 - t1) * 1000 / TIMER_HZ));
    if (ti->have_cert) { term_set_fg(t, TC_GRAY); term_printf(t, "  сертификат SHA-256:\n  "); print_hex(t, ti->cert_sha256, 32); term_putc(t, '\n'); term_set_fg(t, TC_DEFAULT); }
    term_set_fg(t, TC_ORANGE); term_printf(t, "  подлинность сервера не проверена — сверь отпечаток с openssl на другом ПК\n"); term_set_fg(t, TC_DEFAULT);
    tls_close(tl);
    tcp_close(id);
}

/* ---------- lima: установка программ ---------- */

#define LIMA_PLANNED 0
#define LIMA_NET     1

struct lima_pkg {
    const char *name, *alt, *owner, *repo, *note;
    int kind;
    int installed;
    char *readme;      /* kmalloc, если установлен */
};

static struct lima_pkg lima_catalog[] = {
    { "wifiscan",     0,            "AnonimusShamshiAlex", "wifiscan",      "сканер Wi-Fi сетей",              LIMA_NET, 0, 0 },
    { "brutepass",    0,            "AnonimusShamshiAlex", "brutepass",     "подбор паролей",                  LIMA_NET, 0, 0 },
    { "iotlamp",      0,            "AnonimusShamshiAlex", "iotlamp",       "работа с IoT-устройствами",       LIMA_NET, 0, 0 },
    { "exifosint",    0,            "AnonimusShamshiAlex", "exifosint",     "разбор EXIF для OSINT",           LIMA_NET, 0, 0 },
    { "hashbrutes",   0,            "AnonimusShamshiAlex", "hashbrutes",    "подбор по хешам",                 LIMA_NET, 0, 0 },
    { "cscan",        0,            "AnonimusShamshiAlex", "cscan",         "сканер сети и портов",            LIMA_NET, 0, 0 },
    { "parsing-site", 0,            "AnonimusShamshiAlex", "parsing-site",  "парсинг сайтов",                  LIMA_NET, 0, 0 },
    { "nmap",         0,            0, 0,                                  "сканер портов (чужая программа)", LIMA_PLANNED, 0, 0 },
    { "python",       0,            0, 0,                                  "язык программирования Python",    LIMA_PLANNED, 0, 0 },
    { "git",          0,            0, 0,                                  "система контроля версий",         LIMA_PLANNED, 0, 0 },
    { "telegram",     "телеграм",   0, 0,                                  "мессенджер Telegram",             LIMA_PLANNED, 0, 0 },
};
#define NLIMA ((int)(sizeof lima_catalog / sizeof lima_catalog[0]))

static int lima_find(const char *name) {
    for (int i = 0; i < NLIMA; i++)
        if (strcmp(lima_catalog[i].name, name) == 0 || (lima_catalog[i].alt && strcmp(lima_catalog[i].alt, name) == 0))
            return i;
    return -1;
}

static void lima_list(struct term *t) {
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "Твои программы (lima install <имя>):\n");
    term_set_fg(t, TC_DEFAULT);
    for (int i = 0; i < NLIMA; i++)
        if (lima_catalog[i].kind == LIMA_NET)
            term_printf(t, "  %-13s %s  %s\n", lima_catalog[i].name,
                        lima_catalog[i].installed ? "[✓ установлен]" : "              ", lima_catalog[i].note);
    term_set_fg(t, TC_GRAY);
    term_printf(t, "\nБольшие чужие программы (ждут слоя Pulp, пока только показывают статус):\n");
    term_set_fg(t, TC_DEFAULT);
    for (int i = 0; i < NLIMA; i++)
        if (lima_catalog[i].kind == LIMA_PLANNED)
            term_printf(t, "  %-13s %s\n", lima_catalog[i].name, lima_catalog[i].note);
}

static void lima_install(struct term *t, const char *name) {
    int i = lima_find(name);
    if (i < 0) { term_set_fg(t, TC_RED); term_printf(t, "Нет такого пакета. lima list — список.\n"); term_set_fg(t, TC_DEFAULT); return; }
    struct lima_pkg *pkg = &lima_catalog[i];
    if (pkg->kind == LIMA_PLANNED) {
        term_set_fg(t, TC_RED);
        term_printf(t, "«%s» — чужая программа (%s). LimonOS пока не умеет запускать\n", pkg->name, pkg->note);
        term_printf(t, "сторонний код (нужен загрузчик программ, он в планах). Похожее уже есть:\n");
        term_set_fg(t, TC_DEFAULT);
        if (strcmp(pkg->name, "nmap") == 0) term_printf(t, "  pci, vine, sonar — посмотреть сеть и устройства\n");
        return;
    }
    if (!net_info()->configured) { term_set_fg(t, TC_RED); term_printf(t, "Нет сети. Набери: vine dhcp\n"); term_set_fg(t, TC_DEFAULT); return; }
    char url[200];
    term_printf(t, "Скачиваю %s/%s с GitHub (https)...\n", pkg->owner, pkg->repo);
    desktop_refresh();
    struct http_opts o; memset(&o, 0, sizeof o);
    o.max_bytes = 1u << 20;
    struct http_resp r; int rc = -1;
    const char *branches[2] = { "main", "master" };
    for (int k = 0; k < 2; k++) {
        ksnprintf(url, sizeof url, "https://raw.githubusercontent.com/%s/%s/%s/README.md", pkg->owner, pkg->repo, branches[k]);
        rc = http_fetch(url, &o, &r);
        if (rc == HTTP_OK && r.status == 200) break;
        http_free(&r);
        if (rc != HTTP_OK && rc != HTTP_E_CLOSED) break;      /* сеть/TLS сломаны — вторая ветка не поможет */
    }
    if (rc != HTTP_OK || r.status != 200) {
        term_set_fg(t, TC_RED);
        if (rc == HTTP_E_TLS) term_printf(t, "Не вышло: TLS — %s\n", tls_strerror(r.tls_err));
        else if (rc != HTTP_OK) term_printf(t, "Не вышло: %s\n", http_strerror(rc));
        else term_printf(t, "Не удалось скачать (ответ сервера: %d). Проверь имя репозитория.\n", r.status);
        term_set_fg(t, TC_DEFAULT);
        if (rc == HTTP_OK) http_free(&r);
        return;
    }
    show_tls_summary(t, &r);
    char *buf = (char *)r.data; size_t body = 0; int n = (int)r.len;
    size_t rl = (size_t)n - body; if (rl > 400) rl = 400;
    if (pkg->readme) kfree(pkg->readme);
    pkg->readme = kmalloc(rl + 1);
    if (pkg->readme) { memcpy(pkg->readme, buf + body, rl); pkg->readme[rl] = 0; }
    pkg->installed = 1;
    http_free(&r); (void)buf;
    term_set_fg(t, TC_GREEN);
    term_printf(t, "Установлен «%s» (метаданные, %d байт README). Теперь можно набрать: %s\n", pkg->name, n, pkg->name);
    term_set_fg(t, TC_DEFAULT);
}

static void cmd_lima(struct shell *s, int argc, char **argv) {
    struct term *t = s->t;
    if (argc < 2 || strcmp(argv[1], "list") == 0) { lima_list(t); return; }
    if (strcmp(argv[1], "install") == 0) {
        if (argc < 3) { term_printf(t, "Пример: lima install cscan\n"); return; }
        lima_install(t, argv[2]);
        return;
    }
    if (strcmp(argv[1], "remove") == 0) {
        if (argc < 3) { term_printf(t, "Пример: lima remove cscan\n"); return; }
        int i = lima_find(argv[2]);
        if (i >= 0 && lima_catalog[i].installed) {
            if (lima_catalog[i].readme) { kfree(lima_catalog[i].readme); lima_catalog[i].readme = 0; }
            lima_catalog[i].installed = 0;
            term_printf(t, "Удалён «%s»\n", argv[2]);
        } else term_printf(t, "Не установлен: %s\n", argv[2]);
        return;
    }
    term_printf(t, "Используй: lima list | lima install <имя> | lima remove <имя>\n");
}

/* показывает установленный через lima пакет как команду: cscan, iotlamp и т.д. */
static int run_lima_package(struct shell *s, int idx, int argc, char **argv) {
    struct term *t = s->t;
    struct lima_pkg *pkg = &lima_catalog[idx];
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "%s", pkg->name);
    term_set_fg(t, TC_DEFAULT);
    term_printf(t, " — %s\n", pkg->note);
    term_printf(t, "Источник: github.com/%s/%s\n", pkg->owner, pkg->repo);
    if (argc > 1) {
        term_printf(t, "Параметры:");
        for (int i = 1; i < argc; i++) term_printf(t, " %s", argv[i]);
        term_putc(t, '\n');
    }
    if (pkg->readme && pkg->readme[0]) {
        term_set_fg(t, TC_GRAY);
        term_printf(t, "\nREADME (начало):\n%s\n", pkg->readme);
        term_set_fg(t, TC_DEFAULT);
    }
    term_set_fg(t, TC_ORANGE);
    term_printf(t, "\nЗапуск появится после слоя Pulp (загрузчик программ). Пока показаны только метаданные.\n");
    term_set_fg(t, TC_DEFAULT);
    return 0;
}

static void cmd_rebirth(struct shell *s, int argc, char **argv) {
    (void)s; (void)argc; (void)argv;
    desktop_power(1);
}

static void cmd_bye(struct shell *s, int argc, char **argv) {
    (void)s; (void)argc; (void)argv;
    desktop_power(0);
}

static const struct cmd commands[] = {
    { "zest",     "цедра",   "список команд",                          cmd_zest },
    { "squeeze",  "выжать",  "очистить экран терминала",               cmd_squeeze },
    { "peel",     "кожура",  "сведения о системе (с лимоном)",         cmd_peel },
    { "juice",    "сок",     "память: сколько сока осталось",          cmd_juice },
    { "engine",   "мотор",   "процессор и его возможности",            cmd_engine },
    { "sundial",  "время",   "дата и время (часы BIOS)",               cmd_sundial },
    { "pulse",    "пульс",   "сколько система уже работает",           cmd_pulse },
    { "say",      "сказать", "повторить сказанное",                    cmd_say },
    { "abacus",   "счёты",   "калькулятор: abacus 2+3*(4-1)",          cmd_abacus },
    { "palette",  "краски",  "цвета и темы оформления",                cmd_palette },
    { "tint",     "оттенок", "сменить тему: tint lime",                cmd_tint },
    { "lang",     "язык",    "раскладка клавиатуры: lang ru | en",     cmd_lang },
    { "twin",     "двойник", "открыть ещё один терминал",              cmd_twin },
    { "pci",      "шина",    "устройства на шине материнской платы",   cmd_pci },
    { "vine",     "лоза",    "сеть: адрес, шлюз, DNS; vine dhcp",      cmd_vine },
    { "sonar",    "эхо",     "проверить связь (ping): sonar 8.8.8.8",  cmd_sonar },
    { "lookup",   "найти",   "узнать адрес сайта: lookup example.com", cmd_lookup },
    { "ping",     "пинг",    "проверить связь (то же, что sonar)",     cmd_sonar },
    { "citrus",   "цитрус",  "простой браузер: citrus example.com",    cmd_citrus },
    { "lima",     "лима",    "ставить программы: lima install cscan",  cmd_lima },
    { "grab",     "качать",  "скачать файл в память: grab https://...", cmd_grab },
    { "files",    "файлы",   "что скачано (хранится в памяти)",        cmd_files },
    { "peek",     "глянуть", "показать файл: peek имя [hex]",          cmd_peek },
    { "sha",      "хеш",     "SHA-256 файла: sha имя",                 cmd_sha },
    { "drop",     "убрать",  "удалить файл из памяти: drop имя",       cmd_drop },
    { "upload",   "отдать",  "отправить файл: upload имя https://...", cmd_upload },
    { "seal",     "печать",  "проверить https/TLS: seal github.com",   cmd_seal },
    { "scan",     "скан",    "сканер портов: scan 10.0.2.1 [порт(ы)]", cmd_scan },
    { "google",   "гугл",    "поиск в интернете: google запрос",       cmd_google },
    { "ai",       "аи",      "спросить ИИ (Claude): ai твой вопрос",   cmd_ai },
    { "aikey",    "аиключ",  "задать ключ Anthropic API: aikey sk-...", cmd_aikey },
    { "omen",     "знамение","лимонное предсказание",                  cmd_omen },
    { "rebirth",  "заново",  "перезагрузить компьютер",                cmd_rebirth },
    { "bye",      "пока",    "выключить компьютер",                    cmd_bye },
};
static const int ncommands = (int)(sizeof commands / sizeof commands[0]);

static void cmd_zest(struct shell *s, int argc, char **argv) {
    (void)argc; (void)argv;
    struct term *t = s->t;
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "Лимонный справочник LimonOS %s\n", LIMON_VERSION);
    term_set_fg(t, TC_DEFAULT);
    for (int i = 0; i < ncommands; i++) {
        term_set_fg(t, TC_ACCENT);
        term_printf(t, "  %-9s", commands[i].name);
        term_set_fg(t, TC_GRAY);
        term_printf(t, "%-8s", commands[i].alt);
        term_set_fg(t, TC_DEFAULT);
        term_printf(t, "%s\n", commands[i].desc);
    }
    term_set_fg(t, TC_GRAY);
    term_printf(t, "Клавиши: F2 язык, F3 терминал, F4 закрыть окно, F5 тема, Alt+Tab окна\n");
    term_set_fg(t, TC_DEFAULT);
}

/* ---------- выполнение ---------- */

static int tokenize(char *line, char **argv, int max) {
    int argc = 0;
    char *p = line;
    while (*p) {
        while (*p == ' ') p++;
        if (!*p) break;
        if (argc < max) argv[argc++] = p;
        while (*p && *p != ' ') p++;
        if (*p) *p++ = 0;
    }
    return argc;
}

static void run_command(struct shell *s, char *line) {
    char *argv[12];
    int argc = tokenize(line, argv, 12);
    if (argc == 0) return;
    for (char *p = argv[0]; *p; p++) if (*p >= 'A' && *p <= 'Z') *p += 32;
    for (int i = 0; i < ncommands; i++) {
        if (strcmp(argv[0], commands[i].name) == 0 || strcmp(argv[0], commands[i].alt) == 0) {
            commands[i].fn(s, argc, argv);
            return;
        }
    }
    int li = lima_find(argv[0]);
    if (li >= 0 && lima_catalog[li].installed) { run_lima_package(s, li, argc, argv); return; }
    term_set_fg(s->t, TC_RED);
    term_printf(s->t, "Неизвестная команда «%s». Набери zest, чтобы увидеть список.\n", argv[0]);
    if (li >= 0) term_printf(s->t, "Подсказка: набери  lima install %s\n", argv[0]);
    term_set_fg(s->t, TC_DEFAULT);
}

static void submit(struct shell *s) {
    struct term *t = s->t;
    char buf[SH_HIST_BYTES];
    int n = 0;
    for (int i = 0; i < s->len; i++) n += utf8_encode(s->line[i], buf + n);
    buf[n] = 0;
    t->cx = PROMPT_COLS + s->len;
    term_putc(t, '\n');
    if (n > 0) {
        add_history(s, buf);
        run_command(s, buf);
    }
    show_prompt(s);
}

void shell_init(struct shell *s, struct term *t) {
    s->t = t;
    s->hist_count = 0;
    s->hist_idx = -1;
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "LimonOS %s", LIMON_VERSION);
    term_set_fg(t, TC_DEFAULT);
    term_printf(t, " — терминал. Набери ");
    term_set_fg(t, TC_ACCENT);
    term_printf(t, "zest");
    term_set_fg(t, TC_DEFAULT);
    term_printf(t, ", чтобы увидеть команды.\n\n");
    show_prompt(s);
}

void shell_key(struct shell *s, const struct key_event *ev) {
    uint32_t cp = ev->cp;
    if (ev->mods & MOD_CTRL) {
        if (cp == 'l') { term_clear(s->t); show_prompt(s); }
        else if (cp == 'c') { s->t->cx = PROMPT_COLS + s->len; term_printf(s->t, "^C\n"); show_prompt(s); }
        else if (cp == 'u') { s->len = s->pos = s->scroll = 0; repaint(s); }
        return;
    }
    switch (cp) {
    case '\n': submit(s); return;
    case '\b':
        if (s->pos > 0) {
            for (int i = s->pos; i < s->len; i++) s->line[i - 1] = s->line[i];
            s->pos--; s->len--;
        }
        break;
    case KEY_DELETE:
        if (s->pos < s->len) {
            for (int i = s->pos + 1; i < s->len; i++) s->line[i - 1] = s->line[i];
            s->len--;
        }
        break;
    case KEY_LEFT:  if (s->pos > 0) s->pos--; break;
    case KEY_RIGHT: if (s->pos < s->len) s->pos++; break;
    case KEY_HOME:  s->pos = 0; break;
    case KEY_END:   s->pos = s->len; break;
    case KEY_UP:
        if (s->hist_count == 0) return;
        if (s->hist_idx < 0) s->hist_idx = s->hist_count - 1;
        else if (s->hist_idx > 0) s->hist_idx--;
        load_line(s, s->hist[s->hist_idx]);
        break;
    case KEY_DOWN:
        if (s->hist_idx < 0) return;
        if (++s->hist_idx >= s->hist_count) { s->hist_idx = -1; s->len = s->pos = 0; }
        else load_line(s, s->hist[s->hist_idx]);
        break;
    default:
        if (cp >= 0x20 && cp < 0x110000 && s->len < SH_LINE_MAX) {
            for (int i = s->len; i > s->pos; i--) s->line[i] = s->line[i - 1];
            s->line[s->pos++] = cp;
            s->len++;
        }
        break;
    }
    repaint(s);
}
